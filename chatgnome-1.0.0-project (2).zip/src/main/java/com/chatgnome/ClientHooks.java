package com.chatgnome;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

/** Код, що виконується тільки на клієнті. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void open(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(entityId);
        if (e instanceof GnomeEntity g) mc.setScreen(new GnomeScreen(g));
    }
}
