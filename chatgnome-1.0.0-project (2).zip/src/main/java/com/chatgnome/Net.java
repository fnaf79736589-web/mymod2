package com.chatgnome;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private Net() {}

    private static final String VER = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ChatGnomeMod.MODID, "main"), () -> VER, VER::equals, VER::equals);
    private static boolean done;

    public static void init() {
        if (done) return;
        done = true;
        int id = 0;
        CHANNEL.registerMessage(id++, OpenScreen.class, OpenScreen::encode, OpenScreen::decode, OpenScreen::handle);
        CHANNEL.registerMessage(id++, Command.class, Command::encode, Command::decode, Command::handle);
    }

    /** Сервер -> клієнт: відкрити вікно завдань гнома. */
    public static class OpenScreen {
        final int entityId;

        public OpenScreen(int entityId) { this.entityId = entityId; }

        void encode(FriendlyByteBuf buf) { buf.writeInt(entityId); }

        static OpenScreen decode(FriendlyByteBuf buf) { return new OpenScreen(buf.readInt()); }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() ->
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.open(entityId)));
            ctx.get().setPacketHandled(true);
        }
    }

    /** Клієнт -> сервер: довге завдання з вікна. */
    public static class Command {
        final int entityId;
        final String text;

        public Command(int entityId, String text) {
            this.entityId = entityId;
            this.text = text;
        }

        void encode(FriendlyByteBuf buf) {
            buf.writeInt(entityId);
            buf.writeUtf(text, 6000);
        }

        static Command decode(FriendlyByteBuf buf) { return new Command(buf.readInt(), buf.readUtf(6000)); }

        void handle(Supplier<NetworkEvent.Context> ctx) {
            ServerPlayer sender = ctx.get().getSender();
            ctx.get().enqueueWork(() -> {
                if (sender == null) return;
                Entity e = sender.serverLevel().getEntity(entityId);
                if (!(e instanceof GnomeEntity g)) return;
                if (!sender.getUUID().equals(g.getOwnerId()) || g.distanceToSqr(sender) > 128.0 * 128.0) return;
                String t = text.trim();
                if (!t.isEmpty()) ChatHandler.handleCommand(sender, g, t);
            });
            ctx.get().setPacketHandled(true);
        }
    }
}
