package com.chatgnome;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class GnomeScreen extends Screen {
    private static String lastText = "";

    private final int entityId;
    private MultiLineEditBox box;
    private boolean sent;

    public GnomeScreen(GnomeEntity g) {
        super(Component.literal("Гном: нове завдання"));
        this.entityId = g.getId();
    }

    @Override
    protected void init() {
        int w = Math.min(width - 40, 440);
        int x = (width - w) / 2;
        int top = 36;
        int h = Math.max(60, height - 36 - 60);
        box = new MultiLineEditBox(font, x, top, w, h,
                Component.literal("Опиши завдання докладно: що побудувати, з чого, скільки поверхів, які розміри, що всередині..."),
                Component.empty());
        box.setCharacterLimit(5000);
        box.setValue(lastText);
        addRenderableWidget(box);
        setInitialFocus(box);

        int by = top + h + 8;
        int gap = 6;
        int bw = (w - 2 * gap) / 3;
        addRenderableWidget(Button.builder(Component.literal("Надіслати (Ctrl+Enter)"), b -> send(box.getValue()))
                .bounds(x, by, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Зупинити гнома"), b -> { sendRaw("стоп"); onClose(); })
                .bounds(x + bw + gap, by, bw, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Закрити"), b -> onClose())
                .bounds(x + 2 * (bw + gap), by, bw, 20).build());
    }

    private void send(String raw) {
        String t = raw.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) return;
        sendRaw(t);
        lastText = "";
        sent = true;
        onClose();
    }

    private void sendRaw(String t) {
        Net.CHANNEL.sendToServer(new Net.Command(entityId, t));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == 257 || keyCode == 335) && hasControlDown()) {
            send(box.getValue());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (!sent && box != null) lastText = box.getValue();
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        renderBackground(gfx);
        gfx.drawCenteredString(font, title, width / 2, 14, 0xFFFFFF);
        super.render(gfx, mouseX, mouseY, partialTick);
    }
}
