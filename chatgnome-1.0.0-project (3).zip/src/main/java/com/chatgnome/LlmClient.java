package com.chatgnome;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class LlmClient {
    private LlmClient() {}

    public static String ask(String system, String user) throws Exception {
        String key = Config.apiKey();
        if (key.isBlank()) {
            throw new IllegalStateException("Не задано API ключ. Використай команду /gnome apikey <ключ>");
        }
        return Config.useAnthropic() ? askAnthropic(key, system, user) : askCompat(key, system, user);
    }

    private static String post(String url, JsonObject body, String[][] headers) throws Exception {
        for (int attempt = 1; ; attempt++) {
            try {
                return postOnce(url, body, headers);
            } catch (java.net.SocketTimeoutException e) {
                if (attempt >= 2) throw new IOException("Сервіс ШІ не відповів вчасно. Спробуй ще раз.");
            }
        }
    }

    private static String postOnce(String url, JsonObject body, String[][] headers) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(180000);
        c.setDoOutput(true);
        c.setRequestProperty("content-type", "application/json");
        for (String[] h : headers) c.setRequestProperty(h[0], h[1]);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
        String resp = is == null ? "" : new String(is.readAllBytes(), StandardCharsets.UTF_8);
        if (code / 100 != 2) {
            String hint = (code == 401 || code == 403) ? " (перевір API ключ)"
                    : code == 429 ? " (перевищено ліміт запитів, зачекай хвилину)" : "";
            throw new IOException("API " + code + hint + ": " + (resp.length() > 300 ? resp.substring(0, 300) : resp));
        }
        return resp;
    }

    private static JsonObject msg(String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        return m;
    }

    private static String askAnthropic(String key, String system, String user) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.MODEL.get());
        body.addProperty("max_tokens", 4000);
        body.addProperty("system", system);
        JsonArray msgs = new JsonArray();
        msgs.add(msg("user", user));
        body.add("messages", msgs);

        String resp = post(Config.API_URL.get(), body, new String[][]{
                {"x-api-key", key}, {"anthropic-version", "2023-06-01"}});
        JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        for (JsonElement e : o.getAsJsonArray("content")) {
            JsonObject part = e.getAsJsonObject();
            if (part.has("type") && "text".equals(part.get("type").getAsString())) {
                sb.append(part.get("text").getAsString());
            }
        }
        return sb.toString();
    }

    /** Формат OpenAI chat/completions: Gemini, Groq, OpenRouter, Ollama тощо. */
    private static String askCompat(String key, String system, String user) throws Exception {
        JsonObject body = new JsonObject();
        body.addProperty("model", Config.COMPAT_MODEL.get());
        body.addProperty("max_tokens", 8000);
        JsonArray msgs = new JsonArray();
        msgs.add(msg("system", system));
        msgs.add(msg("user", user));
        body.add("messages", msgs);

        String resp = post(Config.COMPAT_URL.get(), body, new String[][]{
                {"Authorization", "Bearer " + key}});
        JsonObject o = JsonParser.parseString(resp).getAsJsonObject();
        JsonArray choices = o.getAsJsonArray("choices");
        if (choices == null || choices.size() == 0) throw new IOException("Порожня відповідь моделі");
        JsonObject message = choices.get(0).getAsJsonObject().getAsJsonObject("message");
        if (message == null || !message.has("content") || message.get("content").isJsonNull()) {
            throw new IOException("Модель не повернула текст (можливо, спрацював фільтр). Спробуй переформулювати.");
        }
        return message.get("content").getAsString();
    }

    public static JsonObject parsePlan(String reply) {
        String s = reply.trim();
        int a = s.indexOf('{');
        int b = s.lastIndexOf('}');
        if (a < 0 || b < a) throw new IllegalArgumentException("Модель не повернула JSON");
        return JsonParser.parseString(s.substring(a, b + 1)).getAsJsonObject();
    }
}
