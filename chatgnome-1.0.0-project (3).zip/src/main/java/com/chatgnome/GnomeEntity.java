package com.chatgnome;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.PacketDistributor;

public class GnomeEntity extends PathfinderMob {
    private UUID owner;
    private final SimpleContainer inventory = new SimpleContainer(27);
    private final Deque<Tasks.Task> queue = new ArrayDeque<>();
    private Tasks.Task current;
    private boolean buildMode;
    /** Лічильник запитів до ШІ: застарілі відповіді ігноруються. */
    public int requestSeq;

    public GnomeEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(6, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double dist) { return false; }

    public UUID getOwnerId() { return owner; }

    public SimpleContainer getInventory() { return inventory; }

    public boolean isBuildMode() { return buildMode; }

    /** Режим «привида»: без гравітації й колізій (для будівництва й копання всередині породи). */
    public void setBuildMode(boolean on) {
        buildMode = on;
        setNoGravity(on);
        noPhysics = on;
        setInvulnerable(on);
        if (!on) fallDistance = 0;
    }

    public void enqueue(Tasks.Task t) { queue.add(t); }

    public void clearTasks() {
        if (current != null) {
            try { current.cancel(this); } catch (Exception ignored) { }
        }
        current = null;
        queue.clear();
        if (buildMode) {
            setBuildMode(false);
            Util.surface(this);
        }
    }

    public boolean isBusy() { return current != null || !queue.isEmpty(); }

    public void fail(String msg) {
        say(msg);
        clearTasks();
    }

    public void say(String msg) {
        if (level().isClientSide || owner == null || msg == null || msg.isBlank()) return;
        ServerPlayer p = ((ServerLevel) level()).getServer().getPlayerList().getPlayer(owner);
        if (p != null) p.sendSystemMessage(Component.literal("<Гном> " + msg));
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        runTasks();
    }

    private void runTasks() {
        if (current == null) {
            current = queue.poll();
            if (current == null) return;
            try {
                current.start(this);
            } catch (Exception e) {
                fail(e.getMessage() == null ? e.toString() : e.getMessage());
                return;
            }
        }
        try {
            if (current.tick(this)) current = null;
        } catch (Exception e) {
            e.printStackTrace();
            fail("Щось пішло не так: " + e);
        }
    }

    public String inventorySummary() {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            ItemStack s = inventory.getItem(i);
            if (!s.isEmpty()) m.merge(Util.itemId(s), s.getCount(), Integer::sum);
        }
        if (m.isEmpty()) return "порожньо";
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (Map.Entry<String, Integer> e : m.entrySet()) {
            if (n++ >= 12) { sb.append("..."); break; }
            sb.append(e.getKey()).append(" x").append(e.getValue()).append(", ");
        }
        return sb.toString();
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (owner == null) {
            owner = player.getUUID();
            say("Привіт! Тепер я твій гном. Клікни по мені ще раз (порожньою рукою), щоб відкрити вікно завдань, або пиши в чат: \"гном, ...\". Не забудь задати API ключ (/gnome apikey ...): підійде ключ Anthropic або Gemini.");
            return InteractionResult.CONSUME;
        }
        if (!player.getUUID().equals(owner)) {
            player.sendSystemMessage(Component.literal("<Гном> Я працюю не на тебе."));
            return InteractionResult.CONSUME;
        }
        ItemStack held = player.getItemInHand(hand);
        if (!held.isEmpty()) {
            ItemStack rest = inventory.addItem(held.copy());
            held.shrink(held.getCount() - rest.getCount());
            say("Забрав у інвентар.");
            return InteractionResult.CONSUME;
        }
        if (player.isShiftKeyDown()) {
            say("В мене: " + inventorySummary());
        } else {
            if (player instanceof ServerPlayer sp) {
                Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> sp), new Net.OpenScreen(getId()));
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) tag.putUUID("Owner", owner);
        tag.put("Inv", inventory.createTag());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) owner = tag.getUUID("Owner");
        inventory.fromTag(tag.getList("Inv", Tag.TAG_COMPOUND));
    }
}
