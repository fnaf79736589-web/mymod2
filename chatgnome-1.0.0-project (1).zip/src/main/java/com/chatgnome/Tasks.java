package com.chatgnome;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

public final class Tasks {
    private Tasks() {}

    public abstract static class Task {
        public void start(GnomeEntity g) {}
        /** true = завдання завершено */
        public abstract boolean tick(GnomeEntity g);
        public void cancel(GnomeEntity g) {}
    }

    public static Task fromJson(JsonObject o, ServerPlayer p) {
        String a = JsonUtil.gets(o, "action", "");
        switch (a) {
            case "goto": return new Goto(o, p);
            case "mine": return new Mine(o);
            case "give_items": return new Give(o, p);
            case "store_items": return new Store(o);
            case "build_house": return new Build(o, p);
            default: throw new IllegalArgumentException("Невідома дія: " + a);
        }
    }

    // ------------------------------------------------------------------ goto
    public static class Goto extends Task {
        final BlockPos fixed;
        final UUID pid;
        int ticks;

        Goto(JsonObject o, ServerPlayer p) {
            pid = p.getUUID();
            fixed = JsonUtil.has(o, "x") && JsonUtil.has(o, "z")
                    ? new BlockPos(JsonUtil.geti(o, "x", 0), JsonUtil.geti(o, "y", p.getBlockY()), JsonUtil.geti(o, "z", 0))
                    : null;
        }

        BlockPos target(GnomeEntity g) {
            if (fixed != null) return fixed;
            Player pl = g.level().getPlayerByUUID(pid);
            return pl != null ? pl.blockPosition() : g.blockPosition();
        }

        @Override
        public boolean tick(GnomeEntity g) {
            BlockPos t = target(g);
            if (g.blockPosition().closerThan(t, 3.0)) {
                g.getNavigation().stop();
                return true;
            }
            if (ticks % 20 == 0) g.getNavigation().moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5, 1.15);
            if (++ticks > 20 * 45) {
                g.moveTo(t.getX() + 0.5, t.getY(), t.getZ() + 0.5);
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------------ mine
    public static class Mine extends Task {
        final String spec;
        final int count, radius;
        Predicate<BlockState> m;
        int mined, wait, brk;
        BlockPos target;

        Mine(JsonObject o) {
            spec = JsonUtil.gets(o, "block", "minecraft:stone");
            count = JsonUtil.clamp(JsonUtil.geti(o, "count", 16), 1, 2304);
            radius = JsonUtil.clamp(JsonUtil.geti(o, "radius", 16), 4, 32);
        }

        @Override
        public void start(GnomeEntity g) { m = Util.matcher(spec); }

        @Override
        public void cancel(GnomeEntity g) { Util.leaveGhost(g); }

        boolean finish(GnomeEntity g, String msg) {
            g.say(msg);
            Util.leaveGhost(g);
            return true;
        }

        @Override
        public boolean tick(GnomeEntity g) {
            Level lv = g.level();
            if (mined >= count) return finish(g, "Накопав " + mined + " (" + spec + ").");
            if (target == null || !m.test(lv.getBlockState(target))) {
                target = find(g);
                wait = 0;
                brk = 0;
                if (target == null) {
                    return finish(g, mined == 0 ? "Не знайшов потрібних блоків поблизу (" + spec + ")."
                            : "Більше таких блоків нема поруч. Накопав " + mined + ".");
                }
            }
            Vec3 c = Vec3.atCenterOf(target);
            if (g.distanceToSqr(c) > 12.0) {
                if (wait % 20 == 0) g.getNavigation().moveTo(c.x, c.y, c.z, 1.25);
                if (++wait > 60) {
                    ghostTo(g, target);
                    wait = 0;
                }
                return false;
            }
            g.getNavigation().stop();
            g.getLookControl().setLookAt(c);
            if (++brk < 5) return false;
            brk = 0;
            BlockState st = lv.getBlockState(target);
            List<ItemStack> drops = Block.getDrops(st, (ServerLevel) lv, target, lv.getBlockEntity(target), g,
                    new ItemStack(Items.NETHERITE_PICKAXE));
            lv.destroyBlock(target, false, g);
            for (ItemStack d : drops) {
                ItemStack rest = g.getInventory().addItem(d);
                if (!rest.isEmpty()) g.spawnAtLocation(rest);
            }
            mined++;
            target = null;
            return false;
        }

        BlockPos find(GnomeEntity g) {
            Level lv = g.level();
            BlockPos c = g.blockPosition();
            BlockPos best = null;
            double bd = Double.MAX_VALUE;
            BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dy = -radius; dy <= radius; dy++) {
                    for (int dz = -radius; dz <= radius; dz++) {
                        mp.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                        BlockState s = lv.getBlockState(mp);
                        if (s.isAir() || !m.test(s)) continue;
                        double d = mp.distSqr(c);
                        if (d < bd && canBreak(lv, mp, s)) {
                            bd = d;
                            best = mp.immutable();
                        }
                    }
                }
            }
            return best;
        }

        static boolean canBreak(Level lv, BlockPos pos, BlockState s) {
            return s.getDestroySpeed(lv, pos) >= 0 && lv.getBlockEntity(pos) == null;
        }

        static void ghostTo(GnomeEntity g, BlockPos t) {
            g.setBuildMode(true);
            BlockPos spot = t;
            for (Direction d : Direction.values()) {
                BlockPos n = t.relative(d);
                if (g.level().getBlockState(n).getCollisionShape(g.level(), n).isEmpty()) {
                    spot = n;
                    break;
                }
            }
            g.moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5);
            g.getNavigation().stop();
        }
    }

    // ------------------------------------------------------------------ give
    public static class Give extends Task {
        final UUID pid;
        final String item;
        final int count;
        int wait;

        Give(JsonObject o, ServerPlayer p) {
            pid = p.getUUID();
            item = Util.normId(JsonUtil.gets(o, "item", "all"));
            count = item.equals("minecraft:all") ? 100000 : JsonUtil.clamp(JsonUtil.geti(o, "count", 64), 1, 100000);
        }

        @Override
        public boolean tick(GnomeEntity g) {
            Player p = g.level().getPlayerByUUID(pid);
            if (p == null) {
                g.say("Не бачу гравця.");
                return true;
            }
            if (g.distanceToSqr(p) > 9) {
                if (wait % 20 == 0) g.getNavigation().moveTo(p, 1.2);
                if (++wait > 100) g.moveTo(p.getX(), p.getY(), p.getZ());
                return false;
            }
            boolean all = item.equals("minecraft:all");
            int left = count, given = 0;
            SimpleContainer inv = g.getInventory();
            for (int i = 0; i < inv.getContainerSize() && left > 0; i++) {
                ItemStack s = inv.getItem(i);
                if (s.isEmpty()) continue;
                if (!all && !Util.itemId(s).equals(item)) continue;
                int n = Math.min(left, s.getCount());
                ItemStack out = s.split(n);
                left -= n;
                given += n;
                if (!p.getInventory().add(out)) p.drop(out, false);
            }
            g.say(given > 0 ? "Тримай: " + given + " шт." : "У мене нема такого предмета.");
            return true;
        }
    }

    // ------------------------------------------------------------------ store
    public static class Store extends Task {
        static class Ref {
            BlockPos pos;
            String label;
            Container c;
        }

        final int radius;
        final List<Ref> chests = new ArrayList<>();
        int idle;

        Store(JsonObject o) { radius = JsonUtil.clamp(JsonUtil.geti(o, "radius", 24), 4, 48); }

        @Override
        public void cancel(GnomeEntity g) { Util.leaveGhost(g); }

        @Override
        public void start(GnomeEntity g) {
            Level lv = g.level();
            BlockPos c = g.blockPosition();
            Set<Long> seen = new HashSet<>();
            BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
            int minY = Math.max(lv.getMinBuildHeight(), c.getY() - 16);
            int maxY = Math.min(lv.getMaxBuildHeight() - 1, c.getY() + 16);
            for (int x = c.getX() - radius; x <= c.getX() + radius; x++) {
                for (int y = minY; y <= maxY; y++) {
                    for (int z = c.getZ() - radius; z <= c.getZ() + radius; z++) {
                        mp.set(x, y, z);
                        BlockState s = lv.getBlockState(mp);
                        if (!(s.getBlock() instanceof ChestBlock cb)) continue;
                        if (seen.contains(mp.asLong())) continue;
                        BlockPos pos = mp.immutable();
                        seen.add(pos.asLong());
                        BlockPos partner = null;
                        if (s.getValue(ChestBlock.TYPE) != ChestType.SINGLE) {
                            partner = pos.relative(ChestBlock.getConnectedDirection(s));
                            seen.add(partner.asLong());
                        }
                        Container cont = ChestBlock.getContainer(cb, s, lv, pos, true);
                        if (cont == null) continue;
                        Ref r = new Ref();
                        r.pos = pos;
                        r.c = cont;
                        String lab = Util.label(lv, pos);
                        if (lab.isBlank() && partner != null) lab = Util.label(lv, partner);
                        r.label = lab.toLowerCase();
                        chests.add(r);
                    }
                }
            }
            if (chests.isEmpty()) throw new IllegalArgumentException("Не знайшов сундуків поруч.");
        }

        boolean done(GnomeEntity g, String msg) {
            g.say(msg);
            Util.leaveGhost(g);
            return true;
        }

        @Override
        public boolean tick(GnomeEntity g) {
            if (++idle < 4) return false;
            idle = 0;
            SimpleContainer inv = g.getInventory();
            int slot = -1;
            for (int i = 0; i < inv.getContainerSize(); i++) {
                if (!inv.getItem(i).isEmpty()) { slot = i; break; }
            }
            if (slot < 0) return done(g, "Усе розклав по сундуках.");
            ItemStack s = inv.getItem(slot);
            String cat = Categories.of(s).toLowerCase();
            // 1) сундуки з потрібною табличкою, 2) "Інше", 3) будь-які
            for (int pass = 0; pass < 3; pass++) {
                for (Ref r : chests) {
                    boolean ok = pass == 0 ? r.label.startsWith(cat)
                            : pass == 1 ? r.label.startsWith(Categories.OTHER.toLowerCase())
                            : true;
                    if (!ok) continue;
                    ItemStack rest = HopperBlockEntity.addItem(null, r.c, s.copy(), null);
                    if (rest.getCount() != s.getCount()) {
                        inv.setItem(slot, rest);
                        g.setBuildMode(true);
                        g.moveTo(r.pos.getX() + 0.5, r.pos.getY() + 1, r.pos.getZ() + 0.5);
                        return false;
                    }
                }
            }
            return done(g, "Сундуки заповнені, не все вдалося розкласти.");
        }
    }

    // ------------------------------------------------------------------ build
    public static class Build extends Task {
        final JsonObject spec;
        final BlockPos pp;
        final Direction face;
        HouseBuilder.Plan plan;
        int idx;

        Build(JsonObject o, ServerPlayer p) {
            spec = o;
            pp = p.blockPosition();
            face = p.getDirection();
        }

        @Override
        public void start(GnomeEntity g) {
            plan = HouseBuilder.plan((ServerLevel) g.level(), spec, pp, face);
            g.say("Починаю будівництво: " + plan.size() + " операцій.");
            for (String n : plan.notes) g.say(n);
            g.setBuildMode(true);
        }

        @Override
        public void cancel(GnomeEntity g) { g.setBuildMode(false); }

        @Override
        public boolean tick(GnomeEntity g) {
            ServerLevel lv = (ServerLevel) g.level();
            int budget = Config.BLOCKS_PER_TICK.get();
            int skips = 0;
            boolean req = Config.REQUIRE_MATERIALS.get();
            while (budget > 0 && idx < plan.size() && skips < 4000) {
                long key = plan.keys[idx];
                BlockState st = plan.states[idx];
                idx++;
                BlockPos pos = BlockPos.of(key);
                BlockState cur = lv.getBlockState(pos);
                if (cur == st || cur.is(net.minecraft.world.level.block.Blocks.BEDROCK)) {
                    skips++;
                    continue;
                }
                double dx = g.getX() - (pos.getX() + 0.5), dy = g.getY() - (pos.getY() + 2), dz = g.getZ() - (pos.getZ() + 0.5);
                if (dx * dx + dy * dy + dz * dz > 36) g.moveTo(pos.getX() + 0.5, pos.getY() + 2, pos.getZ() + 0.5);
                if (req && !st.isAir() && !(st.getBlock() instanceof BedBlock && st.getValue(BedBlock.PART) == BedPart.HEAD)) {
                    Item it = st.getBlock().asItem();
                    if (it == Items.AIR || !take(g, it)) {
                        g.say("Не вистачає матеріалів: " + ForgeRegistries.ITEMS.getKey(it)
                                + ". Дай мені ресурсів (клік по гному предметом) і повтори команду.");
                        g.setBuildMode(false);
                        return true;
                    }
                }
                lv.setBlock(pos, st, 3);
                budget--;
                Block b = st.getBlock();
                if (b instanceof FenceBlock || b instanceof IronBarsBlock || b instanceof WallBlock) {
                    BlockState ns = Block.updateFromNeighbourShapes(st, lv, pos);
                    if (ns != st) lv.setBlock(pos, ns, 2);
                }
                if (b instanceof WallSignBlock) {
                    String[] t = plan.signs.get(key);
                    if (t != null && lv.getBlockEntity(pos) instanceof SignBlockEntity sb) {
                        SignText tx = new SignText();
                        for (int i = 0; i < t.length && i < 4; i++) tx = tx.setMessage(i, Component.literal(t[i]));
                        sb.setText(tx, true);
                        sb.setChanged();
                        lv.sendBlockUpdated(pos, st, st, 3);
                    }
                }
            }
            if (idx >= plan.size()) {
                finish(g, lv);
                return true;
            }
            return false;
        }

        static boolean take(GnomeEntity g, Item it) {
            SimpleContainer inv = g.getInventory();
            for (int i = 0; i < inv.getContainerSize(); i++) {
                ItemStack s = inv.getItem(i);
                if (!s.isEmpty() && s.getItem() == it) {
                    s.shrink(1);
                    return true;
                }
            }
            return false;
        }

        void finish(GnomeEntity g, ServerLevel lv) {
            Random rnd = new Random();
            StringBuilder report = new StringBuilder();
            for (HouseBuilder.Pen pen : plan.pens) {
                AABB box = new AABB(pp).inflate(96, 80, 96);
                List<Animal> list = lv.getEntitiesOfClass(Animal.class, box, a -> {
                    var id = ForgeRegistries.ENTITY_TYPES.getKey(a.getType());
                    if (id == null || !id.toString().equals(pen.entity)) return false;
                    return !plan.bounds.contains(a.position());
                });
                list.sort((a, b) -> Double.compare(a.distanceToSqr(Vec3.atCenterOf(pp)), b.distanceToSqr(Vec3.atCenterOf(pp))));
                int moved = 0;
                for (Animal a : list) {
                    if (moved >= plan.animalsPer) break;
                    a.moveTo(pen.x + rnd.nextDouble() * 2 - 1, pen.y, pen.z + rnd.nextDouble() * 2 - 1, a.getYRot(), 0);
                    a.getNavigation().stop();
                    moved++;
                }
                report.append(pen.entity.replace("minecraft:", "")).append(": ").append(moved).append("; ");
            }
            g.setBuildMode(false);
            if (plan.doorOutside != null) {
                g.moveTo(plan.doorOutside.getX() + 0.5, plan.doorOutside.getY(), plan.doorOutside.getZ() + 0.5);
            }
            g.say("Будинок готовий!" + (report.length() > 0 ? " Привів тварин у загони — " + report : ""));
        }
    }
}
