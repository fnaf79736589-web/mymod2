package com.chatgnome;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GnomeRenderer extends MobRenderer<GnomeEntity, VillagerModel<GnomeEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation("textures/entity/villager/villager.png");

    public GnomeRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new VillagerModel<>(ctx.bakeLayer(ModelLayers.VILLAGER)), 0.4f);
    }

    @Override
    protected void scale(GnomeEntity entity, PoseStack stack, float partialTick) {
        stack.scale(0.8f, 0.8f, 0.8f);
    }

    @Override
    public ResourceLocation getTextureLocation(GnomeEntity entity) {
        return TEXTURE;
    }
}
