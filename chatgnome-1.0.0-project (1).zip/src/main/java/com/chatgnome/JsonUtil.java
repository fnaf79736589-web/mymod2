package com.chatgnome;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

final class JsonUtil {
    private JsonUtil() {}

    static boolean has(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull(); }

    static int geti(JsonObject o, String k, int d) {
        try { return has(o, k) ? o.get(k).getAsInt() : d; } catch (Exception e) { return d; }
    }

    static String gets(JsonObject o, String k, String d) {
        try { return has(o, k) ? o.get(k).getAsString() : d; } catch (Exception e) { return d; }
    }

    static boolean getb(JsonObject o, String k, boolean d) {
        try { return has(o, k) ? o.get(k).getAsBoolean() : d; } catch (Exception e) { return d; }
    }

    static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    static List<String> strList(JsonObject o, String k, boolean addNamespace) {
        List<String> r = new ArrayList<>();
        if (has(o, k) && o.get(k).isJsonArray()) {
            for (JsonElement e : o.getAsJsonArray(k)) {
                try {
                    String s = e.getAsString();
                    r.add(addNamespace && !s.contains(":") ? "minecraft:" + s : s);
                } catch (Exception ignored) { }
            }
        }
        return r;
    }

    static Block block(JsonObject o, String k, String d) {
        String s = gets(o, k, d);
        ResourceLocation rl = new ResourceLocation(s.contains(":") ? s : "minecraft:" + s);
        if (!ForgeRegistries.BLOCKS.containsKey(rl)) throw new IllegalArgumentException("Невідомий блок: " + s);
        return ForgeRegistries.BLOCKS.getValue(rl);
    }
}
