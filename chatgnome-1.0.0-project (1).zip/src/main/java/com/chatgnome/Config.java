package com.chatgnome;

import java.util.List;
import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    public static final ForgeConfigSpec.ConfigValue<String> API_KEY = B
            .comment("API ключ: Anthropic (sk-ant-...) або Google Gemini (AIza...) чи іншого сервісу.",
                    "Можна задати командою /gnome apikey <ключ> або змінними середовища ANTHROPIC_API_KEY / GEMINI_API_KEY")
            .define("apiKey", "");
    public static final ForgeConfigSpec.ConfigValue<String> PROVIDER = B
            .comment("auto = за ключем (sk-ant-... -> anthropic, інакше -> openai-сумісний, напр. Gemini).",
                    "Можливі значення: auto, anthropic, gemini, openai")
            .define("provider", "auto");

    public static final ForgeConfigSpec.ConfigValue<String> API_URL = B
            .comment("Anthropic: адреса")
            .define("apiUrl", "https://api.anthropic.com/v1/messages");
    public static final ForgeConfigSpec.ConfigValue<String> MODEL = B
            .comment("Anthropic: модель. Швидша/дешевша: claude-haiku-5-5")
            .define("model", "claude-sonnet-5-5");

    public static final ForgeConfigSpec.ConfigValue<String> COMPAT_URL = B
            .comment("Gemini / OpenAI-сумісний сервіс: адреса (для Gemini залиш як є).",
                    "Groq: https://api.groq.com/openai/v1/chat/completions",
                    "OpenRouter: https://openrouter.ai/api/v1/chat/completions",
                    "Ollama (локально): http://localhost:11434/v1/chat/completions")
            .define("compatUrl", "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions");
    public static final ForgeConfigSpec.ConfigValue<String> COMPAT_MODEL = B
            .comment("Gemini / OpenAI-сумісний сервіс: модель, напр. gemini-2.5-flash (актуальні назви дивись в Google AI Studio)")
            .define("compatModel", "gemini-2.5-flash");

    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> PREFIXES = B
            .comment("Повідомлення в чаті, що починаються з цих слів, адресуються гному")
            .defineList("chatPrefixes", List.of("гном", "гноме", "gnome"), o -> o instanceof String);
    public static final ForgeConfigSpec.IntValue BLOCKS_PER_TICK = B
            .comment("Скільки блоків гном ставить за тік під час будівництва")
            .defineInRange("blocksPerTick", 15, 1, 500);
    public static final ForgeConfigSpec.BooleanValue REQUIRE_MATERIALS = B
            .comment("true = гном витрачає блоки зі свого інвентаря при будівництві (треба спершу накопати/принести). false = будує безкоштовно")
            .define("requireMaterials", false);
    public static final ForgeConfigSpec.IntValue MAX_FLOORS = B
            .defineInRange("maxFloors", 40, 1, 80);

    public static final ForgeConfigSpec SPEC = B.build();

    /** true, якщо запити йдуть у форматі Anthropic; false — у форматі OpenAI (Gemini, Groq, OpenRouter, Ollama). */
    public static boolean useAnthropic() {
        String p = PROVIDER.get().trim().toLowerCase();
        if (p.equals("anthropic")) return true;
        if (p.equals("gemini") || p.equals("openai")) return false;
        String k = rawKey();
        return k.startsWith("sk-ant-") || (k.isEmpty() && System.getenv("GEMINI_API_KEY") == null);
    }

    private static String rawKey() {
        String k = API_KEY.get();
        return k == null ? "" : k.trim();
    }

    public static String apiKey() {
        String k = rawKey();
        if (!k.isEmpty()) return k;
        String env = System.getenv("ANTHROPIC_API_KEY");
        if (env == null || env.isBlank() || !useAnthropicEnvFirst()) env = System.getenv("GEMINI_API_KEY");
        if (env == null || env.isBlank()) env = System.getenv("ANTHROPIC_API_KEY");
        return env == null ? "" : env.trim();
    }

    private static boolean useAnthropicEnvFirst() {
        String p = PROVIDER.get().trim().toLowerCase();
        return p.equals("anthropic");
    }
}
