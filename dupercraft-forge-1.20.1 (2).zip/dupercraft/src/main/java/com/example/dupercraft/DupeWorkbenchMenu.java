package com.example.dupercraft;

import java.util.Optional;

import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.ResultSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;

/** Меню верстака з сіткою 9x9. Слоти: 0 = результат, 1..81 = сітка, 82..108 = інвентар, 109..117 = хотбар. */
public class DupeWorkbenchMenu extends AbstractContainerMenu {
    public static final int GRID = 9;
    public static final int GRID_SLOTS = GRID * GRID;
    public static final int GRID_X = 8;
    public static final int GRID_Y = 15;
    public static final int RESULT_X = 196;
    public static final int RESULT_Y = 87;
    public static final int INV_Y = 181;
    public static final int HOTBAR_Y = 239;
    private static final int INV_START = 1 + GRID_SLOTS;      // 82
    private static final int HOTBAR_START = INV_START + 27;   // 109
    private static final int END = HOTBAR_START + 9;          // 118

    private final CraftingContainer craftSlots = new TransientCraftingContainer(this, GRID, GRID);
    private final ResultContainer resultSlots = new ResultContainer();
    private final ContainerLevelAccess access;
    private final Player player;

    /** Клієнтський конструктор. */
    public DupeWorkbenchMenu(int id, Inventory inventory) {
        this(id, inventory, ContainerLevelAccess.NULL);
    }

    /** Серверний конструктор. */
    public DupeWorkbenchMenu(int id, Inventory inventory, ContainerLevelAccess access) {
        super(DuperCraft.WORKBENCH_MENU.get(), id);
        this.access = access;
        this.player = inventory.player;

        this.addSlot(new ResultSlot(inventory.player, this.craftSlots, this.resultSlots, 0, RESULT_X, RESULT_Y));
        for (int row = 0; row < GRID; ++row) {
            for (int col = 0; col < GRID; ++col) {
                this.addSlot(new Slot(this.craftSlots, col + row * GRID, GRID_X + col * 18, GRID_Y + row * 18));
            }
        }
        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, INV_Y + row * 18));
            }
        }
        for (int col = 0; col < 9; ++col) {
            this.addSlot(new Slot(inventory, col, 8 + col * 18, HOTBAR_Y));
        }
    }

    @Override
    public void slotsChanged(Container container) {
        this.access.execute((level, pos) -> {
            if (level.isClientSide || !(this.player instanceof ServerPlayer serverPlayer)) {
                return;
            }
            ItemStack result = ItemStack.EMPTY;
            Optional<DupeWorkbenchRecipe> recipe = level.getServer().getRecipeManager()
                    .getRecipeFor(DuperCraft.RECIPE_TYPE.get(), this.craftSlots, level);
            if (recipe.isPresent()) {
                DupeWorkbenchRecipe r = recipe.get();
                if (this.resultSlots.setRecipeUsed(level, serverPlayer, r)) {
                    result = r.assemble(this.craftSlots, level.registryAccess());
                }
            }
            this.resultSlots.setItem(0, result);
            this.setRemoteSlot(0, result);
            serverPlayer.connection.send(new ClientboundContainerSetSlotPacket(this.containerId, this.incrementStateId(), 0, result));
        });
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        this.access.execute((level, pos) -> this.clearContainer(player, this.craftSlots));
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(this.access, player, DuperCraft.WORKBENCH.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack copy = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            copy = stack.copy();
            if (index == 0) {
                this.access.execute((level, pos) -> stack.getItem().onCraftedBy(stack, level, player));
                if (!this.moveItemStackTo(stack, INV_START, END, true)) {
                    return ItemStack.EMPTY;
                }
                slot.onQuickCraft(stack, copy);
            } else if (index >= INV_START && index < END) {
                if (!this.moveItemStackTo(stack, 1, INV_START, false)) {
                    if (index < HOTBAR_START) {
                        if (!this.moveItemStackTo(stack, HOTBAR_START, END, false)) {
                            return ItemStack.EMPTY;
                        }
                    } else if (!this.moveItemStackTo(stack, INV_START, HOTBAR_START, false)) {
                        return ItemStack.EMPTY;
                    }
                }
            } else if (!this.moveItemStackTo(stack, INV_START, END, false)) {
                return ItemStack.EMPTY;
            }

            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == copy.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTake(player, stack);
            if (index == 0) {
                player.drop(stack, false);
            }
        }
        return copy;
    }

    @Override
    public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
        return slot.container != this.resultSlots && super.canTakeItemForPickAll(stack, slot);
    }
}
