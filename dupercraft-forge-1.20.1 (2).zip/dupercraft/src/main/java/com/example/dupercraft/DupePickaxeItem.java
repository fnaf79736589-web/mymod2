package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Кирка дюпера: шанс подвоїти здобич з блока (логіка в DupeEvents). */
public class DupePickaxeItem extends PickaxeItem {
    public DupePickaxeItem() {
        super(Tiers.NETHERITE, 1, -2.8F, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.pickaxe").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
