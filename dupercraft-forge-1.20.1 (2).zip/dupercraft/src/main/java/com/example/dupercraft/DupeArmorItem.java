package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Броня дюпера. Кожна деталь має власну здатність; повний комплект дає бонус. */
public class DupeArmorItem extends ArmorItem {
    public DupeArmorItem(ArmorItem.Type type) {
        super(DupeArmorMaterial.INSTANCE, type, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
    }

    /** Чи одягнений повний комплект. */
    public static boolean isFullSet(Player p) {
        return p.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof DupeArmorItem
                && p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof DupeArmorItem
                && p.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof DupeArmorItem
                && p.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof DupeArmorItem;
    }

    /** Накладає ефект і поновлює його, коли лишається мало часу (без миготіння). */
    private static void refresh(Player p, MobEffect effect, int amplifier, int minRemaining, int duration) {
        MobEffectInstance cur = p.getEffect(effect);
        if (cur == null || cur.getAmplifier() < amplifier || cur.getDuration() <= minRemaining) {
            p.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, true));
        }
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        if (level.isClientSide) {
            return;
        }
        switch (this.getType()) {
            case HELMET -> {
                refresh(player, MobEffects.NIGHT_VISION, 0, 260, 400);
                refresh(player, MobEffects.WATER_BREATHING, 0, 20, 60);
            }
            case CHESTPLATE -> magnet(level, player);
            case LEGGINGS -> {
                refresh(player, MobEffects.FIRE_RESISTANCE, 0, 20, 60);
                refresh(player, MobEffects.MOVEMENT_SPEED, 0, 20, 60);
            }
            case BOOTS -> refresh(player, MobEffects.JUMP, 1, 20, 60);
        }
    }

    /** Магніт: притягує предмети поруч. Присядьте, щоб вимкнути. */
    private static void magnet(Level level, Player player) {
        if (player.isShiftKeyDown() || player.isSpectator()) {
            return;
        }
        double r = DupeConfig.MAGNET_RADIUS.get();
        Vec3 target = player.position().add(0, player.getBbHeight() / 2.0, 0);
        List<ItemEntity> items = level.getEntitiesOfClass(ItemEntity.class, player.getBoundingBox().inflate(r), e -> e.isAlive());
        for (ItemEntity item : items) {
            Vec3 diff = target.subtract(item.position());
            if (diff.lengthSqr() < 0.3) {
                continue;
            }
            item.setDeltaMovement(diff.normalize().scale(0.35));
            item.hurtMarked = true; // синхронізація руху з клієнтом
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        String key = switch (this.getType()) {
            case HELMET -> "helmet";
            case CHESTPLATE -> "chestplate";
            case LEGGINGS -> "leggings";
            case BOOTS -> "boots";
        };
        tooltip.add(Component.translatable("tooltip.dupercraft." + key).withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
