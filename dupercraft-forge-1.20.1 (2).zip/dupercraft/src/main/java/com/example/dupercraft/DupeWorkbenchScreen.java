package com.example.dupercraft;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/** Екран верстака 9x9. Фон малюється кодом (без текстур), у стилі ванільного інтерфейсу. */
public class DupeWorkbenchScreen extends AbstractContainerScreen<DupeWorkbenchMenu> {
    public DupeWorkbenchScreen(DupeWorkbenchMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 224;
        this.imageHeight = 260;
        this.titleLabelX = 8;
        this.titleLabelY = 4;
        this.inventoryLabelY = -1000; // ховаємо напис "Інвентар", щоб влізти по висоті
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;
        int w = this.imageWidth;
        int h = this.imageHeight;

        // Панель
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFFC6C6C6);
        g.fill(x + 1, y + 1, x + w - 2, y + 3, 0xFFFFFFFF);
        g.fill(x + 1, y + 1, x + 3, y + h - 2, 0xFFFFFFFF);
        g.fill(x + 3, y + h - 3, x + w - 1, y + h - 1, 0xFF555555);
        g.fill(x + w - 3, y + 3, x + w - 1, y + h - 1, 0xFF555555);

        // Стрілка від сітки до результату
        int ay = y + DupeWorkbenchMenu.RESULT_Y + 7;
        int ax = x + DupeWorkbenchMenu.GRID_X + 9 * 18 + 6;
        g.fill(ax, ay + 1, ax + 12, ay + 3, 0xFF555555);
        g.fill(ax + 12, ay - 1, ax + 14, ay + 5, 0xFF555555);
        g.fill(ax + 14, ay, ax + 16, ay + 4, 0xFF555555);

        // Слоти
        for (Slot slot : this.menu.slots) {
            int sx = x + slot.x - 1;
            int sy = y + slot.y - 1;
            if (slot.index == 0) { // рамка результату більша
                drawSlot(g, sx - 4, sy - 4, 26);
            }
            drawSlot(g, sx, sy, 18);
        }
    }

    private static void drawSlot(GuiGraphics g, int sx, int sy, int size) {
        g.fill(sx, sy, sx + size, sy + size, 0xFF373737);
        g.fill(sx + 1, sy + 1, sx + size, sy + size, 0xFFFFFFFF);
        g.fill(sx + 1, sy + 1, sx + size - 1, sy + size - 1, 0xFF8B8B8B);
    }
}
