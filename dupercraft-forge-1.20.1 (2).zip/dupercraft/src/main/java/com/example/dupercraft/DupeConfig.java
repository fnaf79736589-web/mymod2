package com.example.dupercraft;

import net.minecraftforge.common.ForgeConfigSpec;

/** Налаштування (файл config/dupercraft-common.toml). */
public class DupeConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue PICKAXE_CHANCE;
    public static final ForgeConfigSpec.DoubleValue SWORD_CHANCE;
    public static final ForgeConfigSpec.DoubleValue SET_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue MAGNET_RADIUS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        PICKAXE_CHANCE = b.comment("Шанс (0..1), що кирка дюпера подвоїть здобич з блока.")
                .defineInRange("pickaxeDuplicateChance", 0.30, 0.0, 1.0);
        SWORD_CHANCE = b.comment("Шанс (0..1), що клинок дюпера подвоїть кожен предмет, який випав з моба.")
                .defineInRange("swordDuplicateChance", 0.30, 0.0, 1.0);
        SET_MULTIPLIER = b.comment("У скільки разів зростають шанси кирки й клинка, якщо одягнений повний комплект (шанс не перевищить 1).")
                .defineInRange("fullSetChanceMultiplier", 2.0, 1.0, 10.0);
        MAGNET_RADIUS = b.comment("Радіус магніту нагрудника, блоків.")
                .defineInRange("magnetRadius", 8, 1, 32);
        SPEC = b.build();
    }
}
