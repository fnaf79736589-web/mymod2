#!/usr/bin/env python3
"""Генерує текстури, моделі, рецепти, loot tables, теги й переклади для DuperCraft.
Запуск з кореня проєкту:  python3 tools/generate_assets.py   (потрібен Pillow)
Іконки предметів прості, їх можна замінити своїми PNG 16x16 у assets/dupercraft/textures/item/."""
import json, os, random
from PIL import Image, ImageDraw

MOD = "dupercraft"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
A = os.path.join(ROOT, "assets", MOD)
D = os.path.join(ROOT, "data", MOD)
random.seed(11)

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def noise(base, spread):
    return tuple(max(0, min(255, c + random.randint(-spread, spread))) for c in base)

# ====================== БЛОКИ: текстури ======================
def tex(name, painter):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    painter(img)
    p = os.path.join(A, "textures", "block", name + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

PLANK = (150, 110, 62); PURPLE = (110, 40, 170); GOLD = (245, 200, 60); OBS = (48, 26, 78)

def planks(img):
    for y in range(16):
        for x in range(16):
            c = noise(PLANK, 10)
            if y % 4 == 3:
                c = noise((105, 75, 40), 6)
            img.putpixel((x, y), c)

def wb_side(img):
    planks(img)
    for x in range(16):
        for y in (6, 7, 8):
            img.putpixel((x, y), noise(PURPLE, 8))
    for x in (0, 15):
        for y in range(16):
            img.putpixel((x, y), noise((70, 50, 28), 6))

def wb_top(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(PURPLE, 10))
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for gy in range(3):
        for gx in range(3):
            for dy in range(3):
                for dx in range(3):
                    x, y = 3 + gx * 4 + dx, 3 + gy * 4 + dy
                    img.putpixel((x, y), noise((30, 12, 55) if (dx, dy) != (1, 1) else (200, 160, 255), 6))

def chest_base(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(OBS, 8))

def chest_side(img):
    chest_base(img)
    for x in range(16):
        for y in (0, 1, 14, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(16):
        for x in (0, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(6, 11):
        for x in range(6, 10):
            img.putpixel((x, y), noise(GOLD, 6))
    img.putpixel((7, 8), (30, 20, 50, 255)); img.putpixel((8, 8), (30, 20, 50, 255))

def chest_top(img):
    chest_base(img)
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(5, 11):
        for x in range(5, 11):
            img.putpixel((x, y), noise((150, 70, 220), 10))

for n, f in [("dupe_workbench_top", wb_top), ("dupe_workbench_side", wb_side), ("dupe_workbench_bottom", planks),
             ("dupe_chest_top", chest_top), ("dupe_chest_side", chest_side), ("dupe_chest_bottom", chest_base)]:
    tex(n, f)

for b in ("dupe_workbench", "dupe_chest"):
    w(os.path.join(A, "models", "block", b + ".json"), {
        "parent": "minecraft:block/cube_bottom_top",
        "textures": {"top": f"{MOD}:block/{b}_top", "side": f"{MOD}:block/{b}_side", "bottom": f"{MOD}:block/{b}_bottom"}})
    w(os.path.join(A, "models", "item", b + ".json"), {"parent": f"{MOD}:block/{b}"})
    w(os.path.join(A, "blockstates", b + ".json"), {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(os.path.join(D, "loot_tables", "blocks", b + ".json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
w(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", "axe.json"),
  {"replace": False, "values": [f"{MOD}:dupe_workbench", f"{MOD}:dupe_chest"]})

# ====================== ПРЕДМЕТИ: іконки ======================
PAL = {"o": (30, 18, 48), "a": (120, 48, 180), "b": (195, 125, 245), "c": (72, 26, 118),
       "g": (250, 205, 70), "h": (125, 82, 46), "k": (82, 52, 26)}

def from_ascii(rows):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in PAL:
                img.putpixel((x, y), PAL[ch] + (255,))
    return img

def mirror(half_rows):          # половина (8 колонок) -> повна ширина 16
    return [r + r[::-1] for r in half_rows]

def blank(n): return ["." * 8] * n

helmet = mirror(blank(2) + ["..oooooo", ".oaaaaaa", "oabbbbbb", "oabaaaaa", "oabaaaaa", "oabaaaaa",
                            "oabggggg", "oabcooo.", "oabc....", "oaco....", "ooo....."] + blank(3))
chest = mirror(blank(1) + ["ooo.oooo", "oaaooaaa", "oabbaaaa", "oabbaaaa", "ooabaaaa", ".oabaaaa", ".oabgggg",
                           ".oabaaaa", ".oabaaaa", ".oabaaaa", ".oacaaaa", ".ooooooo"] + blank(3))
legs = mirror(blank(2) + ["oooooooo", "oaaaaaaa", "oabbaaaa", "oabggggg", "oabaaaao", "oabaaao.", "oabaao..",
                          "oabaao..", "oabaao..", "oabcao..", "oooooo.."] + blank(3))
boots = mirror(blank(4) + ["..oooo..", "..oaabo.", "..oaabo.", "..oaabo.", "..oaabo.", ".ooaaabo", "oaaaaabo",
                           "oabbbbbo", "ooooooo."] + blank(3))

def icon(name, img):
    p = os.path.join(A, "textures", "item", name + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

def outline(img):
    px = img.load(); out = img.copy(); o = out.load()
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0:
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and px[nx, ny][3] > 0:
                        o[x, y] = PAL["o"] + (255,); break
    return out

def pickaxe():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.line([(3, 13), (11, 5)], fill=PAL["h"] + (255,), width=2)             # руків'я
    d.line([(3, 13), (4, 12)], fill=PAL["k"] + (255,), width=1)
    d.line([(2, 7), (3, 4), (6, 2), (10, 2), (13, 5), (14, 9)], fill=PAL["a"] + (255,), width=2)  # голова
    d.line([(3, 6), (4, 4), (7, 3), (10, 3)], fill=PAL["b"] + (255,), width=1)
    d.point([(8, 7), (9, 6)], fill=PAL["g"] + (255,))
    return outline(img)

def sword():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.line([(13, 2), (6, 9)], fill=PAL["a"] + (255,), width=3)               # клинок
    d.line([(13, 1), (6, 8)], fill=PAL["b"] + (255,), width=1)
    d.line([(4, 7), (9, 12)], fill=PAL["g"] + (255,), width=2)               # гарда
    d.line([(7, 10), (2, 14)], fill=PAL["h"] + (255,), width=2)              # руків'я
    d.point([(1, 14)], fill=PAL["g"] + (255,))
    return outline(img)

def ingot():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.polygon([(2, 10), (5, 5), (14, 5), (11, 10)], fill=PAL["b"] + (255,))     # верх
    d.polygon([(2, 10), (11, 10), (11, 13), (2, 13)], fill=PAL["a"] + (255,))   # перед
    d.polygon([(11, 10), (14, 5), (14, 8), (11, 13)], fill=PAL["c"] + (255,))   # бік
    d.line([(4, 7), (11, 7)], fill=PAL["g"] + (255,))
    d.point([(6, 11), (8, 11)], fill=PAL["g"] + (255,))
    return outline(img)

icon("duperium_ingot", ingot())
icon("dupe_pickaxe", pickaxe()); icon("dupe_sword", sword())
icon("dupe_helmet", from_ascii(helmet)); icon("dupe_chestplate", from_ascii(chest))
icon("dupe_leggings", from_ascii(legs)); icon("dupe_boots", from_ascii(boots))

for it, parent in [("duperium_ingot", "item/generated"), ("dupe_pickaxe", "item/handheld"), ("dupe_sword", "item/handheld"), ("dupe_helmet", "item/generated"),
                   ("dupe_chestplate", "item/generated"), ("dupe_leggings", "item/generated"), ("dupe_boots", "item/generated")]:
    w(os.path.join(A, "models", "item", it + ".json"), {"parent": "minecraft:" + parent, "textures": {"layer0": f"{MOD}:item/{it}"}})

# Текстури броні на моделі (64x32): фіолетова з золотими смугами
for layer in (1, 2):
    img = Image.new("RGBA", (64, 32))
    for y in range(32):
        for x in range(64):
            base = (118, 46, 178)
            if y % 6 == 5: base = (245, 200, 70)
            elif (x + y) % 9 == 0: base = (84, 30, 130)
            img.putpixel((x, y), tuple(noise(base, 8)) + (255,))
    p = os.path.join(A, "textures", "models", "armor", f"dupe_layer_{layer}.png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

# ====================== РЕЦЕПТИ ======================
# Верстак дюпера: у ЗВИЧАЙНОМУ верстаку (3x3), дуже важкий
w(os.path.join(D, "recipes", "dupe_workbench.json"), {
    "type": "minecraft:crafting_shaped", "category": "misc",
    "pattern": ["NDN", "DBD", "NDN"],
    "key": {"N": {"item": "minecraft:netherite_ingot"}, "D": {"item": "minecraft:diamond_block"}, "B": {"item": "minecraft:beacon"}},
    "result": {"item": f"{MOD}:dupe_workbench"}})

def wb(name, pattern, key, result, count=1):
    r = {"item": result}
    if count > 1: r["count"] = count
    w(os.path.join(D, "recipes", name + ".json"), {"type": f"{MOD}:workbench", "category": "misc",
                                                    "pattern": pattern, "key": key, "result": r})

def it(i): return {"item": "minecraft:" + i}

def grid(rows, name):
    """Крапка = наповнювач (обсидіан). Перевіряємо, що рецепт 9x9 і жодна клітинка не порожня."""
    assert len(rows) == 9, name
    out = []
    for r in rows:
        assert len(r) == 9, (name, r)
        r = r.replace(".", "O")
        assert " " not in r, (name, r)
        out.append(r)
    assert sum(r.count("U") for r in out) >= 4, name + ": мало дюперію"
    return out

K = {  # спільні символи
    "O": it("obsidian"), "U": {"item": f"{MOD}:duperium_ingot"},
    "N": it("netherite_ingot"), "D": it("diamond_block"), "E": it("emerald_block"),
    "G": it("gold_block"), "S": it("nether_star"), "B": it("blaze_rod"),
}
def keys(*names, **extra):
    d = {k: K[k] for k in ("O", "U") + names}
    d.update(extra)
    return d

# --- Дюперій: ДУЖЕ важкий матеріал. Лише у верстаку дюпера, 81 предмет, виходить 4 злитки ---
RING = {4: "O", 3: "GR", 2: "DE", 1: "N", 0: "S"}
ring_rows = []
for r in range(9):
    row = ""
    for c in range(9):
        d = max(abs(r - 4), abs(c - 4))
        row += RING[d][(r + c) % 2] if len(RING[d]) == 2 else RING[d]
    ring_rows.append(row)
assert all(len(r) == 9 for r in ring_rows)
wb("duperium_ingot", ring_rows,
   {"O": it("obsidian"), "G": it("gold_block"), "R": it("redstone_block"), "D": it("diamond_block"),
    "E": it("emerald_block"), "N": it("netherite_ingot"), "S": it("nether_star")},
   f"{MOD}:duperium_ingot", count=4)

# --- Сундук-дюпер: 81 клітинка, 8 злитків дюперію ---
base = ["    S    ", "   GDG   ", "  GEEEG  ", " ODEXEDO ", "SGENCNEGS", " ODEXEDO ", "  GEEEG  ", "   GDG   ", "    S    "]
base = [r.replace(" ", ".") for r in base]
for (r, c) in ((0, 3), (0, 5), (8, 3), (8, 5), (3, 0), (5, 0), (3, 8), (5, 8)):
    row = list(base[r]); row[c] = "U"; base[r] = "".join(row)
wb("dupe_chest", grid(base, "dupe_chest"),
   keys("S", "G", "D", "E", "N", X=it("end_crystal"), C=it("ender_chest")), f"{MOD}:dupe_chest")

# --- Екіпіровка: 81 клітинка, дюперій у кожному рецепті ---
wb("dupe_pickaxe", grid([
    ".NDDUDDN.", "ND..U..DN", "N...S...N", "....B....", "...UBU...",
    "....B....", "....B....", "....B....", "....B...."], "pickaxe"),
   keys("N", "D", "S", "B"), f"{MOD}:dupe_pickaxe")
wb("dupe_sword", grid([
    "....U....", "....D....", "....D....", "....D....", "..NNSNN..",
    "....U....", "....B....", "....B....", "...UBU..."], "sword"),
   keys("N", "D", "S", "B"), f"{MOD}:dupe_sword")
wb("dupe_helmet", grid([
    "..NNNNN..", ".NDDUDDN.", "NDD.E.DDN", "ND.U.U.DN", "ND.....DN",
    "NU.....UN", "N.......N", ".........", "........."], "helmet"),
   keys("N", "D", E=it("ender_eye")), f"{MOD}:dupe_helmet")
wb("dupe_chestplate", grid([
    "NN.....NN", "NDD...DDN", "NDDDDDDDN", "NDDULUDDN", "NDDUDUDDN",
    ".NDDUDDN.", ".NDDDDDN.", "..NDDDN..", "...NNN..."], "chestplate"),
   keys("N", "D", L=it("lodestone")), f"{MOD}:dupe_chestplate")
wb("dupe_leggings", grid([
    "NNNNNNNNN", "NDDDUDDDN", "NDDMDMDDN", "ND.....DN", "ND.U.U.DN",
    "ND.....DN", "NDU...UDN", "ND.....DN", "NN.....NN"], "leggings"),
   keys("N", "D", M=it("magma_block")), f"{MOD}:dupe_leggings")
wb("dupe_boots", grid([
    ".........", ".NDDUDDN.", ".ND.L.DN.", ".ND...DN.", ".NDU.UDN.",
    ".ND...DN.", "NNDD.DDNN", "NDDDUDDDN", "NNNNNNNNN"], "boots"),
   keys("N", "D", L=it("slime_block")), f"{MOD}:dupe_boots")

# ====================== ПЕРЕКЛАДИ ======================
items = {   # id: (en, uk, ru)
    "duperium_ingot": ("Duperium Ingot", "Дюперієвий злиток", "Дюпериевый слиток"),
    "dupe_workbench": ("Dupe Workbench", "Верстак дюпера", "Верстак дюпера"),
    "dupe_chest": ("Dupe Chest", "Сундук-дюпер", "Сундук-дюпер"),
    "dupe_pickaxe": ("Duper's Pickaxe", "Кирка дюпера", "Кирка дюпера"),
    "dupe_sword": ("Duper's Blade", "Клинок дюпера", "Клинок дюпера"),
    "dupe_helmet": ("Duper's Visor", "Візор дюпера", "Визор дюпера"),
    "dupe_chestplate": ("Duper's Magnet Plate", "Магнітна кіраса дюпера", "Магнитный нагрудник дюпера"),
    "dupe_leggings": ("Duper's Cinder Greaves", "Вогнетривкі поножі дюпера", "Огнеупорные поножи дюпера"),
    "dupe_boots": ("Duper's Cushion Boots", "Амортизуючі черевики дюпера", "Амортизирующие ботинки дюпера"),
}
tips = {
 "en_us": {"pickaxe": "Chance to duplicate the drops of mined blocks", "sword": "Chance to duplicate items dropped by mobs",
           "helmet": "Night Vision and Water Breathing", "chestplate": "Pulls nearby items to you (sneak to disable)",
           "leggings": "Fire Resistance and Speed", "boots": "No fall damage, Jump Boost II",
           "set_bonus": "Full armor set: Regeneration, and Pickaxe/Blade chance x2",
           "duperium": "Crafted only at the Dupe Workbench (9x9)"},
 "uk_ua": {"pickaxe": "Шанс подвоїти здобич із зламаних блоків", "sword": "Шанс подвоїти предмети, що випали з мобів",
           "helmet": "Нічний зір і дихання під водою", "chestplate": "Притягує предмети поруч (присядьте, щоб вимкнути)",
           "leggings": "Вогнестійкість і швидкість", "boots": "Падіння без шкоди, стрибучість II",
           "set_bonus": "Повний комплект броні: регенерація і шанс кирки/клинка x2",
           "duperium": "Крафтиться лише у верстаку дюпера (9x9)"},
 "ru_ru": {"pickaxe": "Шанс удвоить добычу со сломанных блоков", "sword": "Шанс удвоить предметы, выпавшие из мобов",
           "helmet": "Ночное зрение и подводное дыхание", "chestplate": "Притягивает предметы рядом (присядьте, чтобы отключить)",
           "leggings": "Огнестойкость и скорость", "boots": "Падение без урона, прыгучесть II",
           "set_bonus": "Полный комплект брони: регенерация и шанс кирки/клинка x2",
           "duperium": "Крафтится только на верстаке дюпера (9x9)"},
}
for i, code in enumerate(("en_us", "uk_ua", "ru_ru")):
    d = {"itemGroup.dupercraft": "DuperCraft",
         "container.dupercraft.workbench": items["dupe_workbench"][i],
         "container.dupercraft.dupe_chest": items["dupe_chest"][i]}
    for k, v in items.items():
        d[("block." if k in ("dupe_workbench", "dupe_chest") else "item.") + f"{MOD}.{k}"] = v[i]
    for k, v in tips[code].items():
        d[f"tooltip.{MOD}.{k}"] = v
    w(os.path.join(A, "lang", code + ".json"), d)
print("Готово")
