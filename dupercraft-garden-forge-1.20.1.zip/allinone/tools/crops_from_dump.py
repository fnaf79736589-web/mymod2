#!/usr/bin/env python3
"""Додає в crops.json культури для предметів зі списку, який записав мод
(файл resourcecrops_industrialupgrade_items.txt у папці гри).

Аргументи після файлу: 'категорія/' (усі предмети категорії) або повний шлях 'категорія/предмет'.
Приклад:
  python3 tools/crops_from_dump.py items.txt itemingots/ alloyingot/ preciousgem/ glass/reinforced
Потім:  python3 tools/generate_assets.py
"""
import sys, json, os, hashlib, colorsys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "crops.json")
RARE = {"iridium","osmium","platinum","mithril","adamantium","draconid","bloodstone","orichalcum","polonium",
        "neodymium","thallium","palladium","osmiridium","meteoric_iron","uranium","gadolinium","hafnium","tantalum",
        "ruby","sapphire","topaz","superalloy_haynes","superalloy_rene","vitalium","stellite","zeliber"}

dump = sys.argv[1]
wanted = sys.argv[2:] or ["itemingots/"]
data = json.load(open(ROOT, encoding="utf-8"))
have_items = {c["item"] for c in data["crops"]}
have_names = {c["name"] for c in data["crops"]}

def base_name(path):
    cat, last = path.split("/", 1)[0], path.rsplit("/", 1)[-1]
    for suf in ("_ingot", "_gem"):
        if last.endswith(suf):
            last = last[: -len(suf)]
    if last == "reinforced":
        last = "reinforced_glass"
    return last

added = 0
for line in open(dump, encoding="utf-8"):
    rid = line.strip()
    if not rid.startswith("industrialupgrade:") or rid in have_items:
        continue
    path = rid.split(":", 1)[1]
    if not any(path.startswith(w) if w.endswith("/") else path == w for w in wanted):
        continue
    base = base_name(path)
    name = "iu_" + base.replace("-", "_").lower()
    if name in have_names:  # колізія імен -> додаємо категорію
        name = "iu_" + path.split("/")[0] + "_" + base
    h = int(hashlib.md5(path.encode()).hexdigest()[:6], 16)
    r, g, b = colorsys.hsv_to_rgb((h % 360) / 360, 0.45, 0.9)
    color = "#%02X%02X%02X" % (int(r * 255), int(g * 255), int(b * 255))
    cnt = [1, 2] if base in RARE else [2, 3]
    data["crops"].append({"name": name, "color": color, "item": rid, "count": cnt, "mod": "industrialupgrade"})
    have_items.add(rid); have_names.add(name); added += 1

json.dump(data, open(ROOT, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print(f"Додано {added} культур")
