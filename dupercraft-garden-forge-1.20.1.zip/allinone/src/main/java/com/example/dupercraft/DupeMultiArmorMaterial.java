package com.example.dupercraft;

import java.util.EnumMap;
import java.util.Map;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Матеріал мультброні: захист = сума всіх чотирьох деталей комплекту, міцність втричі більша за нагрудник. */
public class DupeMultiArmorMaterial implements ArmorMaterial {
    private static final Map<DupeArmorMaterial, DupeMultiArmorMaterial> CACHE = new EnumMap<>(DupeArmorMaterial.class);

    public static DupeMultiArmorMaterial of(DupeArmorMaterial base) {
        return CACHE.computeIfAbsent(base, DupeMultiArmorMaterial::new);
    }

    public final DupeArmorMaterial base;

    private DupeMultiArmorMaterial(DupeArmorMaterial base) {
        this.base = base;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return base.getDurabilityForType(ArmorItem.Type.CHESTPLATE) * 3;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        int sum = 0;
        for (ArmorItem.Type t : ArmorItem.Type.values()) {
            sum += base.getDefenseForType(t);
        }
        return sum;
    }

    @Override
    public int getEnchantmentValue() {
        return base.getEnchantmentValue();
    }

    @Override
    public SoundEvent getEquipSound() {
        return base.getEquipSound();
    }

    @Override
    public Ingredient getRepairIngredient() {
        return base.getRepairIngredient();
    }

    @Override
    public String getName() {
        return base.getName();
    }

    @Override
    public float getToughness() {
        return base.getToughness();
    }

    @Override
    public float getKnockbackResistance() {
        return base.getKnockbackResistance();
    }
}
