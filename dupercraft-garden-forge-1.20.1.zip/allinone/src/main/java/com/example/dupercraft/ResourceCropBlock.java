package com.example.dupercraft;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraftforge.registries.ForgeRegistries;

/** Культура, що росте як пшениця, але дає довільний предмет (з будь-якого моду). */
public class ResourceCropBlock extends CropBlock {
    private final CropDef def;
    private final Supplier<Item> seed;

    public ResourceCropBlock(CropDef def, Supplier<Item> seed) {
        super(BlockBehaviour.Properties.copy(Blocks.WHEAT));
        this.def = def;
        this.seed = seed;
    }

    @Override
    protected ItemLike getBaseSeedId() {
        return seed.get();
    }

    @Override
    public List<ItemStack> getDrops(BlockState state, LootParams.Builder builder) {
        List<ItemStack> drops = new ArrayList<>();
        RandomSource rand = builder.getLevel().random;

        // Насіння завжди повертається (можна пересаджувати).
        drops.add(new ItemStack(seed.get()));

        if (isMaxAge(state)) {
            // Предмет шукаємо під час збору, тож моди з іншим порядком завантаження не заважають.
            Item out = ForgeRegistries.ITEMS.getValue(def.item());
            if (out != null && out != Items.AIR) {
                int n = def.min() + rand.nextInt(def.max() - def.min() + 1);
                drops.add(new ItemStack(out, n));
            }
            if (rand.nextFloat() < 0.3F) {
                drops.add(new ItemStack(seed.get())); // бонусне насіння
            }
        }
        return drops;
    }
}
