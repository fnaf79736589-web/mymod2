package com.example.dupercraft;

import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = DuperCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(DuperCraft.WORKBENCH_MENU.get(), DupeWorkbenchScreen::new));
    }

    /** Фарбуємо шаблонні текстури культур у колір ресурсу. */
    @SubscribeEvent
    public static void blockColors(RegisterColorHandlersEvent.Block e) {
        for (CropDef d : DuperCraft.CROPS) {
            e.register((state, level, pos, tint) -> tint == 0 ? d.color() : -1,
                    DuperCraft.CROP_BLOCKS.get(d.name()).get());
        }
    }

    @SubscribeEvent
    public static void itemColors(RegisterColorHandlersEvent.Item e) {
        for (CropDef d : DuperCraft.CROPS) {
            e.register((stack, tint) -> tint == 0 ? 0xFF000000 | d.color() : -1,
                    DuperCraft.SEEDS.get(d.name()).get());
        }
    }
}
