package com.example.dupercraft;

import java.util.Map;
import java.util.TreeMap;

import com.mojang.brigadier.context.CommandContext;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

/** /selectionboost scan — показує блоки Industrial Upgrade навколо вас і чи можна їх прискорити. */
@Mod.EventBusSubscriber(modid = DuperCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BoostCommand {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dupercraft")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("scan").executes(BoostCommand::scan)));
    }

    private static int scan(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        Level level = src.getLevel();
        BlockPos origin = BlockPos.containing(src.getPosition());
        int r = 8;
        Map<String, int[]> found = new TreeMap<>(); // id -> {кількість, має BE, має тікер, випадковий тік}
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    if (!level.isLoaded(m)) {
                        continue;
                    }
                    BlockState s = level.getBlockState(m);
                    ResourceLocation key = ForgeRegistries.BLOCKS.getKey(s.getBlock());
                    if (key == null || !key.getNamespace().equals("industrialupgrade")) {
                        continue;
                    }
                    int[] info = found.computeIfAbsent(key.toString(), k -> new int[4]);
                    info[0]++;
                    BlockEntity be = level.getBlockEntity(m);
                    if (be != null) {
                        info[1] = 1;
                        if (TickUtil.ticker(level, s, be) != null) {
                            info[2] = 1;
                        }
                    }
                    if (s.isRandomlyTicking()) {
                        info[3] = 1;
                    }
                }
            }
        }
        if (found.isEmpty()) {
            src.sendSuccess(() -> Component.translatable("message.dupercraft.scan_none"), false);
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("message.dupercraft.scan_header"), false);
        for (Map.Entry<String, int[]> e : found.entrySet()) {
            int[] i = e.getValue();
            src.sendSuccess(() -> Component.translatable("message.dupercraft.scan_line",
                    e.getKey(), i[0], i[2] == 1 ? "ticker" : "-", i[3] == 1 ? "random" : "-"), false);
        }
        return found.size();
    }
}
