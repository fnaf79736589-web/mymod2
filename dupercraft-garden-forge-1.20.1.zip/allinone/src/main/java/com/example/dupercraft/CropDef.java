package com.example.dupercraft;

import net.minecraft.resources.ResourceLocation;

/** Опис однієї культури, прочитаний з crops.json. */
public record CropDef(String name, int color, ResourceLocation item, int min, int max, String mod) {
}
