package com.example.dupercraft;

import java.util.List;
import java.util.Locale;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;

/**
 * Мультиінструмент: кирка + сокира + лопата + мотика + клинок в одному предметі.
 * Копає все, має режими кирки (Shift+ПКМ у повітрі), лісоруб, екскаватор, збирає й садить культури,
 * знімає кору, перекопує землю, робить стежки; шанси подвоєння, вампіризм і досвід як у клинка.
 */
public class DupeMultiToolItem extends DiggerItem {
    /** Блоки, які копає мультиінструмент: об'єднання кирки, сокири, лопати й мотики. */
    public static final TagKey<Block> MINEABLE = TagKey.create(Registries.BLOCK, new ResourceLocation(DuperCraft.MODID, "multitool_mineable"));

    public final DupeTier gear;
    /** Здібність комплекту; null = всеосяжний мультиінструмент (здібність обирається Shift+ПКМ по блоку). */
    public final ToolAbility fixedAbility;

    public DupeMultiToolItem(DupeTier tier, ToolAbility ability) {
        super(3.0F, -2.4F, tier, MINEABLE, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
        this.gear = tier;
        this.fixedAbility = ability;
    }

    public boolean isOmni() {
        return fixedAbility == null;
    }

    /** Поточна здібність: у звичайного мультиінструмента одна, у всеосяжного обирається. */
    public ToolAbility ability(ItemStack stack) {
        if (fixedAbility != null) {
            return fixedAbility;
        }
        int i = stack.hasTag() ? stack.getTag().getInt("DupeAbility") : 0;
        return ToolAbility.values()[Math.floorMod(i, ToolAbility.values().length)];
    }

    public DupePickaxeItem.Mode getMode(ItemStack stack) {
        return GearUtil.getMode(stack, gear.rank);
    }

    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        return ToolActions.DEFAULT_PICKAXE_ACTIONS.contains(action) || ToolActions.DEFAULT_AXE_ACTIONS.contains(action)
                || ToolActions.DEFAULT_SHOVEL_ACTIONS.contains(action) || ToolActions.DEFAULT_HOE_ACTIONS.contains(action)
                || ToolActions.DEFAULT_SWORD_ACTIONS.contains(action);
    }

    /** ПКМ по блоку: збір культур, а далі дії сокири (кора), лопати (стежка), мотики (грядка). */
    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player user = context.getPlayer();
        if (isOmni() && user != null && user.isShiftKeyDown()) {
            if (!context.getLevel().isClientSide) {
                ItemStack stack = context.getItemInHand();
                int next = (ability(stack).ordinal() + 1) % ToolAbility.values().length;
                stack.getOrCreateTag().putInt("DupeAbility", next);
                user.displayClientMessage(Component.translatable("message.dupercraft.ability",
                        Component.translatable("ability.dupercraft." + ToolAbility.values()[next].key)), true);
            }
            return InteractionResult.sidedSuccess(context.getLevel().isClientSide);
        }
        if (context.getLevel().getBlockState(context.getClickedPos()).getBlock() instanceof CropBlock) {
            return DupeHoeItem.harvest(context, gear);
        }
        InteractionResult result = Items.NETHERITE_AXE.useOn(context);
        if (result != InteractionResult.PASS) {
            return result;
        }
        result = Items.NETHERITE_SHOVEL.useOn(context);
        if (result != InteractionResult.PASS) {
            return result;
        }
        return Items.NETHERITE_HOE.useOn(context);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        InteractionResultHolder<ItemStack> cycled = GearUtil.cycleMode(level, player, hand, gear.rank);
        if (cycled != null) {
            return cycled;
        }
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            if (serverPlayer.getCooldowns().isOnCooldown(this)) {
                return InteractionResultHolder.fail(stack);
            }
            ToolAbility ability = ability(stack);
            if (ability.activate(serverPlayer, gear)) {
                serverPlayer.getCooldowns().addCooldown(this, ability.cooldown);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        GearUtil.selfRepair(stack, entity, gear.rank);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.multitool").withStyle(ChatFormatting.LIGHT_PURPLE));
        int percent = (int) Math.round(Math.min(1.0, DupeConfig.PICKAXE_CHANCE.get() * gear.chanceMult) * 100);
        tooltip.add(Component.translatable("tooltip.dupercraft.chance", percent).withStyle(ChatFormatting.GREEN));
        ToolAbility ability = ability(stack);
        tooltip.add(Component.translatable("tooltip.dupercraft.ability", Component.translatable("ability.dupercraft." + ability.key))
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("ability_desc.dupercraft." + ability.key).withStyle(ChatFormatting.GRAY));
        if (isOmni()) {
            tooltip.add(Component.translatable("tooltip.dupercraft.omni_hint").withStyle(ChatFormatting.DARK_GRAY));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.mode",
                Component.translatable("mode.dupercraft." + getMode(stack).name().toLowerCase(Locale.ROOT))).withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.dupercraft.mode_hint").withStyle(ChatFormatting.DARK_GRAY));
        if (gear.rank >= 3) {
            tooltip.add(Component.translatable("tooltip.dupercraft.autopickup").withStyle(ChatFormatting.DARK_GREEN));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", gear.rank).withStyle(ChatFormatting.AQUA));
        if (gear.rank >= 2) {
            tooltip.add(Component.translatable("tooltip.dupercraft.repair").withStyle(ChatFormatting.DARK_AQUA));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
