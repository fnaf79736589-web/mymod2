package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Мотика дюпера: ПКМ по культурі збирає всі стиглі культури в області (за замовчуванням 5x5),
 * садить їх знову і з шансом подвоює здобич. Працює зі своїми та ванільними культурами.
 * По землі працює як звичайна мотика.
 */
public class DupeHoeItem extends HoeItem {
    public DupeHoeItem() {
        super(Tiers.NETHERITE, -4, 0.0F, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos center = context.getClickedPos();
        if (!(level.getBlockState(center).getBlock() instanceof CropBlock)) {
            return super.useOn(context); // звичайна обробка землі
        }
        if (!(level instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        ItemStack hoe = context.getItemInHand();
        int r = DupeConfig.HOE_RADIUS.get();
        double chance = player == null ? DupeConfig.HOE_CHANCE.get() : DupeEvents.chance(DupeConfig.HOE_CHANCE.get(), player);
        int harvested = 0;

        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                BlockPos p = center.offset(dx, 0, dz);
                BlockState state = server.getBlockState(p);
                if (!(state.getBlock() instanceof CropBlock crop) || !crop.isMaxAge(state)) {
                    continue;
                }
                List<ItemStack> drops = Block.getDrops(state, server, p, server.getBlockEntity(p), player, hoe);
                server.setBlock(p, crop.getStateForAge(0), 3); // садимо знову
                for (ItemStack drop : drops) {
                    Block.popResource(server, p, drop);
                    if (server.random.nextDouble() < chance) {
                        Block.popResource(server, p, drop.copy());
                    }
                }
                harvested++;
            }
        }
        if (harvested == 0) {
            return InteractionResult.PASS;
        }
        server.playSound(null, center, SoundEvents.CROP_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);
        if (player != null) {
            hoe.hurtAndBreak(1, player, pl -> pl.broadcastBreakEvent(context.getHand()));
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.hoe").withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
