package com.example.dupercraft;

import net.minecraftforge.common.ForgeConfigSpec;

/** Налаштування (файл config/dupercraft-common.toml). */
public class DupeConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue PICKAXE_CHANCE;
    public static final ForgeConfigSpec.DoubleValue SWORD_CHANCE;
    public static final ForgeConfigSpec.DoubleValue SET_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue MAGNET_RADIUS;
    public static final ForgeConfigSpec.DoubleValue HOE_CHANCE;
    public static final ForgeConfigSpec.IntValue HOE_RADIUS;
    public static final ForgeConfigSpec.DoubleValue SET_CROP_CHANCE;
    public static final ForgeConfigSpec.IntValue FERTILIZER_RADIUS;
    public static final ForgeConfigSpec.DoubleValue TOTEM_KEEP_CHANCE;
    public static final ForgeConfigSpec.BooleanValue SINGULAR_FLIGHT;
    public static final ForgeConfigSpec.IntValue REPAIR_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue LIFESTEAL;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        PICKAXE_CHANCE = b.comment("Шанс (0..1), що кирка дюпера подвоїть здобич з блока.")
                .defineInRange("pickaxeDuplicateChance", 0.30, 0.0, 1.0);
        SWORD_CHANCE = b.comment("Шанс (0..1), що клинок дюпера подвоїть кожен предмет, який випав з моба.")
                .defineInRange("swordDuplicateChance", 0.30, 0.0, 1.0);
        SET_MULTIPLIER = b.comment("У скільки разів зростають шанси кирки й клинка, якщо одягнений повний комплект (шанс не перевищить 1).")
                .defineInRange("fullSetChanceMultiplier", 2.0, 1.0, 10.0);
        MAGNET_RADIUS = b.comment("Радіус магніту нагрудника, блоків.")
                .defineInRange("magnetRadius", 8, 1, 32);
        HOE_CHANCE = b.comment("Шанс (0..1), що мотика дюпера подвоїть здобич кожної зібраної культури.")
                .defineInRange("hoeDuplicateChance", 0.30, 0.0, 1.0);
        HOE_RADIUS = b.comment("Радіус збору мотики дюпера: 2 = область 5x5.")
                .defineInRange("hoeRadius", 2, 0, 6);
        SET_CROP_CHANCE = b.comment("Шанс (0..1), що з культури, зламаної в повному комплекті броні дюпера, випаде подвійна здобич.")
                .defineInRange("fullSetCropDuplicateChance", 0.25, 0.0, 1.0);
        FERTILIZER_RADIUS = b.comment("Радіус дії дюперієвого добрива: 1 = область 3x3.")
                .defineInRange("fertilizerRadius", 1, 0, 4);
        TOTEM_KEEP_CHANCE = b.comment("Шанс (0..1), що Тотем подвоєння НЕ зникне після порятунку від смерті.")
                .defineInRange("totemKeepChance", 0.5, 0.0, 1.0);
        SINGULAR_FLIGHT = b.comment("Чи дає повний комплект сингуларію політ (як у творчому режимі).")
                .define("singularFlight", true);
        REPAIR_INTERVAL = b.comment("Раз на скільки тактів інструменти й броня 2-4 рівнів самі відновлюють міцність (0 = вимкнено).")
                .defineInRange("selfRepairIntervalTicks", 100, 0, 2400);
        LIFESTEAL = b.comment("Частка завданої клинком шкоди, що лікує власника, на кожен рівень (0.04 = 4% за рівень).")
                .defineInRange("swordLifestealPerTier", 0.04, 0.0, 0.5);
        SPEC = b.build();
    }
}
