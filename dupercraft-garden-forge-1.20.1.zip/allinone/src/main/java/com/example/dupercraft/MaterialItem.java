package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Злиток-матеріал: світиться як зачарований і має підказку про те, як його отримати. */
public class MaterialItem extends Item {
    private final String tooltipKey;

    public MaterialItem(Rarity rarity, String tooltipKey) {
        super(new Item.Properties().rarity(rarity).fireResistant());
        this.tooltipKey = tooltipKey;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(tooltipKey).withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
