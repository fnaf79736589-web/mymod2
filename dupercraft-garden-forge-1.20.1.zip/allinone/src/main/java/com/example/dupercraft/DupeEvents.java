package com.example.dupercraft;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Унікальні механіки екіпіровки та предметів дюпера. */
@Mod.EventBusSubscriber(modid = DuperCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DupeEvents {

    /** Шанс з урахуванням бонусу повного комплекту броні. */
    public static double chance(double base, Player player) {
        if (ToolAbility.isBurstActive(player)) {
            return 1.0; // Сплеск подвоєння: усе подвоюється
        }
        double c = base;
        if (DupeArmorItem.isFullSet(player)) {
            c *= DupeConfig.SET_MULTIPLIER.get();
        }
        return Math.min(1.0, c);
    }

    // =====================  ІНСТРУМЕНТИ: копання  =====================

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (!(event.getLevel() instanceof ServerLevel level) || !(player instanceof ServerPlayer sp) || player.isCreative()) {
            return;
        }
        ItemStack tool = player.getMainHandItem();
        BlockState state = event.getState();
        BlockPos pos = event.getPos();

        // Повний комплект броні: шанс подвійної здобичі зі стиглих культур
        if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)
                && ((DupeArmorItem.isFullSet(player) && level.random.nextDouble() < DupeConfig.SET_CROP_CHANCE.get())
                || (AmuletEvents.has(player, DuperCraft.TERRANIUM_AMULET) && level.random.nextDouble() < 0.25))) {
            for (ItemStack drop : Block.getDrops(state, level, pos, level.getBlockEntity(pos), player, tool)) {
                Block.popResource(level, pos, drop);
            }
        }

        // Які можливості має інструмент у руці
        DupeTier gear;
        boolean pickCap = false;
        boolean axeCap = false;
        boolean shovelCap = false;
        if (tool.getItem() instanceof DupePickaxeItem pickItem) {
            gear = pickItem.gear;
            pickCap = true;
        } else if (tool.getItem() instanceof DupeAxeItem axeItem) {
            gear = axeItem.gear;
            axeCap = true;
        } else if (tool.getItem() instanceof DupeShovelItem shovelItem) {
            gear = shovelItem.gear;
            shovelCap = true;
        } else if (tool.getItem() instanceof DupeMultiToolItem multiItem) {
            gear = multiItem.gear;
            pickCap = axeCap = shovelCap = true;
        } else {
            return;
        }

        int rank = gear.rank;
        boolean hasEntity = level.getBlockEntity(pos) != null;
        boolean sneaking = player.isShiftKeyDown();
        double dup = chance(DupeConfig.PICKAXE_CHANCE.get() * gear.chanceMult, player);

        if (pickCap && state.is(BlockTags.MINEABLE_WITH_PICKAXE)) {
            if (!player.hasCorrectToolForDrops(state)) {
                return;
            }
            DupePickaxeItem.Mode mode = GearUtil.getMode(tool, rank);
            boolean auto = rank >= 3;
            if (!hasEntity && !sneaking && (mode != DupePickaxeItem.Mode.NORMAL || auto)) {
                List<BlockPos> targets;
                switch (mode) {
                    case TUNNEL -> targets = GearUtil.plane(level, pos, GearUtil.faceOf(player), rank >= 4 ? 2 : 1,
                            s -> s.is(BlockTags.MINEABLE_WITH_PICKAXE));
                    case VEIN -> targets = GearUtil.connected(level, pos, s -> s.is(state.getBlock()), rank >= 4 ? 128 : 64);
                    default -> targets = List.of(pos);
                }
                event.setCanceled(true);
                GearUtil.breakBlocks(level, sp, tool, targets, mode == DupePickaxeItem.Mode.SMELT, dup, auto);
                return;
            }
            duplicateDrops(level, player, tool, state, pos, dup);
            return;
        }
        if (axeCap && state.is(BlockTags.LOGS)) {
            if (!hasEntity && !sneaking) {
                // Лісоруб: валить усе дерево (32/64/128/256 колод за рівнем)
                List<BlockPos> targets = GearUtil.connected(level, pos, s -> s.is(BlockTags.LOGS), 32 << (rank - 1));
                event.setCanceled(true);
                GearUtil.breakBlocks(level, sp, tool, targets, false, dup, rank >= 3);
                return;
            }
            duplicateDrops(level, player, tool, state, pos, dup);
            return;
        }
        if (shovelCap && state.is(BlockTags.MINEABLE_WITH_SHOVEL)) {
            if (!hasEntity && !sneaking && rank >= 2) {
                // Екскаватор: 3x3 (5x5 на 4-му рівні)
                List<BlockPos> targets = GearUtil.plane(level, pos, GearUtil.faceOf(player), rank >= 4 ? 2 : 1,
                        s -> s.is(BlockTags.MINEABLE_WITH_SHOVEL));
                event.setCanceled(true);
                GearUtil.breakBlocks(level, sp, tool, targets, false, dup, rank >= 3);
                return;
            }
            duplicateDrops(level, player, tool, state, pos, dup);
            return;
        }
        if (player.hasCorrectToolForDrops(state)) {
            duplicateDrops(level, player, tool, state, pos, dup);
        }
    }

    private static void duplicateDrops(ServerLevel level, Player player, ItemStack tool, BlockState state, BlockPos pos, double chance) {
        if (level.random.nextDouble() >= chance) {
            return;
        }
        for (ItemStack drop : Block.getDrops(state, level, pos, level.getBlockEntity(pos), player, tool)) {
            Block.popResource(level, pos, drop);
        }
    }

    // =====================  КЛИНОК  =====================

    /** Рівень, якщо в руці клинок або мультиінструмент (інакше null). */
    private static DupeTier bladeTier(ItemStack stack) {
        if (stack.getItem() instanceof DupeSwordItem sword) {
            return sword.gear;
        }
        if (stack.getItem() instanceof DupeMultiToolItem multi) {
            return multi.gear;
        }
        return null;
    }

    /** Здобич з мобів: шанс подвоїти кожен предмет. */
    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player) || player.level().isClientSide) {
            return;
        }
        DupeTier blade = bladeTier(player.getMainHandItem());
        if (blade == null) {
            return;
        }
        Level level = event.getEntity().level();
        double chance = chance(DupeConfig.SWORD_CHANCE.get() * blade.chanceMult, player);
        List<ItemEntity> extra = new ArrayList<>();
        for (ItemEntity drop : event.getDrops()) {
            if (level.random.nextDouble() < chance) {
                ItemEntity copy = new ItemEntity(level, drop.getX(), drop.getY(), drop.getZ(), drop.getItem().copy());
                copy.setDefaultPickUpDelay();
                extra.add(copy);
            }
        }
        event.getDrops().addAll(extra);
    }

    /** Вампіризм: частина завданої шкоди лікує власника клинка. */
    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        // Захист мультброні: «Горизонт подій» обмежує удар і відбиває частину шкоди
        if (event.getEntity() instanceof Player victim && !victim.level().isClientSide
                && DupeMultiArmorItem.abilitiesOf(victim).contains(ArmorAbility.HORIZON)) {
            if (event.getAmount() > 10.0F) {
                event.setAmount(10.0F);
            }
            DamageSource source = event.getSource();
            if (source.getEntity() instanceof LivingEntity attacker && attacker != victim && !source.is(DamageTypes.THORNS)) {
                attacker.hurt(victim.damageSources().thorns(victim), event.getAmount() * 0.25F);
            }
        }

        if (event.getSource().getEntity() instanceof Player player && !player.level().isClientSide) {
            DupeTier blade = bladeTier(player.getMainHandItem());
            if (blade != null) {
                player.heal((float) (event.getAmount() * DupeConfig.LIFESTEAL.get() * blade.rank));
            }
        }
    }

    /** Пасивні здібності мультброні: ухилення, імунітет до снарядів і вибухів. */
    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) {
            return;
        }
        Set<ArmorAbility> abilities = DupeMultiArmorItem.abilitiesOf(player);
        if (abilities.isEmpty()) {
            return;
        }
        DamageSource source = event.getSource();
        if (abilities.contains(ArmorAbility.WARD) && source.is(DamageTypeTags.IS_PROJECTILE)) {
            event.setCanceled(true);
        } else if (abilities.contains(ArmorAbility.ANCHOR) && source.is(DamageTypeTags.IS_EXPLOSION)) {
            event.setCanceled(true);
        } else if (abilities.contains(ArmorAbility.MIRROR) && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                && player.getRandom().nextFloat() < 0.15F) {
            event.setCanceled(true);
            player.level().broadcastEntityEvent(player, (byte) 46); // частинки телепорту
        }
    }

    /** Бонус досвіду за вбивства клинком: +50% за рівень. */
    @SubscribeEvent
    public static void onExperienceDrop(LivingExperienceDropEvent event) {
        Player killer = event.getAttackingPlayer();
        DupeTier blade = killer == null ? null : bladeTier(killer.getMainHandItem());
        if (blade != null) {
            event.setDroppedExperience((int) (event.getDroppedExperience() * (1.0 + 0.5 * blade.rank)));
        }
    }

    // =====================  БРОНЯ  =====================

    /** Черевики: падіння без шкоди. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player player
                && (player.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof DupeArmorItem
                || player.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof DupeMultiArmorItem)) {
            event.setDamageMultiplier(0.0F);
        }
    }

    /** «Якір порожнечі»: падіння під світ повертає гравця до місця відродження. */
    private static void voidAnchor(Player player) {
        if (!(player instanceof ServerPlayer sp) || !(sp.level() instanceof ServerLevel level)
                || sp.getY() >= level.getMinBuildHeight() - 8
                || !DupeMultiArmorItem.abilitiesOf(sp).contains(ArmorAbility.ANCHOR)) {
            return;
        }
        BlockPos spawn = sp.getRespawnPosition() != null && sp.getRespawnDimension() == level.dimension()
                ? sp.getRespawnPosition() : level.getSharedSpawnPos();
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, spawn.getX(), spawn.getZ());
        if (y <= level.getMinBuildHeight()) {
            y = spawn.getY();
        }
        sp.fallDistance = 0.0F;
        sp.setDeltaMovement(Vec3.ZERO);
        sp.teleportTo(spawn.getX() + 0.5, y, spawn.getZ() + 0.5);
    }

    private static final String FLIGHT_TAG = "dupercraft_flight";

    /** Бонус комплекту (регенерація, поглинання) і політ сингуларію. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        Player player = event.player;
        if (event.phase != TickEvent.Phase.END || player.level().isClientSide) {
            return;
        }
        voidAnchor(player);
        if (player.tickCount % 10 != 0) {
            return;
        }
        int tier = DupeArmorItem.setTier(player);
        if (tier > 0 && player.tickCount % 20 == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, tier >= 3 ? 1 : 0, true, false, true));
            if (tier >= 2) {
                player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 60, tier - 2, true, false, true));
            }
        }
        updateFlight(player, tier);
    }

    /** Повний комплект сингуларію дає творчий політ; при зніманні політ забирається. */
    private static void updateFlight(Player player, int tier) {
        CompoundTag data = player.getPersistentData();
        boolean should = DupeConfig.SINGULAR_FLIGHT.get() && tier >= 4;
        boolean granted = data.getBoolean(FLIGHT_TAG);
        if (should) {
            if (!player.getAbilities().mayfly) {
                player.getAbilities().mayfly = true;
                data.putBoolean(FLIGHT_TAG, true);
                player.onUpdateAbilities();
            }
        } else if (granted) {
            data.putBoolean(FLIGHT_TAG, false);
            if (!player.isCreative() && !player.isSpectator()) {
                player.getAbilities().mayfly = false;
                player.getAbilities().flying = false;
                player.onUpdateAbilities();
            }
        }
    }

    // =====================  ТОТЕМ ПОДВОЄННЯ  =====================

    /** Тотем у будь-якому слоті інвентаря рятує від смерті; з шансом не зникає. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        ItemStack totem = findTotem(player);
        if (totem.isEmpty()) {
            return;
        }
        event.setCanceled(true);
        player.setHealth(player.getMaxHealth() * 0.5F);
        player.removeAllEffects();
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
        player.level().broadcastEntityEvent(player, (byte) 35); // анімація тотема
        if (player.getRandom().nextDouble() >= DupeConfig.TOTEM_KEEP_CHANCE.get()) {
            totem.shrink(1);
        }
    }

    private static ItemStack findTotem(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(DuperCraft.DUPE_TOTEM.get())) {
                return s;
            }
        }
        ItemStack off = player.getOffhandItem();
        return off.is(DuperCraft.DUPE_TOTEM.get()) ? off : ItemStack.EMPTY;
    }
}
