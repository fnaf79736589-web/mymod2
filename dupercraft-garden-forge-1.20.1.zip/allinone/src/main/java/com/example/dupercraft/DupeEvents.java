package com.example.dupercraft;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Унікальні механіки екіпіровки дюпера. */
@Mod.EventBusSubscriber(modid = DuperCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class DupeEvents {

    public static double chance(double base, Player player) {
        double c = base;
        if (DupeArmorItem.isFullSet(player)) {
            c *= DupeConfig.SET_MULTIPLIER.get();
        }
        return Math.min(1.0, c);
    }

    /** Кирка: шанс подвоїти здобич з блока. */
    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (!(event.getLevel() instanceof ServerLevel level) || player.isCreative()) {
            return;
        }
        ItemStack tool = player.getMainHandItem();
        BlockState brokenState = event.getState();
        // Повний комплект броні: шанс подвійної здобичі з культур (власних і ванільних)
        if (brokenState.getBlock() instanceof CropBlock crop && crop.isMaxAge(brokenState) && DupeArmorItem.isFullSet(player)
                && level.random.nextDouble() < DupeConfig.SET_CROP_CHANCE.get()) {
            BlockPos cropPos = event.getPos();
            for (ItemStack drop : Block.getDrops(brokenState, level, cropPos, level.getBlockEntity(cropPos), player, tool)) {
                Block.popResource(level, cropPos, drop);
            }
        }
        if (!(tool.getItem() instanceof DupePickaxeItem)) {
            return;
        }
        BlockState state = event.getState();
        if (!player.hasCorrectToolForDrops(state)) {
            return;
        }
        if (level.random.nextDouble() >= chance(DupeConfig.PICKAXE_CHANCE.get(), player)) {
            return;
        }
        BlockPos pos = event.getPos();
        for (ItemStack drop : Block.getDrops(state, level, pos, level.getBlockEntity(pos), player, tool)) {
            Block.popResource(level, pos, drop);
        }
    }

    /** Клинок: шанс подвоїти кожен предмет, що випав з моба. */
    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        if (!(event.getSource().getEntity() instanceof Player player) || player.level().isClientSide) {
            return;
        }
        if (!(player.getMainHandItem().getItem() instanceof DupeSwordItem)) {
            return;
        }
        Level level = event.getEntity().level();
        double chance = chance(DupeConfig.SWORD_CHANCE.get(), player);
        List<ItemEntity> extra = new ArrayList<>();
        for (ItemEntity drop : event.getDrops()) {
            if (level.random.nextDouble() < chance) {
                ItemEntity copy = new ItemEntity(level, drop.getX(), drop.getY(), drop.getZ(), drop.getItem().copy());
                copy.setDefaultPickUpDelay();
                extra.add(copy);
            }
        }
        event.getDrops().addAll(extra);
    }

    /** Черевики: падіння без шкоди. */
    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntity() instanceof Player player
                && player.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET).getItem() instanceof DupeArmorItem) {
            event.setDamageMultiplier(0.0F);
        }
    }

    /** Бонус повного комплекту: постійна регенерація. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        Player player = event.player;
        if (event.phase != TickEvent.Phase.END || player.level().isClientSide || player.tickCount % 20 != 0) {
            return;
        }
        if (DupeArmorItem.isFullSet(player)) {
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true));
        }
    }
}
