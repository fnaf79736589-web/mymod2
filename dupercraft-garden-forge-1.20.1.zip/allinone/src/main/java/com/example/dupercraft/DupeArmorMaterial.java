package com.example.dupercraft;

import java.util.function.Supplier;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.crafting.Ingredient;

/** Матеріали броні: дюперій, ефіріум, войдіум, сингуларій. Текстури: textures/models/armor/<name>_layer_1/2.png */
public enum DupeArmorMaterial implements ArmorMaterial {
    DUPE("dupe", 1, 45, new int[]{4, 9, 7, 4}, 4.0F, 0.15F, 22, () -> DuperCraft.DUPERIUM_INGOT.get()),
    AETHER("aether", 2, 55, new int[]{5, 10, 8, 5}, 5.0F, 0.20F, 26, () -> DuperCraft.AETHERIUM_INGOT.get()),
    VOID("void", 3, 70, new int[]{6, 11, 9, 6}, 6.0F, 0.25F, 30, () -> DuperCraft.VOIDIUM_INGOT.get()),
    SINGULAR("singular", 4, 90, new int[]{7, 12, 10, 7}, 8.0F, 0.30F, 35, () -> DuperCraft.SINGULARIUM_INGOT.get()),
    /** Лише для всеосяжної мультброні. */
    OMNI("omni", 4, 110, new int[]{8, 13, 11, 8}, 10.0F, 0.40F, 40, () -> DuperCraft.SINGULARIUM_INGOT.get());

    /** Номер рівня 1..4. */
    public final int rank;
    private final String name;
    private final int durabilityFactor;
    private final int[] defense; // шолом, нагрудник, поножі, черевики
    private final float toughness;
    private final float knockback;
    private final int enchantment;
    private final Supplier<Item> ingot;

    DupeArmorMaterial(String name, int rank, int durabilityFactor, int[] defense, float toughness, float knockback,
                      int enchantment, Supplier<Item> ingot) {
        this.name = name;
        this.rank = rank;
        this.durabilityFactor = durabilityFactor;
        this.defense = defense;
        this.toughness = toughness;
        this.knockback = knockback;
        this.enchantment = enchantment;
        this.ingot = ingot;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        int base = switch (type) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return base * durabilityFactor;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return switch (type) {
            case HELMET -> defense[0];
            case CHESTPLATE -> defense[1];
            case LEGGINGS -> defense[2];
            case BOOTS -> defense[3];
        };
    }

    @Override
    public int getEnchantmentValue() {
        return enchantment;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_NETHERITE;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ingot.get());
    }

    @Override
    public String getName() {
        return DuperCraft.MODID + ":" + name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockback;
    }
}
