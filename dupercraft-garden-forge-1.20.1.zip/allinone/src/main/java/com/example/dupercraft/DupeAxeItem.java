package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Axe дюпера: механіка в DupeEvents (шанс подвоєння, axe-здатність; присядьте, щоб вимкнути). */
public class DupeAxeItem extends AxeItem {
    public final DupeTier gear;

    public DupeAxeItem(DupeTier tier) {
        super(tier, 5.0F, -3.0F, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
        this.gear = tier;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        GearUtil.selfRepair(stack, entity, gear.rank);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.axe").withStyle(ChatFormatting.LIGHT_PURPLE));
        int percent = (int) Math.round(Math.min(1.0, DupeConfig.PICKAXE_CHANCE.get() * gear.chanceMult) * 100);
        tooltip.add(Component.translatable("tooltip.dupercraft.chance", percent).withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", gear.rank).withStyle(ChatFormatting.AQUA));
        if (gear.rank >= 2) {
            tooltip.add(Component.translatable("tooltip.dupercraft.repair").withStyle(ChatFormatting.DARK_AQUA));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
