package com.example.dupercraft;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Мультброня: одягається в слот нагрудника, але рахується ПОВНИМ комплектом і дає здібності всіх чотирьох деталей
 * (візор, магнітна кіраса, поножі, черевики) та бонус комплекту.
 */
public class DupeMultiArmorItem extends DupeArmorItem {
    /** Пасивні здібності цієї мультброні (одна за комплектом, усі чотири у всеосяжної). */
    public final Set<ArmorAbility> abilities;

    public DupeMultiArmorItem(DupeArmorMaterial material, Set<ArmorAbility> abilities) {
        super(DupeMultiArmorMaterial.of(material), ArmorItem.Type.CHESTPLATE, material.rank);
        this.abilities = abilities;
    }

    /** Здібності мультброні, одягненої на гравця (порожньо, якщо її немає). */
    public static Set<ArmorAbility> abilitiesOf(Player player) {
        if (player.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof DupeMultiArmorItem multi) {
            return multi.abilities;
        }
        return EnumSet.noneOf(ArmorAbility.class);
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        GearUtil.selfRepair(stack, player, rank);
        if (level.isClientSide) {
            return;
        }
        applyHelmet(player, rank);
        applyChest(level, player, rank);
        applyLeggings(player, rank);
        applyBoots(player, rank);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.multiarmor").withStyle(ChatFormatting.LIGHT_PURPLE));
        for (ArmorAbility ability : abilities) {
            tooltip.add(Component.translatable("armor_ability.dupercraft." + ability.key).withStyle(ChatFormatting.YELLOW));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", rank).withStyle(ChatFormatting.AQUA));
        if (rank >= 2) {
            tooltip.add(Component.translatable("tooltip.dupercraft.repair").withStyle(ChatFormatting.DARK_AQUA));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
        if (rank >= 4) {
            tooltip.add(Component.translatable("tooltip.dupercraft.flight").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
    }
}
