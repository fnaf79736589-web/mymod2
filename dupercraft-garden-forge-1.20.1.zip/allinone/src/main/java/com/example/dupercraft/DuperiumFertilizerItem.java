package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Дюперієве добриво: миттєво доводить до стиглості всі культури (CropBlock) в області (за замовчуванням 3x3). */
public class DuperiumFertilizerItem extends Item {
    public DuperiumFertilizerItem() {
        super(new Item.Properties().rarity(Rarity.RARE));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos center = context.getClickedPos();
        if (!(level.getBlockState(center).getBlock() instanceof CropBlock)) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        int r = DupeConfig.FERTILIZER_RADIUS.get();
        int grown = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                BlockPos p = center.offset(dx, 0, dz);
                BlockState state = level.getBlockState(p);
                if (state.getBlock() instanceof CropBlock crop && !crop.isMaxAge(state)) {
                    level.setBlock(p, crop.getStateForAge(crop.getMaxAge()), 3);
                    level.levelEvent(2005, p, 0); // частинки добрива
                    grown++;
                }
            }
        }
        if (grown == 0) {
            return InteractionResult.PASS;
        }
        if (context.getPlayer() == null || !context.getPlayer().getAbilities().instabuild) {
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.fertilizer").withStyle(ChatFormatting.LIGHT_PURPLE));
    }
}
