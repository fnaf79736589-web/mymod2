package com.example.dupercraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Активні здібності мультиінструментів (ПКМ). Кожен комплект має свою; всеосяжний мультиінструмент має всі чотири. */
public enum ToolAbility {
    /** Сплеск подвоєння: деякий час кожна здобич (з блоків і мобів) подвоюється гарантовано. */
    DUPE_BURST("dupe_burst", 1200),
    /** Ривок у небо: стрімкий ривок уперед без шкоди від падіння. */
    DASH("dash", 40),
    /** Стрибок крізь порожнечу: телепорт до блока, на який ви дивитесь. */
    BLINK("blink", 30),
    /** Імпульс сингулярності: стягує предмети, досвід і мобів до вас, оглушуючи й ранячи їх. */
    SINGULARITY("singularity", 100);

    public static final String BURST_TAG = "dupercraft_burst";

    public final String key;
    /** Перезарядка в тактах. */
    public final int cooldown;

    ToolAbility(String key, int cooldown) {
        this.key = key;
        this.cooldown = cooldown;
    }

    /** Чи активний зараз сплеск подвоєння у гравця. */
    public static boolean isBurstActive(Player player) {
        return player.getPersistentData().getLong(BURST_TAG) > player.level().getGameTime();
    }

    /** Виконує здібність. Повертає true, якщо вона спрацювала (тоді вмикається перезарядка). */
    public boolean activate(ServerPlayer player, DupeTier gear) {
        ServerLevel level = player.serverLevel();
        switch (this) {
            case DUPE_BURST -> {
                player.getPersistentData().putLong(BURST_TAG, level.getGameTime() + 200L + 40L * gear.rank);
                level.playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.5F);
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0, player.getZ(), 30, 0.5, 0.8, 0.5, 0.1);
                return true;
            }
            case DASH -> {
                Vec3 look = player.getLookAngle();
                player.setDeltaMovement(look.x * 2.2, look.y * 1.4 + 0.25, look.z * 2.2);
                player.hurtMarked = true;
                player.fallDistance = 0.0F;
                level.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0F, 1.0F);
                level.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY() + 0.5, player.getZ(), 20, 0.3, 0.3, 0.3, 0.1);
                return true;
            }
            case BLINK -> {
                return blink(player, level, 16 + 4 * gear.rank);
            }
            case SINGULARITY -> {
                return pulse(player, level, 8.0 + 2.0 * gear.rank, gear);
            }
        }
        return false;
    }

    private static boolean blink(ServerPlayer player, ServerLevel level, int range) {
        HitResult hit = player.pick(range, 1.0F, false);
        BlockPos target;
        if (hit instanceof BlockHitResult block && block.getType() == HitResult.Type.BLOCK) {
            target = block.getBlockPos().relative(block.getDirection());
        } else {
            target = BlockPos.containing(player.getEyePosition().add(player.getLookAngle().scale(range)));
        }
        for (int dy = 0; dy <= 3; dy++) {
            BlockPos p = target.above(dy);
            if (level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                    && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()) {
                level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 40, 0.3, 0.6, 0.3, 0.2);
                player.teleportTo(p.getX() + 0.5, p.getY(), p.getZ() + 0.5);
                player.fallDistance = 0.0F;
                level.playSound(null, p, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
                level.sendParticles(ParticleTypes.PORTAL, p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5, 40, 0.3, 0.6, 0.3, 0.2);
                return true;
            }
        }
        return false;
    }

    private static boolean pulse(ServerPlayer player, ServerLevel level, double radius, DupeTier gear) {
        Vec3 target = player.position().add(0, player.getBbHeight() / 2.0, 0);
        AABB box = player.getBoundingBox().inflate(radius);
        for (Entity e : level.getEntities(player, box, ent -> ent.isAlive())) {
            if (e instanceof ItemEntity || e instanceof ExperienceOrb) {
                pull(e, target, 0.9);
            } else if (e instanceof LivingEntity living && !(e instanceof Player)) {
                pull(e, target, 0.6);
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3));
                living.hurt(player.damageSources().playerAttack(player), 2.0F + 2.0F * gear.rank);
            }
        }
        level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 0.5F);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 80, radius / 3.0, 0.8, radius / 3.0, 0.3);
        return true;
    }

    private static void pull(Entity entity, Vec3 target, double speed) {
        Vec3 diff = target.subtract(entity.position());
        if (diff.lengthSqr() < 0.3) {
            return;
        }
        entity.setDeltaMovement(diff.normalize().scale(speed));
        entity.hurtMarked = true;
    }
}
