package com.example.dupercraft;

import net.minecraft.core.registries.Registries;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(DuperCraft.MODID)
public class DuperCraft {
    public static final String MODID = "dupercraft";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(ForgeRegistries.RECIPE_TYPES, MODID);
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final int TIERS = 10;

    // Культури (з crops.json)
    public static final List<CropDef> CROPS = new ArrayList<>();
    public static final Map<String, RegistryObject<Block>> CROP_BLOCKS = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> SEEDS = new LinkedHashMap<>();

    // Прискорювачі селекції (10 рівнів)
    public static final List<RegistryObject<Block>> BOOSTERS = new ArrayList<>();
    public static final List<RegistryObject<Item>> BOOSTER_ITEMS = new ArrayList<>();

    static {
        for (int t = 1; t <= TIERS; t++) {
            final int tier = t;
            String name = tier == 1 ? "breeding_booster" : "breeding_booster_" + tier;
            RegistryObject<Block> block = BLOCKS.register(name,
                    () -> new BoosterBlock(BlockBehaviour.Properties.of().strength(2.5F).sound(SoundType.METAL), tier));
            BOOSTERS.add(block);
            BOOSTER_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of().strength(2.5F).sound(SoundType.WOOD);
    }

    // Блоки
    public static final RegistryObject<Block> WORKBENCH = BLOCKS.register("dupe_workbench", () -> new DupeWorkbenchBlock(props()));
    public static final RegistryObject<Block> DUPE_CHEST = BLOCKS.register("dupe_chest", () -> new DupeChestBlock(props()));

    // Предмети-блоки
    public static final RegistryObject<Item> WORKBENCH_ITEM = ITEMS.register("dupe_workbench", () -> new BlockItem(WORKBENCH.get(), new Item.Properties()));
    public static final RegistryObject<Item> DUPE_CHEST_ITEM = ITEMS.register("dupe_chest", () -> new BlockItem(DUPE_CHEST.get(), new Item.Properties()));

    // Матеріали: усі крафтяться лише у верстаку дюпера (9x9), кожен наступний з попереднього
    public static final RegistryObject<Item> DUPERIUM_INGOT = ITEMS.register("duperium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.duperium"));
    public static final RegistryObject<Item> AETHERIUM_INGOT = ITEMS.register("aetherium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.aetherium"));
    public static final RegistryObject<Item> VOIDIUM_INGOT = ITEMS.register("voidium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.voidium"));
    public static final RegistryObject<Item> SINGULARIUM_INGOT = ITEMS.register("singularium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.singularium"));
    // Гілка матеріалів: кожен теж крафтиться лише у верстаку дюпера (9x9) і росте як культура
    public static final RegistryObject<Item> TERRANIUM_INGOT = ITEMS.register("terranium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.terranium"));
    public static final RegistryObject<Item> PYRONIUM_INGOT = ITEMS.register("pyronium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.pyronium"));
    public static final RegistryObject<Item> CRYONIUM_INGOT = ITEMS.register("cryonium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.cryonium"));
    public static final RegistryObject<Item> CHRONIUM_INGOT = ITEMS.register("chronium_ingot", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.chronium"));

    // Амулети (діють з інвентаря)
    public static final RegistryObject<Item> TERRANIUM_AMULET = ITEMS.register("terranium_amulet", () -> new AmuletItem(Rarity.EPIC, "tooltip.dupercraft.amulet_terranium"));
    public static final RegistryObject<Item> PYRONIUM_AMULET = ITEMS.register("pyronium_amulet", () -> new AmuletItem(Rarity.EPIC, "tooltip.dupercraft.amulet_pyronium"));
    public static final RegistryObject<Item> CRYONIUM_AMULET = ITEMS.register("cryonium_amulet", () -> new AmuletItem(Rarity.EPIC, "tooltip.dupercraft.amulet_cryonium"));
    public static final RegistryObject<Item> CHRONIUM_AMULET = ITEMS.register("chronium_amulet", () -> new AmuletItem(Rarity.EPIC, "tooltip.dupercraft.amulet_chronium"));

    // Блоки-накопичувачі всіх восьми матеріалів
    public static final List<RegistryObject<Item>> MATERIAL_BLOCK_ITEMS = new ArrayList<>();

    static {
        for (String material : new String[]{"duperium", "aetherium", "voidium", "singularium", "terranium", "pyronium", "cryonium", "chronium"}) {
            RegistryObject<Block> block = BLOCKS.register(material + "_block", () -> new Block(
                    BlockBehaviour.Properties.of().strength(5.0F, 10.0F).sound(SoundType.METAL).requiresCorrectToolForDrops()));
            MATERIAL_BLOCK_ITEMS.add(ITEMS.register(material + "_block", () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    public static final RegistryObject<Item> DUPERIUM_FERTILIZER = ITEMS.register("duperium_fertilizer", DuperiumFertilizerItem::new);
    public static final RegistryObject<Item> DUPE_TOTEM = ITEMS.register("dupe_totem", () -> new MaterialItem(Rarity.EPIC, "tooltip.dupercraft.totem"));
    public static final RegistryObject<Item> DUPE_SATCHEL = ITEMS.register("dupe_satchel", SatchelItem::new);

    // Екіпіровка: 4 комплекти (dupe, aether, void, singular) по 7 предметів. Порядок має збігатися з DupeTier / DupeArmorMaterial.
    public static final Map<String, RegistryObject<Item>> GEAR = new LinkedHashMap<>();

    static {
        String[] sets = {"dupe", "aether", "void", "singular"};
        ToolAbility[] toolAbilities = {ToolAbility.DUPE_BURST, ToolAbility.DASH, ToolAbility.BLINK, ToolAbility.SINGULARITY};
        ArmorAbility[] armorAbilities = {ArmorAbility.MIRROR, ArmorAbility.WARD, ArmorAbility.ANCHOR, ArmorAbility.HORIZON};
        for (int i = 0; i < sets.length; i++) {
            final String s = sets[i];
            final DupeTier tier = DupeTier.values()[i];
            final DupeArmorMaterial mat = DupeArmorMaterial.values()[i];
            final ToolAbility toolAbility = toolAbilities[i];
            final ArmorAbility armorAbility = armorAbilities[i];
            GEAR.put(s + "_pickaxe", ITEMS.register(s + "_pickaxe", () -> new DupePickaxeItem(tier)));
            GEAR.put(s + "_sword", ITEMS.register(s + "_sword", () -> new DupeSwordItem(tier)));
            GEAR.put(s + "_hoe", ITEMS.register(s + "_hoe", () -> new DupeHoeItem(tier)));
            GEAR.put(s + "_axe", ITEMS.register(s + "_axe", () -> new DupeAxeItem(tier)));
            GEAR.put(s + "_shovel", ITEMS.register(s + "_shovel", () -> new DupeShovelItem(tier)));
            GEAR.put(s + "_helmet", ITEMS.register(s + "_helmet", () -> new DupeArmorItem(mat, ArmorItem.Type.HELMET)));
            GEAR.put(s + "_chestplate", ITEMS.register(s + "_chestplate", () -> new DupeArmorItem(mat, ArmorItem.Type.CHESTPLATE)));
            GEAR.put(s + "_leggings", ITEMS.register(s + "_leggings", () -> new DupeArmorItem(mat, ArmorItem.Type.LEGGINGS)));
            GEAR.put(s + "_boots", ITEMS.register(s + "_boots", () -> new DupeArmorItem(mat, ArmorItem.Type.BOOTS)));
            GEAR.put(s + "_multitool", ITEMS.register(s + "_multitool", () -> new DupeMultiToolItem(tier, toolAbility)));
            GEAR.put(s + "_multiarmor", ITEMS.register(s + "_multiarmor", () -> new DupeMultiArmorItem(mat, EnumSet.of(armorAbility))));
        }
        // Всеосяжні версії: крафтяться з усіх чотирьох комплектів, мають ВСІ здібності
        GEAR.put("omni_multitool", ITEMS.register("omni_multitool", () -> new DupeMultiToolItem(DupeTier.OMNI, null)));
        GEAR.put("omni_multiarmor", ITEMS.register("omni_multiarmor",
                () -> new DupeMultiArmorItem(DupeArmorMaterial.OMNI, EnumSet.allOf(ArmorAbility.class))));
    }

    // Блок-сутність сундука
    public static final RegistryObject<BlockEntityType<DupeChestBlockEntity>> DUPE_CHEST_BE = BLOCK_ENTITIES.register("dupe_chest",
            () -> BlockEntityType.Builder.of(DupeChestBlockEntity::new, DUPE_CHEST.get()).build(null));

    // Блок-сутність прискорювачів (один тип для всіх рівнів)
    public static final RegistryObject<BlockEntityType<BoosterBlockEntity>> BOOSTER_BE = BLOCK_ENTITIES.register("breeding_booster",
            () -> BlockEntityType.Builder.of(BoosterBlockEntity::new,
                    BOOSTERS.stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    // Меню верстака
    public static final RegistryObject<MenuType<DupeWorkbenchMenu>> WORKBENCH_MENU = MENUS.register("workbench",
            () -> IForgeMenuType.create((id, inv, data) -> new DupeWorkbenchMenu(id, inv)));

    // Власний тип рецептів (крафтяться лише в цьому верстаку)
    public static final RegistryObject<RecipeType<DupeWorkbenchRecipe>> RECIPE_TYPE = RECIPE_TYPES.register("workbench",
            () -> RecipeType.simple(new ResourceLocation(MODID, "workbench")));
    public static final RegistryObject<RecipeSerializer<DupeWorkbenchRecipe>> RECIPE_SERIALIZER = RECIPE_SERIALIZERS.register("workbench",
            DupeWorkbenchRecipe.Serializer::new);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dupercraft"))
                    .icon(() -> new ItemStack(DUPE_CHEST_ITEM.get()))
                    .displayItems((params, out) -> {
                        out.accept(WORKBENCH_ITEM.get());
                        out.accept(DUPE_CHEST_ITEM.get());
                        out.accept(DUPERIUM_INGOT.get());
                        out.accept(AETHERIUM_INGOT.get());
                        out.accept(VOIDIUM_INGOT.get());
                        out.accept(SINGULARIUM_INGOT.get());
                        out.accept(TERRANIUM_INGOT.get());
                        out.accept(PYRONIUM_INGOT.get());
                        out.accept(CRYONIUM_INGOT.get());
                        out.accept(CHRONIUM_INGOT.get());
                        MATERIAL_BLOCK_ITEMS.forEach(i -> out.accept(i.get()));
                        out.accept(TERRANIUM_AMULET.get());
                        out.accept(PYRONIUM_AMULET.get());
                        out.accept(CRYONIUM_AMULET.get());
                        out.accept(CHRONIUM_AMULET.get());
                        out.accept(DUPERIUM_FERTILIZER.get());
                        out.accept(DUPE_TOTEM.get());
                        out.accept(DUPE_SATCHEL.get());
                        GEAR.values().forEach(i -> out.accept(i.get()));
                        BOOSTER_ITEMS.forEach(i -> out.accept(i.get()));
                    })
                    .build());

    public static final RegistryObject<CreativeModeTab> CROPS_TAB = TABS.register("crops", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dupercraft.crops"))
                    .icon(() -> new ItemStack(SEEDS.values().iterator().next().get()))
                    .displayItems((params, out) -> {
                        // показуємо лише насіння, чий ресурс існує в грі
                        for (CropDef d : CROPS) {
                            if (ForgeRegistries.ITEMS.containsKey(d.item())) {
                                out.accept(SEEDS.get(d.name()).get());
                            }
                        }
                    })
                    .build());

    public DuperCraft() {
        loadCrops();
        for (CropDef d : CROPS) {
            RegistryObject<Block> block = BLOCKS.register(d.name() + "_crop",
                    () -> new ResourceCropBlock(d, () -> SEEDS.get(d.name()).get()));
            RegistryObject<Item> seed = ITEMS.register(d.name() + "_seeds",
                    () -> new ItemNameBlockItem(block.get(), new Item.Properties()));
            CROP_BLOCKS.put(d.name(), block);
            SEEDS.put(d.name(), seed);
        }

        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        MENUS.register(bus);
        RECIPE_TYPES.register(bus);
        RECIPE_SERIALIZERS.register(bus);
        TABS.register(bus);
        bus.addListener(this::onLoadComplete);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, DupeConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BoosterConfig.SPEC, "dupercraft-boosters.toml");
    }

    private static void loadCrops() {
        try (InputStream in = DuperCraft.class.getResourceAsStream("/crops.json")) {
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject();
            for (JsonElement el : root.getAsJsonArray("crops")) {
                JsonObject o = el.getAsJsonObject();
                String name = o.get("name").getAsString();
                int color = Integer.parseInt(o.get("color").getAsString().replace("#", ""), 16);
                ResourceLocation item = new ResourceLocation(o.get("item").getAsString());
                JsonArray c = o.getAsJsonArray("count");
                String mod = o.has("mod") ? o.get("mod").getAsString() : null;
                CROPS.add(new CropDef(name, color, item, c.get(0).getAsInt(), c.get(1).getAsInt(), mod));
            }
        } catch (Exception e) {
            throw new RuntimeException("Не вдалося прочитати crops.json", e);
        }
        LogUtils.getLogger().info("DuperCraft: завантажено {} культур", CROPS.size());
    }

    /** Після завантаження всіх модів: записуємо ID предметів Industrial Upgrade у файл і попереджаємо про хибні ID. */
    private void onLoadComplete(FMLLoadCompleteEvent e) {
        try {
            List<String> ids = new ArrayList<>();
            for (ResourceLocation id : ForgeRegistries.ITEMS.getKeys()) {
                if (id.getNamespace().equals("industrialupgrade")) {
                    ids.add(id.toString());
                }
            }
            Collections.sort(ids);
            if (!ids.isEmpty()) {
                Files.write(FMLPaths.GAMEDIR.get().resolve("resourcecrops_industrialupgrade_items.txt"), ids);
            }
        } catch (IOException ex) {
            LogUtils.getLogger().warn("DuperCraft: не вдалося записати список предметів", ex);
        }
        for (CropDef d : CROPS) {
            if (!ForgeRegistries.ITEMS.containsKey(d.item())) {
                LogUtils.getLogger().warn("DuperCraft: предмет {} не знайдено, культура '{}' не дасть ресурсу", d.item(), d.name());
            }
        }
    }
}
