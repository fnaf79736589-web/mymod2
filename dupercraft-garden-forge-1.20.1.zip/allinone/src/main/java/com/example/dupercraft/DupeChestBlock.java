package com.example.dupercraft;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.CompoundContainer;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.ChestType;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Сундук-дюпер. Два сундуки, поставлені поруч (лицем в один бік), зливаються в ОДИН ВЕЛИКИЙ на 54 слоти,
 * як ванільні. Присядьте при установці, щоб поставити окремо.
 */
public class DupeChestBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;
    public static final EnumProperty<ChestType> TYPE = BlockStateProperties.CHEST_TYPE;

    public DupeChestBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(TYPE, ChestType.SINGLE));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, TYPE);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL; // BaseEntityBlock за замовчуванням невидимий
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new DupeChestBlockEntity(pos, state);
    }

    // ---------- Об'єднання у великий сундук (логіка як у ванільного сундука) ----------

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        ChestType type = ChestType.SINGLE;
        Direction direction = context.getHorizontalDirection().getOpposite();
        boolean sneaking = context.isSecondaryUseActive();
        Direction clicked = context.getClickedFace();
        if (clicked.getAxis().isHorizontal() && sneaking) {
            Direction partner = candidatePartnerFacing(context, clicked.getOpposite());
            if (partner != null && partner.getAxis() != clicked.getAxis()) {
                direction = partner;
                type = partner.getCounterClockWise() == clicked.getOpposite() ? ChestType.RIGHT : ChestType.LEFT;
            }
        }
        if (type == ChestType.SINGLE && !sneaking) {
            if (direction == candidatePartnerFacing(context, direction.getClockWise())) {
                type = ChestType.LEFT;
            } else if (direction == candidatePartnerFacing(context, direction.getCounterClockWise())) {
                type = ChestType.RIGHT;
            }
        }
        return this.defaultBlockState().setValue(FACING, direction).setValue(TYPE, type);
    }

    @Nullable
    private Direction candidatePartnerFacing(BlockPlaceContext context, Direction side) {
        BlockState state = context.getLevel().getBlockState(context.getClickedPos().relative(side));
        return state.is(this) && state.getValue(TYPE) == ChestType.SINGLE ? state.getValue(FACING) : null;
    }

    private static Direction connectedDirection(BlockState state) {
        Direction facing = state.getValue(FACING);
        return state.getValue(TYPE) == ChestType.LEFT ? facing.getClockWise() : facing.getCounterClockWise();
    }

    @Override
    public BlockState updateShape(BlockState state, Direction direction, BlockState neighbor, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        if (neighbor.is(this) && direction.getAxis().isHorizontal()) {
            ChestType neighborType = neighbor.getValue(TYPE);
            if (state.getValue(TYPE) == ChestType.SINGLE && neighborType != ChestType.SINGLE
                    && state.getValue(FACING) == neighbor.getValue(FACING)
                    && connectedDirection(neighbor) == direction.getOpposite()) {
                return state.setValue(TYPE, neighborType.getOpposite());
            }
        } else if (connectedDirection(state) == direction) {
            return state.setValue(TYPE, ChestType.SINGLE);
        }
        return super.updateShape(state, direction, neighbor, level, pos, neighborPos);
    }

    @Override
    public BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    public BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    // ---------- Відкриття ----------

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        MenuProvider provider = this.getMenuProvider(state, level, pos);
        if (provider != null) {
            player.openMenu(provider);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    @Nullable
    public MenuProvider getMenuProvider(BlockState state, Level level, BlockPos pos) {
        if (!(level.getBlockEntity(pos) instanceof DupeChestBlockEntity self)) {
            return null;
        }
        if (state.getValue(TYPE) == ChestType.SINGLE) {
            return self;
        }
        BlockPos otherPos = pos.relative(connectedDirection(state));
        BlockState otherState = level.getBlockState(otherPos);
        if (!otherState.is(this) || !(level.getBlockEntity(otherPos) instanceof DupeChestBlockEntity other)) {
            return self;
        }
        // Однаковий порядок слотів незалежно від того, яку половину відкрито: LEFT перша, RIGHT друга
        DupeChestBlockEntity first = state.getValue(TYPE) == ChestType.LEFT ? self : other;
        DupeChestBlockEntity second = first == self ? other : self;
        CompoundContainer container = new CompoundContainer(first, second);
        return new MenuProvider() {
            @Override
            public Component getDisplayName() {
                return Component.translatable("container.dupercraft.dupe_chest_double");
            }

            @Override
            public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
                return ChestMenu.sixRows(id, inventory, container);
            }
        };
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof DupeChestBlockEntity chest) {
                Containers.dropContents(level, pos, chest);
                level.updateNeighbourForOutputSignal(pos, this);
            }
        }
        super.onRemove(state, level, pos, newState, moved);
    }
}
