package com.example.dupercraft;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Спільні помічники для інструментів дюпера: пошук блоків, масове руйнування, самолагодження. */
public final class GearUtil {
    private GearUtil() {
    }

    /** Скільки режимів кирки доступно на рівні. */
    public static int modeCount(int rank) {
        return rank >= 3 ? 4 : rank == 2 ? 3 : 2;
    }

    public static DupePickaxeItem.Mode getMode(ItemStack stack, int rank) {
        int i = stack.hasTag() ? stack.getTag().getInt("DupeMode") : 0;
        return DupePickaxeItem.Mode.values()[Math.max(0, Math.min(i, modeCount(rank) - 1))];
    }

    /** Shift+ПКМ: перемикає режим інструмента. Повертає null, якщо гравець не присів. */
    public static InteractionResultHolder<ItemStack> cycleMode(Level level, Player player, InteractionHand hand, int rank) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isShiftKeyDown()) {
            return null;
        }
        if (!level.isClientSide) {
            int next = (getMode(stack, rank).ordinal() + 1) % modeCount(rank);
            stack.getOrCreateTag().putInt("DupeMode", next);
            player.displayClientMessage(Component.translatable("message.dupercraft.mode",
                    Component.translatable("mode.dupercraft." + DupePickaxeItem.Mode.values()[next].name().toLowerCase(java.util.Locale.ROOT))), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Самолагодження (з 2-го рівня): раз на N тактів відновлює міцність. */
    public static void selfRepair(ItemStack stack, Entity entity, int rank) {
        if (rank < 2 || entity.level().isClientSide || !stack.isDamaged()) {
            return;
        }
        int interval = DupeConfig.REPAIR_INTERVAL.get();
        if (interval <= 0 || entity.tickCount % interval != 0) {
            return;
        }
        stack.setDamageValue(Math.max(0, stack.getDamageValue() - (rank - 1)));
    }

    /** Грань блока, на яку дивиться гравець. */
    public static Direction faceOf(Player player) {
        HitResult hit = player.pick(6.0D, 1.0F, false);
        if (hit instanceof BlockHitResult block && block.getType() == HitResult.Type.BLOCK) {
            return block.getDirection();
        }
        Vec3 look = player.getLookAngle();
        return Direction.getNearest(look.x, look.y, look.z);
    }

    /** Квадрат (2*radius+1)^2 блоків у площині, перпендикулярній до грані. Початковий блок першим. */
    public static List<BlockPos> plane(Level level, BlockPos origin, Direction face, int radius, Predicate<BlockState> filter) {
        List<BlockPos> result = new ArrayList<>();
        result.add(origin);
        for (int a = -radius; a <= radius; a++) {
            for (int b = -radius; b <= radius; b++) {
                if (a == 0 && b == 0) {
                    continue;
                }
                BlockPos p = switch (face.getAxis()) {
                    case Y -> origin.offset(a, 0, b);
                    case X -> origin.offset(0, a, b);
                    case Z -> origin.offset(a, b, 0);
                };
                if (level.isLoaded(p) && filter.test(level.getBlockState(p))) {
                    result.add(p);
                }
            }
        }
        return result;
    }

    /** Зв'язна область блоків (включно з діагоналями), що задовольняють фільтр, до limit штук. */
    public static List<BlockPos> connected(Level level, BlockPos origin, Predicate<BlockState> match, int limit) {
        List<BlockPos> result = new ArrayList<>();
        Set<BlockPos> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(origin);
        seen.add(origin);
        while (!queue.isEmpty() && result.size() < limit) {
            BlockPos cur = queue.poll();
            result.add(cur);
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos n = cur.offset(dx, dy, dz);
                        if (seen.contains(n) || !level.isLoaded(n)) {
                            continue;
                        }
                        seen.add(n);
                        if (match.test(level.getBlockState(n))) {
                            queue.add(n);
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * Ламає блоки зі списку як гравець: збирає здобич (з шансом подвоєння, за бажанням переплавляє й кладе в інвентар),
     * видає досвід і зношує інструмент. Блоки з блок-сутностями (скрині, машини) не чіпає.
     */
    public static int breakBlocks(ServerLevel level, ServerPlayer player, ItemStack tool, List<BlockPos> positions,
                                  boolean smelt, double duplicateChance, boolean autoPickup) {
        int silk = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool);
        int fortune = EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, tool);
        int broken = 0;
        for (BlockPos pos : positions) {
            if (tool.isEmpty()) {
                break;
            }
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.getDestroySpeed(level, pos) < 0 || !player.hasCorrectToolForDrops(state)
                    || level.getBlockEntity(pos) != null) {
                continue;
            }
            List<ItemStack> drops = Block.getDrops(state, level, pos, null, player, tool);
            int exp = silk > 0 ? 0 : state.getExpDrop(level, level.random, pos, fortune, silk);
            level.destroyBlock(pos, false, player);
            for (ItemStack drop : drops) {
                ItemStack out = smelt ? smelted(level, drop) : drop;
                give(level, player, pos, out, autoPickup);
                if (level.random.nextDouble() < duplicateChance) {
                    give(level, player, pos, out.copy(), autoPickup);
                }
            }
            if (exp > 0) {
                ExperienceOrb.award(level, Vec3.atCenterOf(pos), exp);
            }
            tool.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(EquipmentSlot.MAINHAND));
            broken++;
        }
        return broken;
    }

    private static ItemStack smelted(ServerLevel level, ItemStack in) {
        Optional<SmeltingRecipe> recipe = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SimpleContainer(in), level);
        if (recipe.isEmpty()) {
            return in;
        }
        ItemStack result = recipe.get().getResultItem(level.registryAccess()).copy();
        result.setCount(result.getCount() * in.getCount());
        return result;
    }

    private static void give(ServerLevel level, ServerPlayer player, BlockPos pos, ItemStack stack, boolean autoPickup) {
        if (stack.isEmpty()) {
            return;
        }
        if (autoPickup) {
            if (!player.getInventory().add(stack)) {
                Block.popResource(level, pos, stack);
            }
        } else {
            Block.popResource(level, pos, stack);
        }
    }

    /** Лише для зручності: чи є контейнер порожнім. */
    public static boolean isEmpty(Container c) {
        for (int i = 0; i < c.getContainerSize(); i++) {
            if (!c.getItem(i).isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
