package com.example.dupercraft;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Інвентар сумки дюпера на 27 слотів. Зберігається в NBT предмета; предмети всередині стають повними стаками. */
public class SatchelContainer extends SimpleContainer {
    private final ItemStack satchel;
    private boolean loading;

    public SatchelContainer(ItemStack satchel) {
        super(27);
        this.satchel = satchel;
        CompoundTag tag = satchel.getTag();
        if (tag != null && tag.contains("SatchelItems", Tag.TAG_LIST)) {
            this.loading = true;
            this.fromTag(tag.getList("SatchelItems", Tag.TAG_COMPOUND));
            this.loading = false;
        }
    }

    @Override
    public void setChanged() {
        if (!this.loading) {
            for (int i = 0; i < this.getContainerSize(); i++) {
                ItemStack s = this.getItem(i);
                if (!s.isEmpty() && s.getCount() < s.getMaxStackSize()) {
                    s.setCount(s.getMaxStackSize());
                }
            }
            this.satchel.getOrCreateTag().put("SatchelItems", this.createTag());
        }
        super.setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        return player.getMainHandItem() == this.satchel || player.getOffhandItem() == this.satchel;
    }

    @Override
    public boolean canPlaceItem(int index, ItemStack stack) {
        return !(stack.getItem() instanceof SatchelItem); // сумку в сумку класти не можна
    }
}
