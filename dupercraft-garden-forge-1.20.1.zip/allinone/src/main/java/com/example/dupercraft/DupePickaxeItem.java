package com.example.dupercraft;

import java.util.List;
import java.util.Locale;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Кирка дюпера. Шанс подвоїти здобич; з 3-го рівня здобич летить одразу в інвентар.
 * Режими (Shift+ПКМ у повітрі змінює): звичайний, плавлення, тунель (3x3 / 5x5), жила (вся рудна жила).
 * Тунель відкривається з 2-го рівня, жила з 3-го. Присядьте під час копання, щоб копати звичайно.
 */
public class DupePickaxeItem extends PickaxeItem {
    public enum Mode {NORMAL, SMELT, TUNNEL, VEIN}

    public final DupeTier gear;

    public DupePickaxeItem(DupeTier tier) {
        super(tier, 1, -2.8F, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
        this.gear = tier;
    }

    public int modeCount() {
        return GearUtil.modeCount(gear.rank);
    }

    public Mode getMode(ItemStack stack) {
        return GearUtil.getMode(stack, gear.rank);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        InteractionResultHolder<ItemStack> cycled = GearUtil.cycleMode(level, player, hand, gear.rank);
        return cycled != null ? cycled : super.use(level, player, hand);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        super.inventoryTick(stack, level, entity, slot, selected);
        GearUtil.selfRepair(stack, entity, gear.rank);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.pickaxe").withStyle(ChatFormatting.LIGHT_PURPLE));
        int percent = (int) Math.round(Math.min(1.0, DupeConfig.PICKAXE_CHANCE.get() * gear.chanceMult) * 100);
        tooltip.add(Component.translatable("tooltip.dupercraft.chance", percent).withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.translatable("tooltip.dupercraft.mode",
                Component.translatable("mode.dupercraft." + getMode(stack).name().toLowerCase(Locale.ROOT))).withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.dupercraft.mode_hint").withStyle(ChatFormatting.DARK_GRAY));
        if (gear.rank >= 3) {
            tooltip.add(Component.translatable("tooltip.dupercraft.autopickup").withStyle(ChatFormatting.DARK_GREEN));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", gear.rank).withStyle(ChatFormatting.AQUA));
        if (gear.rank >= 2) {
            tooltip.add(Component.translatable("tooltip.dupercraft.repair").withStyle(ChatFormatting.DARK_AQUA));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
