package com.example.dupercraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.FrostWalkerEnchantment;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

/**
 * Пасивні здібності амулетів (працюють, поки амулет лежить будь-де в інвентарі):
 * терраній = «Зелений палець», піроній = «Серце інферно», кріоній = «Льодохід», хроній = «Хроно-якір».
 */
@Mod.EventBusSubscriber(modid = DuperCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class AmuletEvents {
    private static final String CHRONO_PREV = "dupercraft_chrono_prev";
    private static final String CHRONO_CUR = "dupercraft_chrono_cur";
    private static final String CHRONO_COOLDOWN = "dupercraft_chrono_cd";

    /** Чи є амулет у гравця (основний інвентар або друга рука). */
    public static boolean has(Player player, RegistryObject<Item> amulet) {
        Item item = amulet.get();
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(item)) {
                return true;
            }
        }
        return player.getOffhandItem().is(item);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        Player player = event.player;
        if (event.phase != TickEvent.Phase.END || !(player.level() instanceof ServerLevel level) || level.isClientSide) {
            return;
        }
        int t = player.tickCount;
        if (t % 2 == 0 && has(player, DuperCraft.CRYONIUM_AMULET)) {
            // Льодохід: вода під ногами замерзає (як чобітки Frost Walker II)
            FrostWalkerEnchantment.onEntityMoved(player, level, player.blockPosition(), 2);
        }
        if (t % 20 != 0) {
            return;
        }
        if (has(player, DuperCraft.TERRANIUM_AMULET)) {
            greenThumb(level, player);
        }
        if (has(player, DuperCraft.PYRONIUM_AMULET)) {
            DupeArmorItem.refresh(player, MobEffects.FIRE_RESISTANCE, 0, 20, 60);
        }
        if (has(player, DuperCraft.CRYONIUM_AMULET)) {
            for (Monster monster : level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(5.0), e -> e.isAlive())) {
                monster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1)); // студить ворогів поруч
            }
        }
        if (has(player, DuperCraft.CHRONIUM_AMULET)) {
            DupeArmorItem.refresh(player, MobEffects.DIG_SPEED, 1, 20, 60);
            DupeArmorItem.refresh(player, MobEffects.MOVEMENT_SPEED, 0, 20, 60);
            if (t % 100 == 0) {
                recordPosition(level, player);
            }
        }
    }

    /** Зелений палець: культури навколо дозрівають швидше. */
    private static void greenThumb(ServerLevel level, Player player) {
        BlockPos center = player.blockPosition();
        for (int i = 0; i < 16; i++) {
            BlockPos pos = center.offset(level.random.nextInt(13) - 6, level.random.nextInt(5) - 2, level.random.nextInt(13) - 6);
            BlockState state = level.getBlockState(pos);
            if (state.getBlock() instanceof CropBlock crop && !crop.isMaxAge(state) && level.random.nextFloat() < 0.5F) {
                crop.growCrops(level, pos, state);
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 3, 0.25, 0.25, 0.25, 0.0);
            }
        }
    }

    /** Хроно-якір: раз на 5 секунд запам'ятовує позицію (потрібна позиція 5-10 секунд тому). */
    private static void recordPosition(ServerLevel level, Player player) {
        CompoundTag data = player.getPersistentData();
        if (data.contains(CHRONO_CUR)) {
            data.put(CHRONO_PREV, data.getCompound(CHRONO_CUR).copy());
        }
        CompoundTag cur = new CompoundTag();
        cur.putString("dim", level.dimension().location().toString());
        cur.putDouble("x", player.getX());
        cur.putDouble("y", player.getY());
        cur.putDouble("z", player.getZ());
        data.put(CHRONO_CUR, cur);
    }

    /** Піроній: імунітет до вогню. Кріоній: імунітет до замерзання. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) {
            return;
        }
        if (event.getSource().is(DamageTypeTags.IS_FIRE) && has(player, DuperCraft.PYRONIUM_AMULET)) {
            event.setCanceled(true);
            player.clearFire();
        } else if (event.getSource().is(DamageTypeTags.IS_FREEZING) && has(player, DuperCraft.CRYONIUM_AMULET)) {
            event.setCanceled(true);
        }
    }

    /** Піроній: кожен ваш удар підпалює ціль. */
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent event) {
        if (event.getSource().getEntity() instanceof Player player && !player.level().isClientSide
                && has(player, DuperCraft.PYRONIUM_AMULET)) {
            event.getEntity().setSecondsOnFire(6);
        }
    }

    /** Хроній: смертельний удар відкочує вас на 5-10 секунд назад (перезарядка 5 хвилин). Спрацьовує раніше за тотем. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)
                || !has(player, DuperCraft.CHRONIUM_AMULET)) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        long now = player.level().getGameTime();
        if (data.getLong(CHRONO_COOLDOWN) > now || !data.contains(CHRONO_PREV)) {
            return;
        }
        CompoundTag prev = data.getCompound(CHRONO_PREV);
        if (!prev.getString("dim").equals(player.level().dimension().location().toString())) {
            return;
        }
        event.setCanceled(true);
        ServerLevel level = player.serverLevel();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, player.getX(), player.getY() + 1.0, player.getZ(), 60, 0.4, 0.8, 0.4, 0.2);
        player.teleportTo(prev.getDouble("x"), prev.getDouble("y"), prev.getDouble("z"));
        player.setDeltaMovement(Vec3.ZERO);
        player.fallDistance = 0.0F;
        player.clearFire();
        player.removeAllEffects();
        player.setHealth(player.getMaxHealth() * 0.6F);
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 1));
        data.putLong(CHRONO_COOLDOWN, now + 6000L);
        level.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.displayClientMessage(Component.translatable("message.dupercraft.rewind"), true);
    }
}
