package com.example.dupercraft;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.state.BlockState;

/** Шукає поруч блоки з фільтра (грядки, вулики Industrial Upgrade) і додатково "підтікує" їх. */
public class BoosterBlockEntity extends BlockEntity {
    private List<BlockPos> targets = new ArrayList<>();
    private int age = 0;

    public BoosterBlockEntity(BlockPos pos, BlockState state) {
        super(DuperCraft.BOOSTER_BE.get(), pos, state);
    }

    public int getTargetCount() {
        return targets.size();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, BoosterBlockEntity be) {
        if (!(level instanceof ServerLevel server)) {
            return;
        }
        int tier = state.getBlock() instanceof BoosterBlock b ? b.tier : 1;
        if (be.age++ % BoosterConfig.RESCAN_INTERVAL.get() == 0) {
            be.rescan(server, pos, BoosterConfig.RADIUS[tier - 1].get());
        }
        int extra = BoosterConfig.EXTRA_TICKS[tier - 1].get();
        if (extra <= 0 || be.targets.isEmpty()) {
            return;
        }
        for (BlockPos p : be.targets) {
            if (!server.isLoaded(p)) {
                continue;
            }
            // 1) додаткові такти блок-сутності (ріст, цикли роботи, розмноження)
            for (int i = 0; i < extra; i++) {
                BlockEntity target = server.getBlockEntity(p);
                if (target == null || target.isRemoved()) {
                    break;
                }
                BlockEntityTicker ticker = TickUtil.ticker(server, target.getBlockState(), target);
                if (ticker == null) {
                    break;
                }
                ticker.tick(server, p, target.getBlockState(), target);
            }
            // 2) додаткові випадкові такти (для блоків, що ростуть як ванільні культури)
            BlockState current = server.getBlockState(p);
            if (!current.isAir() && current.isRandomlyTicking() && server.random.nextInt(1365) < extra) {
                current.randomTick(server, p, server.random);
            }
        }
    }

    private void rescan(ServerLevel level, BlockPos origin, int r) {
        List<BlockPos> found = new ArrayList<>();
        int max = BoosterConfig.MAX_TARGETS.get();
        BoosterConfig.Matcher matcher = new BoosterConfig.Matcher();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        scan:
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.set(origin.getX() + dx, origin.getY() + dy, origin.getZ() + dz);
                    if (m.equals(origin) || !level.isLoaded(m)) {
                        continue;
                    }
                    BlockState s = level.getBlockState(m);
                    if (s.isAir()) {
                        continue;
                    }
                    if (matcher.matches(s)) {
                        found.add(m.immutable());
                        if (found.size() >= max) {
                            break scan;
                        }
                    }
                }
            }
        }
        this.targets = found;
    }
}
