package com.example.dupercraft;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.registries.ForgeRegistries;

/** Налаштування (файл config/selectionboost-common.toml). */
public class BoosterConfig {
    public static final int TIERS = 10;
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue[] RADIUS = new ForgeConfigSpec.IntValue[TIERS];
    public static final ForgeConfigSpec.IntValue[] EXTRA_TICKS = new ForgeConfigSpec.IntValue[TIERS];
    public static final ForgeConfigSpec.IntValue RESCAN_INTERVAL;
    public static final ForgeConfigSpec.IntValue MAX_TARGETS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FILTERS;

    // Значення за замовчуванням для рівнів 1..5
    private static final int[] DEFAULT_RADIUS = {4, 8, 12, 16, 24, 28, 32, 32, 32, 32};
    private static final int[] DEFAULT_EXTRA = {2, 4, 8, 16, 32, 48, 64, 96, 128, 160};

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        for (int i = 0; i < TIERS; i++) {
            b.push("tier" + (i + 1));
            RADIUS[i] = b.comment("Радіус дії (куб навколо прискорювача), блоків.")
                    .defineInRange("radius", DEFAULT_RADIUS[i], 1, 32);
            EXTRA_TICKS[i] = b.comment("Скільки ДОДАТКОВИХ тактів роботи отримує кожен блок за кожен такт гри. N = у (N+1) разів швидше. 0 = вимкнено.")
                    .defineInRange("extraTicksPerTick", DEFAULT_EXTRA[i], 0, 1000);
            b.pop();
        }
        RESCAN_INTERVAL = b.comment("Як часто (у тактах) прискорювач заново шукає блоки навколо.")
                .defineInRange("rescanIntervalTicks", 100, 20, 1200);
        MAX_TARGETS = b.comment("Максимум блоків, які прискорює один прискорювач (захист від лагів).")
                .defineInRange("maxTargets", 256, 1, 4096);
        FILTERS = b.comment("Які блоки прискорювати. Запис = початок ID блока 'мод:шлях' АБО тег блоків із решіткою '#мод:тег'.",
                        "Приклад: \"industrialupgrade:crop/\" прискорює все з категорії crop/; \"#minecraft:crops\" усі ванільні культури.",
                        "\"#dupercraft:boostable\" це всі культури цього мода (тег можна доповнювати датапаком).",
                        "Додайте \"industrialupgrade:basemachine3/\", щоб прискорити й машини (вони тоді споживатимуть більше енергії!).",
                        "ID блоків можна подивитись командою /dupercraft scan.")
                .defineList("blockFilters", List.of("#dupercraft:boostable", "#minecraft:crops", "industrialupgrade:crop/", "industrialupgrade:apiary/"), o -> o instanceof String);
        SPEC = b.build();
    }

    /** Скомпільований фільтр: теги + префікси ID. Створюється один раз на сканування. */
    public static class Matcher {
        private final List<TagKey<Block>> tags = new ArrayList<>();
        private final List<String> prefixes = new ArrayList<>();

        public Matcher() {
            for (String f : FILTERS.get()) {
                if (f.startsWith("#")) {
                    ResourceLocation id = ResourceLocation.tryParse(f.substring(1));
                    if (id != null) {
                        tags.add(TagKey.create(Registries.BLOCK, id));
                    }
                } else {
                    prefixes.add(f);
                }
            }
        }

        public boolean matches(BlockState state) {
            for (TagKey<Block> tag : tags) {
                if (state.is(tag)) {
                    return true;
                }
            }
            if (!prefixes.isEmpty()) {
                ResourceLocation key = ForgeRegistries.BLOCKS.getKey(state.getBlock());
                if (key != null) {
                    String id = key.toString();
                    for (String p : prefixes) {
                        if (id.startsWith(p)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }
}
