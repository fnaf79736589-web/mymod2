package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Броня дюпера (4 рівні). Кожна деталь має здатність, що сильнішає з рівнем; повний комплект дає бонус. */
public class DupeArmorItem extends ArmorItem {
    /** Рівень матеріалу 1..4. */
    public final int rank;

    public DupeArmorItem(DupeArmorMaterial material, ArmorItem.Type type) {
        this(material, type, material.rank);
    }

    protected DupeArmorItem(ArmorMaterial material, ArmorItem.Type type, int rank) {
        super(material, type, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
        this.rank = rank;
    }

    /** Рівень повного комплекту: найнижчий рівень серед чотирьох деталей (0, якщо комплект неповний). */
    public static int setTier(Player p) {
        // Мультброня в слоті нагрудника сама рахується повним комплектом
        if (p.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof DupeMultiArmorItem multi) {
            return multi.rank;
        }
        int min = Integer.MAX_VALUE;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            if (!(p.getItemBySlot(slot).getItem() instanceof DupeArmorItem armor)) {
                return 0;
            }
            min = Math.min(min, armor.rank);
        }
        return min;
    }

    public static boolean isFullSet(Player p) {
        return setTier(p) > 0;
    }

    /** Накладає ефект і поновлює його, коли лишається мало часу (без миготіння). */
    static void refresh(Player p, MobEffect effect, int amplifier, int minRemaining, int duration) {
        MobEffectInstance cur = p.getEffect(effect);
        if (cur == null || cur.getAmplifier() < amplifier || cur.getDuration() <= minRemaining) {
            p.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, true));
        }
    }

    @Override
    public void onArmorTick(ItemStack stack, Level level, Player player) {
        GearUtil.selfRepair(stack, player, rank);
        if (level.isClientSide) {
            return;
        }
        switch (this.getType()) {
            case HELMET -> applyHelmet(player, rank);
            case CHESTPLATE -> applyChest(level, player, rank);
            case LEGGINGS -> applyLeggings(player, rank);
            case BOOTS -> applyBoots(player, rank);
        }
    }

    static void applyHelmet(Player player, int rank) {
        refresh(player, MobEffects.NIGHT_VISION, 0, 260, 400);
        refresh(player, MobEffects.WATER_BREATHING, 0, 20, 60);
        if (rank >= 2) {
            refresh(player, MobEffects.DIG_SPEED, rank - 2, 20, 60); // Поспіх I..III
        }
    }

    static void applyChest(Level level, Player player, int rank) {
        magnet(level, player, rank);
    }

    static void applyLeggings(Player player, int rank) {
        refresh(player, MobEffects.FIRE_RESISTANCE, 0, 20, 60);
        refresh(player, MobEffects.MOVEMENT_SPEED, rank - 1, 20, 60); // Швидкість I..IV
    }

    static void applyBoots(Player player, int rank) {
        refresh(player, MobEffects.JUMP, rank, 20, 60); // Стрибучість II..V
        if (rank >= 3) {
            refresh(player, MobEffects.DOLPHINS_GRACE, 0, 20, 60);
        }
    }

    /** Магніт: притягує предмети (і краплі досвіду з 3-го рівня). Присядьте, щоб вимкнути. */
    private static void magnet(Level level, Player player, int rank) {
        if (player.isShiftKeyDown() || player.isSpectator()) {
            return;
        }
        double r = DupeConfig.MAGNET_RADIUS.get() * (1.0 + 0.5 * (rank - 1));
        Vec3 target = player.position().add(0, player.getBbHeight() / 2.0, 0);
        List<ItemEntity> items = level.getEntitiesOfClass(ItemEntity.class, player.getBoundingBox().inflate(r), e -> e.isAlive());
        for (ItemEntity item : items) {
            pull(item, target);
        }
        if (rank >= 3) {
            List<ExperienceOrb> orbs = level.getEntitiesOfClass(ExperienceOrb.class, player.getBoundingBox().inflate(r), e -> e.isAlive());
            for (ExperienceOrb orb : orbs) {
                pull(orb, target);
            }
        }
    }

    private static void pull(net.minecraft.world.entity.Entity entity, Vec3 target) {
        Vec3 diff = target.subtract(entity.position());
        if (diff.lengthSqr() < 0.3) {
            return;
        }
        entity.setDeltaMovement(diff.normalize().scale(0.35));
        entity.hurtMarked = true; // синхронізація руху з клієнтом
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        String key = switch (this.getType()) {
            case HELMET -> "helmet";
            case CHESTPLATE -> "chestplate";
            case LEGGINGS -> "leggings";
            case BOOTS -> "boots";
        };
        tooltip.add(Component.translatable("tooltip.dupercraft." + key).withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", rank).withStyle(ChatFormatting.AQUA));
        if (rank >= 2) {
            tooltip.add(Component.translatable("tooltip.dupercraft.repair").withStyle(ChatFormatting.DARK_AQUA));
        }
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
        if (rank >= 4) {
            tooltip.add(Component.translatable("tooltip.dupercraft.flight").withStyle(ChatFormatting.LIGHT_PURPLE));
        }
    }
}
