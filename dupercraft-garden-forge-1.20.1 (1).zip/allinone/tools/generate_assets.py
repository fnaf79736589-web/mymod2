#!/usr/bin/env python3
"""Генерує ВСІ ресурси мода DuperCraft: Garden (блоки, предмети, культури, прискорювачі, рецепти, переклади).
Запуск з кореня проєкту:  python3 tools/generate_assets.py   (потрібен Pillow)
Іконки предметів прості, їх можна замінити своїми PNG 16x16 у assets/dupercraft/textures/item/."""
import json, os, random
from PIL import Image, ImageDraw

MOD = "dupercraft"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
A = os.path.join(ROOT, "assets", MOD)
D = os.path.join(ROOT, "data", MOD)
random.seed(11)
LANG = {"en_us": {}, "uk_ua": {}, "ru_ru": {}}

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def noise(base, spread):
    return tuple(max(0, min(255, c + random.randint(-spread, spread))) for c in base)

# ====================== БЛОКИ: текстури ======================
def tex(name, painter):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    painter(img)
    p = os.path.join(A, "textures", "block", name + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

PLANK = (150, 110, 62); PURPLE = (110, 40, 170); GOLD = (245, 200, 60); OBS = (48, 26, 78)

def planks(img):
    for y in range(16):
        for x in range(16):
            c = noise(PLANK, 10)
            if y % 4 == 3:
                c = noise((105, 75, 40), 6)
            img.putpixel((x, y), c)

def wb_side(img):
    planks(img)
    for x in range(16):
        for y in (6, 7, 8):
            img.putpixel((x, y), noise(PURPLE, 8))
    for x in (0, 15):
        for y in range(16):
            img.putpixel((x, y), noise((70, 50, 28), 6))

def wb_top(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(PURPLE, 10))
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for gy in range(3):
        for gx in range(3):
            for dy in range(3):
                for dx in range(3):
                    x, y = 3 + gx * 4 + dx, 3 + gy * 4 + dy
                    img.putpixel((x, y), noise((30, 12, 55) if (dx, dy) != (1, 1) else (200, 160, 255), 6))

def chest_base(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(OBS, 8))

def chest_side(img):
    chest_base(img)
    for x in range(16):
        for y in (0, 1, 14, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(16):
        for x in (0, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(6, 11):
        for x in range(6, 10):
            img.putpixel((x, y), noise(GOLD, 6))
    img.putpixel((7, 8), (30, 20, 50, 255)); img.putpixel((8, 8), (30, 20, 50, 255))

def chest_top(img):
    chest_base(img)
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(5, 11):
        for x in range(5, 11):
            img.putpixel((x, y), noise((150, 70, 220), 10))

for n, f in [("dupe_workbench_top", wb_top), ("dupe_workbench_side", wb_side), ("dupe_workbench_bottom", planks),
             ("dupe_chest_top", chest_top), ("dupe_chest_side", chest_side), ("dupe_chest_bottom", chest_base)]:
    tex(n, f)

for b in ("dupe_workbench", "dupe_chest"):
    w(os.path.join(A, "models", "block", b + ".json"), {
        "parent": "minecraft:block/cube_bottom_top",
        "textures": {"top": f"{MOD}:block/{b}_top", "side": f"{MOD}:block/{b}_side", "bottom": f"{MOD}:block/{b}_bottom"}})
    w(os.path.join(A, "models", "item", b + ".json"), {"parent": f"{MOD}:block/{b}"})
    w(os.path.join(A, "blockstates", b + ".json"), {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(os.path.join(D, "loot_tables", "blocks", b + ".json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
w(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", "axe.json"),
  {"replace": False, "values": [f"{MOD}:dupe_workbench", f"{MOD}:dupe_chest"]})

# ====================== ПРЕДМЕТИ: іконки ======================
PAL = {"o": (30, 18, 48), "a": (120, 48, 180), "b": (195, 125, 245), "c": (72, 26, 118),
       "g": (250, 205, 70), "h": (125, 82, 46), "k": (82, 52, 26)}

def from_ascii(rows):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch in PAL:
                img.putpixel((x, y), PAL[ch] + (255,))
    return img

def mirror(half_rows):          # половина (8 колонок) -> повна ширина 16
    return [r + r[::-1] for r in half_rows]

def blank(n): return ["." * 8] * n

helmet = mirror(blank(2) + ["..oooooo", ".oaaaaaa", "oabbbbbb", "oabaaaaa", "oabaaaaa", "oabaaaaa",
                            "oabggggg", "oabcooo.", "oabc....", "oaco....", "ooo....."] + blank(3))
chest = mirror(blank(1) + ["ooo.oooo", "oaaooaaa", "oabbaaaa", "oabbaaaa", "ooabaaaa", ".oabaaaa", ".oabgggg",
                           ".oabaaaa", ".oabaaaa", ".oabaaaa", ".oacaaaa", ".ooooooo"] + blank(3))
legs = mirror(blank(2) + ["oooooooo", "oaaaaaaa", "oabbaaaa", "oabggggg", "oabaaaao", "oabaaao.", "oabaao..",
                          "oabaao..", "oabaao..", "oabcao..", "oooooo.."] + blank(3))
boots = mirror(blank(4) + ["..oooo..", "..oaabo.", "..oaabo.", "..oaabo.", "..oaabo.", ".ooaaabo", "oaaaaabo",
                           "oabbbbbo", "ooooooo."] + blank(3))

def icon(name, img):
    p = os.path.join(A, "textures", "item", name + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

def outline(img):
    px = img.load(); out = img.copy(); o = out.load()
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0:
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and px[nx, ny][3] > 0:
                        o[x, y] = PAL["o"] + (255,); break
    return out

def pickaxe():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.line([(3, 13), (11, 5)], fill=PAL["h"] + (255,), width=2)             # руків'я
    d.line([(3, 13), (4, 12)], fill=PAL["k"] + (255,), width=1)
    d.line([(2, 7), (3, 4), (6, 2), (10, 2), (13, 5), (14, 9)], fill=PAL["a"] + (255,), width=2)  # голова
    d.line([(3, 6), (4, 4), (7, 3), (10, 3)], fill=PAL["b"] + (255,), width=1)
    d.point([(8, 7), (9, 6)], fill=PAL["g"] + (255,))
    return outline(img)

def sword():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.line([(13, 2), (6, 9)], fill=PAL["a"] + (255,), width=3)               # клинок
    d.line([(13, 1), (6, 8)], fill=PAL["b"] + (255,), width=1)
    d.line([(4, 7), (9, 12)], fill=PAL["g"] + (255,), width=2)               # гарда
    d.line([(7, 10), (2, 14)], fill=PAL["h"] + (255,), width=2)              # руків'я
    d.point([(1, 14)], fill=PAL["g"] + (255,))
    return outline(img)

def ingot():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.polygon([(2, 10), (5, 5), (14, 5), (11, 10)], fill=PAL["b"] + (255,))     # верх
    d.polygon([(2, 10), (11, 10), (11, 13), (2, 13)], fill=PAL["a"] + (255,))   # перед
    d.polygon([(11, 10), (14, 5), (14, 8), (11, 13)], fill=PAL["c"] + (255,))   # бік
    d.line([(4, 7), (11, 7)], fill=PAL["g"] + (255,))
    d.point([(6, 11), (8, 11)], fill=PAL["g"] + (255,))
    return outline(img)

def hoe():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.line([(3, 13), (11, 5)], fill=PAL["h"] + (255,), width=2)
    d.line([(8, 3), (13, 3), (14, 7)], fill=PAL["a"] + (255,), width=2)
    d.line([(8, 3), (11, 6)], fill=PAL["a"] + (255,), width=2)
    d.line([(9, 2), (13, 2)], fill=PAL["b"] + (255,), width=1)
    return outline(img)

def fertilizer():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    d.rectangle([4, 4, 11, 13], fill=PAL["a"] + (255,))
    d.rectangle([4, 4, 11, 6], fill=PAL["b"] + (255,))
    d.rectangle([6, 8, 9, 11], fill=PAL["g"] + (255,))
    d.point([(7, 9), (8, 10)], fill=PAL["c"] + (255,))
    return outline(img)

# Комплекти: id, матеріал, палітра іконок, кольори броні (основний, смуга, тінь)
SETS = [
    ("dupe", "duperium", {"a": (120, 48, 180), "b": (195, 125, 245), "c": (72, 26, 118), "g": (250, 205, 70)},
     ((118, 46, 178), (245, 200, 70), (84, 30, 130))),
    ("aether", "aetherium", {"a": (40, 150, 200), "b": (150, 235, 255), "c": (20, 90, 135), "g": (235, 250, 255)},
     ((50, 160, 210), (235, 250, 255), (25, 100, 150))),
    ("void", "voidium", {"a": (50, 36, 92), "b": (140, 100, 235), "c": (22, 14, 44), "g": (255, 90, 200)},
     ((52, 38, 96), (255, 90, 200), (24, 16, 48))),
    ("singular", "singularium", {"a": (28, 28, 36), "b": (255, 165, 45), "c": (12, 12, 18), "g": (255, 225, 130)},
     ((30, 30, 40), (255, 165, 45), (14, 14, 20))),
]
PARTS = [("pickaxe", "item/handheld"), ("sword", "item/handheld"), ("hoe", "item/handheld"), ("helmet", "item/generated"),
         ("chestplate", "item/generated"), ("leggings", "item/generated"), ("boots", "item/generated")]

def model(item_id, parent):
    w(os.path.join(A, "models", "item", item_id + ".json"),
      {"parent": "minecraft:" + parent, "textures": {"layer0": f"{MOD}:item/{item_id}"}})

for sid, mat, pal, armor_cols in SETS:
    PAL.update(pal)
    icon(f"{mat}_ingot", ingot()); model(f"{mat}_ingot", "item/generated")
    icon(f"{sid}_pickaxe", pickaxe()); icon(f"{sid}_sword", sword()); icon(f"{sid}_hoe", hoe())
    icon(f"{sid}_helmet", from_ascii(helmet)); icon(f"{sid}_chestplate", from_ascii(chest))
    icon(f"{sid}_leggings", from_ascii(legs)); icon(f"{sid}_boots", from_ascii(boots))
    for part, parent in PARTS:
        model(f"{sid}_{part}", parent)
    # Текстури броні на моделі (64x32)
    base_c, stripe_c, shade_c = armor_cols
    for layer in (1, 2):
        img = Image.new("RGBA", (64, 32))
        for y in range(32):
            for x in range(64):
                col = base_c
                if y % 6 == 5: col = stripe_c
                elif (x + y) % 9 == 0: col = shade_c
                img.putpixel((x, y), tuple(noise(col, 8)) + (255,))
        pth = os.path.join(A, "textures", "models", "armor", f"{sid}_layer_{layer}.png")
        os.makedirs(os.path.dirname(pth), exist_ok=True)
        img.save(pth)
PAL.update(SETS[0][2])
icon("duperium_fertilizer", fertilizer()); model("duperium_fertilizer", "item/generated")

# ====================== РЕЦЕПТИ ======================
# Верстак дюпера: у ЗВИЧАЙНОМУ верстаку (3x3), дуже важкий
w(os.path.join(D, "recipes", "dupe_workbench.json"), {
    "type": "minecraft:crafting_shaped", "category": "misc",
    "pattern": ["NDN", "DBD", "NDN"],
    "key": {"N": {"item": "minecraft:netherite_ingot"}, "D": {"item": "minecraft:diamond_block"}, "B": {"item": "minecraft:beacon"}},
    "result": {"item": f"{MOD}:dupe_workbench"}})

def wb(name, pattern, key, result, count=1):
    r = {"item": result}
    if count > 1: r["count"] = count
    w(os.path.join(D, "recipes", name + ".json"), {"type": f"{MOD}:workbench", "category": "misc",
                                                    "pattern": pattern, "key": key, "result": r})

def it(i): return {"item": "minecraft:" + i}

def grid(rows, name):
    """Крапка = наповнювач (обсидіан). Перевіряємо, що рецепт 9x9 і жодна клітинка не порожня."""
    assert len(rows) == 9, name
    out = []
    for r in rows:
        assert len(r) == 9, (name, r)
        r = r.replace(".", "O")
        assert " " not in r, (name, r)
        out.append(r)
    assert sum(r.count("U") for r in out) >= 4, name + ": мало дюперію"
    return out

K = {  # спільні символи
    "O": it("obsidian"), "U": {"item": f"{MOD}:duperium_ingot"},
    "N": it("netherite_ingot"), "D": it("diamond_block"), "E": it("emerald_block"),
    "G": it("gold_block"), "S": it("nether_star"), "B": it("blaze_rod"),
}
def keys(*names, **extra):
    d = {k: K[k] for k in ("O", "U") + names}
    d.update(extra)
    return d

# --- Дюперій: ДУЖЕ важкий матеріал. Лише у верстаку дюпера, 81 предмет, виходить 4 злитки ---
RING = {4: "O", 3: "GR", 2: "DE", 1: "N", 0: "S"}
ring_rows = []
for r in range(9):
    row = ""
    for c in range(9):
        d = max(abs(r - 4), abs(c - 4))
        row += RING[d][(r + c) % 2] if len(RING[d]) == 2 else RING[d]
    ring_rows.append(row)
assert all(len(r) == 9 for r in ring_rows)
wb("duperium_ingot", ring_rows,
   {"O": it("obsidian"), "G": it("gold_block"), "R": it("redstone_block"), "D": it("diamond_block"),
    "E": it("emerald_block"), "N": it("netherite_ingot"), "S": it("nether_star")},
   f"{MOD}:duperium_ingot", count=4)

# --- Сундук-дюпер: 81 клітинка, 8 злитків дюперію ---
base = ["    S    ", "   GDG   ", "  GEEEG  ", " ODEXEDO ", "SGENCNEGS", " ODEXEDO ", "  GEEEG  ", "   GDG   ", "    S    "]
base = [r.replace(" ", ".") for r in base]
for (r, c) in ((0, 3), (0, 5), (8, 3), (8, 5), (3, 0), (5, 0), (3, 8), (5, 8)):
    row = list(base[r]); row[c] = "U"; base[r] = "".join(row)
wb("dupe_chest", grid(base, "dupe_chest"),
   keys("S", "G", "D", "E", "N", X=it("end_crystal"), C=it("ender_chest")), f"{MOD}:dupe_chest")

# --- Нові матеріали: 81 клітинка, кожен з попереднього (лише у верстаку дюпера) ---
def ring_pattern(spec):
    rows = []
    for r in range(9):
        row = ""
        for c in range(9):
            sym = spec[max(abs(r - 4), abs(c - 4))]
            row += sym[(r + c) % 2] if len(sym) == 2 else sym
        rows.append(row)
    return rows

def ring_recipe(name, spec, key, count):
    rows = ring_pattern(spec)
    assert set("".join(rows)) <= set(key), name
    wb(name, rows, key, f"{MOD}:{name}", count=count)

I = lambda ident: {"item": ident}
ring_recipe("aetherium_ingot", {4: "O", 3: "AQ", 2: "DE", 1: "U", 0: "S"},
            {"O": it("obsidian"), "A": it("amethyst_block"), "Q": it("quartz_block"), "D": it("diamond_block"),
             "E": it("emerald_block"), "U": I(f"{MOD}:duperium_ingot"), "S": it("nether_star")}, 3)
ring_recipe("voidium_ingot", {4: "C", 3: "PL", 2: "NY", 1: "U", 0: "B"},
            {"C": it("crying_obsidian"), "P": it("purpur_block"), "L": it("ender_pearl"), "N": it("netherite_ingot"),
             "Y": it("ender_eye"), "U": I(f"{MOD}:aetherium_ingot"), "B": it("beacon")}, 2)
ring_recipe("singularium_ingot", {4: "C", 3: "NE", 2: "SG", 1: "U", 0: "X"},
            {"C": it("crying_obsidian"), "N": it("netherite_ingot"), "E": it("end_crystal"), "S": it("nether_star"),
             "G": it("enchanted_golden_apple"), "U": I(f"{MOD}:voidium_ingot"), "X": it("netherite_block")}, 2)

# --- Екіпіровка: 4 комплекти x 7 предметів, 81 клітинка, матеріал комплекту в кожному рецепті ---
PATTERNS = {
    "pickaxe": [".NDDUDDN.", "ND..U..DN", "N...S...N", "....B....", "...UBU...", "....B....", "....B....", "....B....", "....B...."],
    "sword": ["....U....", "....D....", "....D....", "....D....", "..NNSNN..", "....U....", "....B....", "....B....", "...UBU..."],
    "hoe": ["..NDDDDN.", "..ND.UDN.", "...HSH...", "....B....", "...UBU...", "....B....", "....B....", "....B....", "...UBU..."],
    "helmet": ["..NNNNN..", ".NDDUDDN.", "NDD.E.DDN", "ND.U.U.DN", "ND.....DN", "NU.....UN", "N.......N", ".........", "........."],
    "chestplate": ["NN.....NN", "NDD...DDN", "NDDDDDDDN", "NDDULUDDN", "NDDUDUDDN", ".NDDUDDN.", ".NDDDDDN.", "..NDDDN..", "...NNN..."],
    "leggings": ["NNNNNNNNN", "NDDDUDDDN", "NDDMDMDDN", "ND.....DN", "ND.U.U.DN", "ND.....DN", "NDU...UDN", "ND.....DN", "NN.....NN"],
    "boots": [".........", ".NDDUDDN.", ".ND.L.DN.", ".ND...DN.", ".NDU.UDN.", ".ND...DN.", "NNDD.DDNN", "NDDDUDDDN", "NNNNNNNNN"],
}
EXTRA = {"helmet": {"E": it("ender_eye")}, "chestplate": {"L": it("lodestone")}, "leggings": {"M": it("magma_block")},
         "boots": {"L": it("slime_block")}, "hoe": {"H": it("hay_block")}}
SET_ITEMS = {   # комплект: (предмет матеріалу U, наповнювач, предмет S)
    "dupe": (f"{MOD}:duperium_ingot", "minecraft:obsidian", "minecraft:nether_star"),
    "aether": (f"{MOD}:aetherium_ingot", "minecraft:amethyst_block", "minecraft:nether_star"),
    "void": (f"{MOD}:voidium_ingot", "minecraft:crying_obsidian", "minecraft:beacon"),
    "singular": (f"{MOD}:singularium_ingot", "minecraft:crying_obsidian", "minecraft:netherite_block"),
}
for sid, (u_item, filler, star) in SET_ITEMS.items():
    for part, rows in PATTERNS.items():
        key = {"O": I(filler), "U": I(u_item), "N": it("netherite_ingot"), "D": it("diamond_block"), "S": I(star), "B": it("blaze_rod")}
        key.update(EXTRA.get(part, {}))
        used = set("".join(rows).replace(".", "O"))
        wb(f"{sid}_{part}", grid(rows, f"{sid}_{part}"), {k: v for k, v in key.items() if k in used}, f"{MOD}:{sid}_{part}")

# Дюперієве добриво: 76 кісткового борошна + 5 дюперію, виходить 16 шт.
fert = ["MMMMMMMMM"] * 9
for (r, c) in ((3, 4), (4, 3), (4, 4), (4, 5), (5, 4)):
    row = list(fert[r]); row[c] = "U"; fert[r] = "".join(row)
wb("duperium_fertilizer", grid(fert, "fertilizer"), keys(M=it("bone_meal")), f"{MOD}:duperium_fertilizer", count=16)

# ====================== ПЕРЕКЛАДИ ======================
items = {   # id: (en, uk, ru)
    "duperium_ingot": ("Duperium Ingot", "Дюперієвий злиток", "Дюпериевый слиток"),
    "duperium_fertilizer": ("Duperium Fertilizer", "Дюперієве добриво", "Дюпериевое удобрение"),
    "dupe_workbench": ("Dupe Workbench", "Верстак дюпера", "Верстак дюпера"),
    "dupe_chest": ("Dupe Chest", "Сундук-дюпер", "Сундук-дюпер"),
    "dupe_pickaxe": ("Duper's Pickaxe", "Кирка дюпера", "Кирка дюпера"),
    "dupe_sword": ("Duper's Blade", "Клинок дюпера", "Клинок дюпера"),
    "dupe_hoe": ("Duper's Hoe", "Мотика дюпера", "Мотыга дюпера"),
    "dupe_helmet": ("Duper's Visor", "Візор дюпера", "Визор дюпера"),
    "dupe_chestplate": ("Duper's Magnet Plate", "Магнітна кіраса дюпера", "Магнитный нагрудник дюпера"),
    "dupe_leggings": ("Duper's Cinder Greaves", "Вогнетривкі поножі дюпера", "Огнеупорные поножи дюпера"),
    "dupe_boots": ("Duper's Cushion Boots", "Амортизуючі черевики дюпера", "Амортизирующие ботинки дюпера"),
}
tips = {
 "en_us": {"pickaxe": "Chance to duplicate the drops of mined blocks", "sword": "Chance to duplicate items dropped by mobs",
           "hoe": "Right-click a crop: harvests and replants all ripe crops in 5x5, with a chance to duplicate the yield",
           "fertilizer": "Instantly ripens crops in a 3x3 area",
           "helmet": "Night Vision and Water Breathing", "chestplate": "Pulls nearby items to you (sneak to disable)",
           "leggings": "Fire Resistance and Speed", "boots": "No fall damage, Jump Boost II",
           "set_bonus": "Full armor set: Regeneration, tools' chance x2, crops sometimes drop double",
           "duperium": "Crafted only at the Dupe Workbench (9x9). Can also be grown as a crop"},
 "uk_ua": {"pickaxe": "Шанс подвоїти здобич із зламаних блоків", "sword": "Шанс подвоїти предмети, що випали з мобів",
           "hoe": "ПКМ по культурі: збирає й заново садить усі стиглі культури в 5x5, з шансом подвоїти здобич",
           "fertilizer": "Миттєво достигає культури в області 3x3",
           "helmet": "Нічний зір і дихання під водою", "chestplate": "Притягує предмети поруч (присядьте, щоб вимкнути)",
           "leggings": "Вогнестійкість і швидкість", "boots": "Падіння без шкоди, стрибучість II",
           "set_bonus": "Повний комплект броні: регенерація, шанс інструментів x2, культури іноді дають подвійну здобич",
           "duperium": "Крафтиться лише у верстаку дюпера (9x9). Його також можна вирощувати як культуру"},
 "ru_ru": {"pickaxe": "Шанс удвоить добычу со сломанных блоков", "sword": "Шанс удвоить предметы, выпавшие из мобов",
           "hoe": "ПКМ по культуре: собирает и заново сажает все спелые культуры в 5x5, с шансом удвоить добычу",
           "fertilizer": "Мгновенно вызревает культуры в области 3x3",
           "helmet": "Ночное зрение и подводное дыхание", "chestplate": "Притягивает предметы рядом (присядьте, чтобы отключить)",
           "leggings": "Огнестойкость и скорость", "boots": "Падение без урона, прыгучесть II",
           "set_bonus": "Полный комплект брони: регенерация, шанс инструментов x2, культуры иногда дают двойную добычу",
           "duperium": "Крафтится только на верстаке дюпера (9x9). Его также можно выращивать как культуру"},
}
for i, code in enumerate(("en_us", "uk_ua", "ru_ru")):
    L = LANG[code]
    L.update({f"itemGroup.{MOD}": "DuperCraft",
              f"container.{MOD}.workbench": items["dupe_workbench"][i],
              f"container.{MOD}.dupe_chest": items["dupe_chest"][i]})
    for key, v in items.items():
        L[("block." if key in ("dupe_workbench", "dupe_chest") else "item.") + f"{MOD}.{key}"] = v[i]
    for key, v in tips[code].items():
        L[f"tooltip.{MOD}.{key}"] = v

# ====================== КУЛЬТУРИ (crops.json) ======================
crops = json.load(open(os.path.join(ROOT, "crops.json"), encoding="utf-8"))["crops"]
# ---------- текстури (спільні, фарбуються кольором у грі) ----------
tex_dir = os.path.join(A, "textures")
os.makedirs(os.path.join(tex_dir, "block"), exist_ok=True)
os.makedirs(os.path.join(tex_dir, "item"), exist_ok=True)
random.seed(7)
heights = [5, 9, 13, 15]
for s in range(4):
    stem = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    ore = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    h = heights[s]
    for x in (3, 7, 11, 15):  # 4 стебла
        top = 15 - h + (x % 3)
        for y in range(top, 16):
            g = 110 + (y * 7 + x * 3) % 50
            stem.putpixel((x, y), (50, g, 40, 255))
            if x > 0 and s >= 1 and y < top + 4:
                stem.putpixel((x - 1, y), (60, g - 10, 45, 255))
    if s >= 1:  # листочки/бруньки
        for x in (3, 7, 11, 15):
            top = 15 - h + (x % 3)
            for dx, dy in [(-1, 0), (1, 0), (0, -1)][: s]:
                px, py = x + dx, top + dy + 1
                if 0 <= px < 16 and 0 <= py < 16:
                    v = 215 + random.randint(0, 40)
                    ore.putpixel((px, py), (v, v, v, 255))
    if s == 3:  # зріла: великі «самородки»
        for x in (3, 7, 11, 15):
            top = 15 - h + (x % 3)
            for dx in (-1, 0):
                for dy in (0, 1):
                    px, py = x + dx, top + dy
                    if 0 <= px < 16 and 0 <= py < 16:
                        v = 225 + random.randint(0, 30)
                        ore.putpixel((px, py), (v, v, v, 255))
    stem.save(os.path.join(tex_dir, "block", f"crop_stem_{s}.png"))
    ore.save(os.path.join(tex_dir, "block", f"crop_ore_{s}.png"))

seed = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
for (x, y) in [(5, 6), (6, 6), (5, 7), (6, 7), (9, 8), (10, 8), (9, 9), (10, 9), (7, 11), (8, 11), (7, 12), (8, 12)]:
    seed.putpixel((x, y), (235, 235, 235, 255))
for (x, y) in [(4, 6), (4, 7), (7, 6), (7, 7), (8, 8), (8, 9), (11, 8), (11, 9), (6, 11), (6, 12), (9, 11), (9, 12)]:
    seed.putpixel((x, y), (160, 160, 160, 255))
seed.save(os.path.join(tex_dir, "item", "crop_seeds.png"))

# ---------- спільні моделі стадій росту (4 штуки) ----------
def planes(tex, tint, off):
    def face(d):
        f = {"uv": [0, 0, 16, 16], "texture": tex}
        if tint:
            f["tintindex"] = 0
        return {d: f}
    a, b = 4 + off, 12 - off
    els = []
    for x in (a, b):
        els.append({"from": [x, -1, 0], "to": [x, 15, 16], "faces": {**face("east"), **face("west")}})
    for z in (a, b):
        els.append({"from": [0, -1, z], "to": [16, 15, z], "faces": {**face("north"), **face("south")}})
    return els

for s in range(4):
    w(os.path.join(A, "models", "block", f"crop_stage_{s}.json"), {
        "ambientocclusion": False,
        "render_type": "minecraft:cutout",
        "textures": {
            "particle": f"{MOD}:block/crop_stem_{s}",
            "stem": f"{MOD}:block/crop_stem_{s}",
            "ore": f"{MOD}:block/crop_ore_{s}",
        },
        "elements": planes("#stem", False, 0) + planes("#ore", True, 0.05),
    })


# Назви ресурсів: (укр, рос)
NAMES = {
    "coal": ("Вугілля", "Уголь"), "charcoal": ("Деревне вугілля", "Древесный уголь"),
    "iron": ("Залізо", "Железо"), "copper": ("Мідь", "Медь"), "gold": ("Золото", "Золото"),
    "diamond": ("Алмаз", "Алмаз"), "emerald": ("Смарагд", "Изумруд"),
    "lapis": ("Лазурит", "Лазурит"), "redstone": ("Редстоун", "Редстоун"),
    "quartz": ("Кварц", "Кварц"), "amethyst": ("Аметист", "Аметист"),
    "glowstone": ("Світлокамінний пил", "Светокаменная пыль"),
    "netherite_scrap": ("Незеритовий брухт", "Незеритовый лом"),
    "netherite": ("Незерит", "Незерит"), "ender_pearl": ("Перлина Краю", "Жемчужина Края"),
    "blaze": ("Вогняний стрижень", "Огненный стержень"), "slime": ("Слиз", "Слизь"),
    "gunpowder": ("Порох", "Порох"), "bone": ("Кістка", "Кость"), "clay": ("Глина", "Глина"),
    "flint": ("Кремінь", "Кремень"),
    "raw_iron": ("Необроблене залізо", "Необработанное железо"), "raw_copper": ("Необроблена мідь", "Необработанная медь"),
    "raw_gold": ("Необроблене золото", "Необработанное золото"), "ancient_debris": ("Древні уламки", "Древние обломки"),
    "obsidian": ("Обсидіан", "Обсидиан"), "prismarine_shard": ("Призмариновий уламок", "Призмариновый осколок"),
    "prismarine_crystals": ("Призмаринові кристали", "Призмариновые кристаллы"), "ghast_tear": ("Сльоза гаста", "Слеза гаста"),
    "shulker_shell": ("Панцир шалкера", "Панцирь шалкера"), "echo_shard": ("Уламок відлуння", "Осколок эха"),
    "iu_sapphire": ("Сапфір", "Сапфир"), "iu_ruby": ("Рубін", "Рубин"), "iu_topaz": ("Топаз", "Топаз"),
    "iu_nichrome": ("Ніхром", "Нихром"), "iu_ferromanganese": ("Феромарганець", "Ферромарганец"),
    "iu_tempered_glass": ("Загартоване скло", "Закалённое стекло"),
    "iu_tin": ("Олово", "Олово"), "iu_lead": ("Свинець", "Свинец"),
    "iu_silver": ("Срібло", "Серебро"), "iu_nickel": ("Нікель", "Никель"),
    "iu_aluminium": ("Алюміній", "Алюминий"), "iu_titanium": ("Титан", "Титан"),
    "iu_tungsten": ("Вольфрам", "Вольфрам"), "iu_uranium": ("Уран", "Уран"),
    "iu_bronze": ("Бронза", "Бронза"), "iu_steel": ("Сталь", "Сталь"),
}


# Назви ресурсів Industrial Upgrade: ключ без "iu_" -> (укр, рос)
IU_NAMES = {
 "adamantium": ("Адамантій", "Адамантий"), "alloy": ("Сплав", "Сплав"), "aluminium": ("Алюміній", "Алюминий"),
 "arsenic": ("Миш'як", "Мышьяк"), "barium": ("Барій", "Барий"), "bismuth": ("Вісмут", "Висмут"),
 "bloodstone": ("Кривавий камінь", "Кровавый камень"), "bronze": ("Бронза", "Бронза"), "cadmium": ("Кадмій", "Кадмий"),
 "caravky": ("Каравки", "Каравки"), "chromium": ("Хром", "Хром"), "cobalt": ("Кобальт", "Кобальт"),
 "draconid": ("Драконід", "Дракониды"), "electrum": ("Електрум", "Электрум"), "gadolinium": ("Гадоліній", "Гадолиний"),
 "gallium": ("Галій", "Галлий"), "germanium": ("Германій", "Германий"), "hafnium": ("Гафній", "Гафний"),
 "invar": ("Інвар", "Инвар"), "iridium": ("Ірідій", "Иридий"), "lead": ("Свинець", "Свинец"),
 "magnesium": ("Магній", "Магний"), "manganese": ("Марганець", "Марганец"), "meteoric_iron": ("Метеоритне залізо", "Метеоритное железо"),
 "mikhail": ("Міхаїл", "Михаил"), "mithril": ("Мітрил", "Мифрил"), "molybdenum": ("Молібден", "Молибден"),
 "neodymium": ("Неодим", "Неодим"), "nickel": ("Нікель", "Никель"), "niobium": ("Ніобій", "Ниобий"),
 "orichalcum": ("Орихалк", "Орихалк"), "osmium": ("Осмій", "Осмий"), "palladium": ("Паладій", "Палладий"),
 "platinum": ("Платина", "Платина"), "polonium": ("Полоній", "Полоний"), "silver": ("Срібло", "Серебро"),
 "spinel": ("Шпінель", "Шпинель"), "steel": ("Сталь", "Сталь"), "strontium": ("Стронцій", "Стронций"),
 "tantalum": ("Тантал", "Тантал"), "thallium": ("Талій", "Таллий"), "tin": ("Олово", "Олово"),
 "titanium": ("Титан", "Титан"), "tungsten": ("Вольфрам", "Вольфрам"), "vanadium": ("Ванадій", "Ванадий"),
 "yttrium": ("Ітрій", "Иттрий"), "zinc": ("Цинк", "Цинк"), "zirconium": ("Цирконій", "Цирконий"),
 "uranium": ("Уран", "Уран"),
 "alcled": ("Алклед", "Алклэд"), "alumel": ("Алюмель", "Алюмель"),
 "aluminium_lithium_alloy": ("Алюмінієво-літієвий сплав", "Алюминиево-литиевый сплав"),
 "aluminium_silicon": ("Алюміній-кремній", "Алюминий-кремний"), "aluminum_bronze": ("Алюмінієва бронза", "Алюминиевая бронза"),
 "beryllium_bronze": ("Берилієва бронза", "Бериллиевая бронза"), "cobalt_chrome": ("Кобальт-хром", "Кобальт-хром"),
 "duralumin": ("Дюралюміній", "Дюралюминий"), "ferromanganese": ("Феромарганець", "Ферромарганец"),
 "gallium_arsenic": ("Арсенід галію", "Арсенид галлия"), "hafnium_boride_alloy": ("Борид гафнію", "Борид гафния"),
 "hafnium_carbide": ("Карбід гафнію", "Карбид гафния"), "inconel": ("Інконель", "Инконель"),
 "molybdenum_steel": ("Молібденова сталь", "Молибденовая сталь"), "muntsa": ("Мунца", "Мунца"),
 "nichrome": ("Ніхром", "Нихром"), "nimonic": ("Німонік", "Нимоник"), "niobium_titanium": ("Ніобій-титан", "Ниобий-титан"),
 "nitenol": ("Нітінол", "Нитинол"), "osmiridium": ("Осмірідій", "Осмиридий"), "permalloy": ("Пермалой", "Пермаллой"),
 "red_brass": ("Червона латунь", "Красная латунь"), "stainless_steel": ("Нержавіюча сталь", "Нержавеющая сталь"),
 "stellite": ("Стеліт", "Стеллит"), "superalloy_haynes": ("Суперсплав Хейнс", "Суперсплав Хейнс"),
 "superalloy_rene": ("Суперсплав Рене", "Суперсплав Рене"),
 "tantalum_tungsten_hafnium": ("Тантал-вольфрам-гафній", "Тантал-вольфрам-гафний"),
 "vanadoalumite": ("Ванадоалюміт", "Ванадоалюмит"), "vitalium": ("Віталіум", "Виталлиум"),
 "woods": ("Сплав Вуда", "Сплав Вуда"), "yttrium_aluminium_garnet": ("Ітрій-алюмінієвий гранат", "Иттрий-алюминиевый гранат"),
 "zeliber": ("Зелібер", "Зелибер"),
 "tempered_glass": ("Загартоване скло", "Закалённое стекло"), "reinforced_glass": ("Посилене скло", "Усиленное стекло"),
 "ruby": ("Рубін", "Рубин"), "sapphire": ("Сапфір", "Сапфир"), "topaz": ("Топаз", "Топаз"),
}
NAMES.update({"iu_" + k: v for k, v in IU_NAMES.items()})
NAMES["duperium"] = ("Дюперій", "Дюперий")
NAMES["aetherium"] = ("Ефіріум", "Эфириум")
NAMES["voidium"] = ("Войдіум", "Войдиум")
NAMES["singularium"] = ("Сингуларій", "Сингулярий")

# ---------- по-культурні файли ----------
lang_en = LANG["en_us"]; lang_en[f"itemGroup.{MOD}.crops"] = "Resource Crops"
lang_uk = LANG["uk_ua"]; lang_uk[f"itemGroup.{MOD}.crops"] = "Ресурсні культури"
lang_ru = LANG["ru_ru"]; lang_ru[f"itemGroup.{MOD}.crops"] = "Ресурсные культуры"

for c in crops:
    n = c["name"]
    title = n.replace("iu_", "").replace("_", " ").title()
    prefix = " (Industrial Upgrade)" if c.get("mod") == "industrialupgrade" else ""
    lang_en[f"item.{MOD}.{n}_seeds"] = f"{title} Seeds{prefix}"
    lang_en[f"block.{MOD}.{n}_crop"] = f"{title} Crop{prefix}"
    uk_n, ru_n = NAMES.get(n, (title, title))
    lang_uk[f"item.{MOD}.{n}_seeds"] = f"Насіння: {uk_n}{prefix}"
    lang_uk[f"block.{MOD}.{n}_crop"] = f"Культура: {uk_n}{prefix}"
    lang_ru[f"item.{MOD}.{n}_seeds"] = f"Семена: {ru_n}{prefix}"
    lang_ru[f"block.{MOD}.{n}_crop"] = f"Культура: {ru_n}{prefix}"

    # blockstate: вік 0..7 -> 4 моделі
    w(os.path.join(A, "blockstates", f"{n}_crop.json"), {
        "variants": {f"age={a}": {"model": f"{MOD}:block/crop_stage_{a // 2}"} for a in range(8)}
    })
    # модель насіння
    w(os.path.join(A, "models", "item", f"{n}_seeds.json"), {
        "parent": "minecraft:item/generated",
        "textures": {"layer0": f"{MOD}:item/crop_seeds"},
    })
    # рецепт: насіння пшениці + 1 ресурс -> насіння культури
    recipe = {}
    if c.get("mod") or not c["item"].startswith("minecraft:"):
        recipe["conditions"] = [{"type": "forge:item_exists", "item": c["item"]}]
    recipe.update({
        "type": "minecraft:crafting_shapeless",
        "category": "misc",
        "ingredients": [{"item": "minecraft:wheat_seeds"}] + [{"item": c["item"]}] * c.get("seedCost", 1),
        "result": {"item": f"{MOD}:{n}_seeds"},
    })
    w(os.path.join(D, "recipes", f"{n}_seeds.json"), recipe)


# ====================== ПРИСКОРЮВАЧІ СЕЛЕКЦІЇ (5 рівнів) ======================
def bn(base, s):
    return tuple(max(0, min(255, c + random.randint(-s, s))) for c in base) + (255,)

# рівень: (основний колір, колір рамки, колір "сот"/світла, англ., укр., рос.)
TIERS = [
    ((46, 110, 58),   (24, 60, 34),   (240, 190, 50),  "Basic",    "Базовий",    "Базовый"),
    ((40, 100, 150),  (20, 50, 85),   (170, 230, 255), "Improved", "Покращений", "Улучшенный"),
    ((110, 55, 160),  (60, 28, 95),   (235, 170, 255), "Advanced", "Просунутий", "Продвинутый"),
    ((190, 90, 40),   (100, 45, 20),  (255, 220, 120), "Perfect",  "Досконалий", "Совершенный"),
    ((200, 230, 240), (80, 100, 120), (255, 255, 255), "Photonic", "Фотонний",   "Фотонный"),
    ((60, 60, 140),   (30, 30, 80),   (120, 255, 220), "Quantum",  "Квантовий",  "Квантовый"),
    ((230, 200, 90),  (120, 95, 30),  (255, 255, 230), "Stellar",  "Зоряний",    "Звёздный"),
    ((70, 30, 120),   (30, 10, 60),   (255, 120, 230), "Cosmic",   "Космічний",  "Космический"),
    ((30, 120, 110),  (10, 60, 55),   (255, 230, 120), "Temporal", "Часовий",    "Временной"),
    ((20, 20, 24),    (0, 0, 0),      (255, 215, 80),  "Absolute", "Абсолютний", "Абсолютный"),
]
ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]

def name(t):
    return "breeding_booster" if t == 1 else f"breeding_booster_{t}"

def save(nm, fn):
    img = Image.new("RGBA", (16, 16))
    fn(img)
    p = os.path.join(A, "textures", "block", nm + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

for t, (main, dark, light, *_ ) in enumerate(TIERS, start=1):
    def base(img):
        for y in range(16):
            for x in range(16):
                img.putpixel((x, y), bn(main, 8))
    def frame(img):
        for i in range(16):
            for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
                img.putpixel((x, y), bn(dark, 6))
    def side(img):
        base(img); frame(img)
        for (cx, cy) in ((4, 4), (11, 4), (4, 9), (11, 9)):
            for dx, dy in ((0,0),(1,0),(-1,0),(0,1),(0,-1)):
                img.putpixel((cx + dx, cy + dy), bn(light, 8))
        for i in range(t):                     # t крапок = рівень (у два ряди)
            img.putpixel((2 + (i % 5) * 3, 13 - (i // 5) * 2), bn(light, 4))
    def top(img):
        base(img); frame(img)
        for y in range(3, 13):
            for x in range(3, 13):
                if (x - 7.5) ** 2 + (y - 7.5) ** 2 < 22:
                    img.putpixel((x, y), bn(light, 10))
        for y in range(6, 10):
            for x in range(6, 10):
                img.putpixel((x, y), bn(dark, 6))
    def bottom(img):
        base(img); frame(img)
    save(name(t) + "_side", side); save(name(t) + "_top", top); save(name(t) + "_bottom", bottom)

    b = name(t)
    w(os.path.join(A, "models", "block", b + ".json"), {
        "parent": "minecraft:block/cube_bottom_top",
        "textures": {"top": f"{MOD}:block/{b}_top", "side": f"{MOD}:block/{b}_side", "bottom": f"{MOD}:block/{b}_bottom"}})
    w(os.path.join(A, "models", "item", b + ".json"), {"parent": f"{MOD}:block/{b}"})
    w(os.path.join(A, "blockstates", b + ".json"), {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(os.path.join(D, "loot_tables", "blocks", b + ".json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

w(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", "pickaxe.json"),
  {"replace": False, "values": [f"{MOD}:{name(t)}" for t in range(1, len(TIERS) + 1)]})

# Рецепти. Рівень 1 з простих матеріалів; рівень N = попередній прискорювач у центрі + матеріали.
w(os.path.join(D, "recipes", name(1) + ".json"), {
    "type": "minecraft:crafting_shaped", "category": "misc",
    "pattern": ["RBR", "BDB", "RBR"],
    "key": {"R": {"item": "minecraft:redstone"}, "B": {"item": "minecraft:bone_meal"}, "D": {"item": "minecraft:diamond"}},
    "result": {"item": f"{MOD}:{name(1)}"}})
UPGRADES = {   # рівень: (кути, боки)
    2: ("minecraft:gold_ingot", "minecraft:bone_block"),
    3: ("minecraft:diamond", "minecraft:emerald"),
    4: ("dupercraft:duperium_ingot", "minecraft:gold_block"),
    5: ("dupercraft:duperium_ingot", "minecraft:nether_star"),
    6: ("dupercraft:aetherium_ingot", "minecraft:diamond_block"),
    7: ("dupercraft:aetherium_ingot", "minecraft:netherite_ingot"),
    8: ("dupercraft:voidium_ingot", "minecraft:nether_star"),
    9: ("dupercraft:voidium_ingot", "dupercraft:aetherium_ingot"),
    10: ("dupercraft:singularium_ingot", "dupercraft:voidium_ingot"),
}
for t, (corner, edge) in UPGRADES.items():
    w(os.path.join(D, "recipes", name(t) + ".json"), {
        "type": "minecraft:crafting_shaped", "category": "misc",
        "pattern": ["CEC", "EXE", "CEC"],
        "key": {"C": {"item": corner}, "E": {"item": edge}, "X": {"item": f"{MOD}:{name(t - 1)}"}},
        "result": {"item": f"{MOD}:{name(t)}"}})


msgs = {
 "en_us": {"status": "Tier %s: boosting %s blocks (radius %s, speed x%s)",
           "scan_none": "No Industrial Upgrade blocks within 8 blocks of you",
           "scan_header": "Industrial Upgrade blocks nearby (id, count, tick type):", "scan_line": "%s x%s [%s, %s]"},
 "uk_ua": {"status": "Рівень %s: прискорюється блоків %s (радіус %s, швидкість x%s)",
           "scan_none": "Блоків Industrial Upgrade у радіусі 8 блоків немає",
           "scan_header": "Блоки Industrial Upgrade поруч (ID, кількість, тип тіку):", "scan_line": "%s x%s [%s, %s]"},
 "ru_ru": {"status": "Уровень %s: ускоряется блоков %s (радиус %s, скорость x%s)",
           "scan_none": "Блоков Industrial Upgrade в радиусе 8 блоков нет",
           "scan_header": "Блоки Industrial Upgrade рядом (ID, количество, тип тика):", "scan_line": "%s x%s [%s, %s]"},
}
base_names = {"en_us": "Breeding Booster", "uk_ua": "Прискорювач селекції", "ru_ru": "Ускоритель селекции"}
idx = {"en_us": 3, "uk_ua": 4, "ru_ru": 5}
for code in ("en_us", "uk_ua", "ru_ru"):
    for key, v in msgs[code].items():
        LANG[code][f"message.{MOD}.{key}"] = v
    for t, tier in enumerate(TIERS, start=1):
        roman = ROMAN[t - 1]
        LANG[code][f"block.{MOD}.{name(t)}"] = f"{base_names[code]}: {tier[idx[code]]} ({roman})"

# Тег блоків, які прискорюють прискорювачі (усі культури мода)
w(os.path.join(ROOT, "data", MOD, "tags", "blocks", "boostable.json"),
  {"replace": False, "values": [f"{MOD}:{c['name']}_crop" for c in crops]})


# ====================== ПЕРЕКЛАДИ: нові матеріали й комплекти ======================
MAT = {  # комплект: (EN, UK називний, UK родовий, RU називний, RU родовий)
    "aether": ("Aetherium", "Ефіріум", "ефіріуму", "Эфириум", "эфириума"),
    "void": ("Voidium", "Войдіум", "войдіуму", "Войдиум", "войдиума"),
    "singular": ("Singularium", "Сингуларій", "сингуларію", "Сингулярий", "сингулярия"),
}
PART_NAMES = {  # частина: (EN-шаблон, UK-шаблон, RU-шаблон)
    "pickaxe": ("{M} Pickaxe", "Кирка {g}", "Кирка {g}"), "sword": ("{M} Blade", "Клинок {g}", "Клинок {g}"),
    "hoe": ("{M} Hoe", "Мотика {g}", "Мотыга {g}"), "helmet": ("{M} Visor", "Візор {g}", "Визор {g}"),
    "chestplate": ("{M} Magnet Plate", "Магнітна кіраса {g}", "Магнитный нагрудник {g}"),
    "leggings": ("{M} Cinder Greaves", "Вогнетривкі поножі {g}", "Огнеупорные поножи {g}"),
    "boots": ("{M} Cushion Boots", "Амортизуючі черевики {g}", "Амортизирующие ботинки {g}"),
}
INGOT_NAMES = {  # комплект: (id злитка, EN, UK, RU)
    "aether": ("aetherium_ingot", "Aetherium Ingot", "Ефіріумовий злиток", "Эфириумовый слиток"),
    "void": ("voidium_ingot", "Voidium Ingot", "Войдіумовий злиток", "Войдиумовый слиток"),
    "singular": ("singularium_ingot", "Singularium Ingot", "Сингуларієвий злиток", "Сингуляриевый слиток"),
}
for sid, (en, uk, uk_g, ru, ru_g) in MAT.items():
    ingot_id, n_en, n_uk, n_ru = INGOT_NAMES[sid]
    LANG["en_us"][f"item.{MOD}.{ingot_id}"] = n_en
    LANG["uk_ua"][f"item.{MOD}.{ingot_id}"] = n_uk
    LANG["ru_ru"][f"item.{MOD}.{ingot_id}"] = n_ru
    for part, (t_en, t_uk, t_ru) in PART_NAMES.items():
        LANG["en_us"][f"item.{MOD}.{sid}_{part}"] = t_en.format(M=en)
        LANG["uk_ua"][f"item.{MOD}.{sid}_{part}"] = t_uk.format(g=uk_g)
        LANG["ru_ru"][f"item.{MOD}.{sid}_{part}"] = t_ru.format(g=ru_g)
EXTRA_TIPS = {
    "en_us": {"chance": "Duplicate chance: %s%%", "gear_tier": "Gear tier %s of 4",
              "aetherium": "Tier II material: crafted at the Dupe Workbench (9x9) from Duperium",
              "voidium": "Tier III material: crafted at the Dupe Workbench (9x9) from Aetherium",
              "singularium": "Tier IV material: crafted at the Dupe Workbench (9x9) from Voidium"},
    "uk_ua": {"chance": "Шанс подвоєння: %s%%", "gear_tier": "Рівень екіпіровки %s з 4",
              "aetherium": "Матеріал II рівня: крафтиться у верстаку дюпера (9x9) з дюперію",
              "voidium": "Матеріал III рівня: крафтиться у верстаку дюпера (9x9) з ефіріуму",
              "singularium": "Матеріал IV рівня: крафтиться у верстаку дюпера (9x9) з войдіуму"},
    "ru_ru": {"chance": "Шанс удвоения: %s%%", "gear_tier": "Уровень экипировки %s из 4",
              "aetherium": "Материал II уровня: крафтится на верстаке дюпера (9x9) из дюперия",
              "voidium": "Материал III уровня: крафтится на верстаке дюпера (9x9) из эфириума",
              "singularium": "Материал IV уровня: крафтится на верстаке дюпера (9x9) из войдиума"},
}
for code, tips_ in EXTRA_TIPS.items():
    for k_, v_ in tips_.items():
        LANG[code][f"tooltip.{MOD}.{k_}"] = v_

# ====================== ЗАПИС ПЕРЕКЛАДІВ ======================
for code, d_ in LANG.items():
    w(os.path.join(A, "lang", code + ".json"), d_)
print(f"Готово: {len(crops)} культур, {len(TIERS)} рівнів прискорювача")
