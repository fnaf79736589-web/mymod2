package com.example.dupercraft;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;

import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.crafting.CraftingHelper;

/**
 * Фасонний рецепт розміром до 9x9 (JSON як у ванільного crafting_shaped: pattern + key + result).
 * Візерунок може лежати в будь-якому місці сітки; дозволено дзеркальне відображення.
 */
public class DupeWorkbenchRecipe implements Recipe<CraftingContainer> {
    public static final int MAX_SIZE = 9;

    private final ResourceLocation id;
    private final int width;
    private final int height;
    private final NonNullList<Ingredient> ingredients;
    private final ItemStack result;

    public DupeWorkbenchRecipe(ResourceLocation id, int width, int height, NonNullList<Ingredient> ingredients, ItemStack result) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.ingredients = ingredients;
        this.result = result;
    }

    public int getRecipeWidth() {
        return width;
    }

    public int getRecipeHeight() {
        return height;
    }

    /** Результат без потреби в RegistryAccess (для JEI). */
    public ItemStack getResult() {
        return result;
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        int cw = container.getWidth();
        int ch = container.getHeight();
        for (int ox = 0; ox <= cw - width; ox++) {
            for (int oy = 0; oy <= ch - height; oy++) {
                if (matchesAt(container, ox, oy, false) || matchesAt(container, ox, oy, true)) {
                    return true;
                }
            }
        }
        return false;
    }

    private boolean matchesAt(CraftingContainer container, int ox, int oy, boolean mirror) {
        int cw = container.getWidth();
        int ch = container.getHeight();
        for (int x = 0; x < cw; x++) {
            for (int y = 0; y < ch; y++) {
                int rx = x - ox;
                int ry = y - oy;
                Ingredient ing = Ingredient.EMPTY;
                if (rx >= 0 && ry >= 0 && rx < width && ry < height) {
                    ing = mirror ? ingredients.get(width - rx - 1 + ry * width) : ingredients.get(rx + ry * width);
                }
                if (!ing.test(container.getItem(x + y * cw))) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess access) {
        return result.copy();
    }

    @Override
    public boolean canCraftInDimensions(int w, int h) {
        return w >= width && h >= height;
    }

    @Override
    public ItemStack getResultItem(RegistryAccess access) {
        return result;
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return ingredients;
    }

    @Override
    public ResourceLocation getId() {
        return id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return DuperCraft.RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return DuperCraft.RECIPE_TYPE.get();
    }

    public static class Serializer implements RecipeSerializer<DupeWorkbenchRecipe> {
        @Override
        public DupeWorkbenchRecipe fromJson(ResourceLocation id, JsonObject json) {
            JsonArray pattern = GsonHelper.getAsJsonArray(json, "pattern");
            int height = pattern.size();
            if (height < 1 || height > MAX_SIZE) {
                throw new JsonSyntaxException("pattern: висота має бути від 1 до " + MAX_SIZE);
            }
            int width = GsonHelper.convertToString(pattern.get(0), "pattern[0]").length();
            if (width < 1 || width > MAX_SIZE) {
                throw new JsonSyntaxException("pattern: ширина має бути від 1 до " + MAX_SIZE);
            }

            Map<Character, Ingredient> key = new HashMap<>();
            for (Map.Entry<String, JsonElement> e : GsonHelper.getAsJsonObject(json, "key").entrySet()) {
                if (e.getKey().length() != 1) {
                    throw new JsonSyntaxException("key: ключ має бути одним символом: " + e.getKey());
                }
                key.put(e.getKey().charAt(0), Ingredient.fromJson(e.getValue()));
            }
            key.put(' ', Ingredient.EMPTY);

            NonNullList<Ingredient> list = NonNullList.withSize(width * height, Ingredient.EMPTY);
            for (int r = 0; r < height; r++) {
                String row = GsonHelper.convertToString(pattern.get(r), "pattern[" + r + "]");
                if (row.length() != width) {
                    throw new JsonSyntaxException("pattern: усі рядки мають бути однакової довжини (" + width + ")");
                }
                for (int c = 0; c < width; c++) {
                    Ingredient ing = key.get(row.charAt(c));
                    if (ing == null) {
                        throw new JsonSyntaxException("pattern використовує символ '" + row.charAt(c) + "', якого немає в key");
                    }
                    list.set(c + r * width, ing);
                }
            }
            ItemStack result = CraftingHelper.getItemStack(GsonHelper.getAsJsonObject(json, "result"), true);
            return new DupeWorkbenchRecipe(id, width, height, list, result);
        }

        @Override
        public DupeWorkbenchRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            int width = buf.readVarInt();
            int height = buf.readVarInt();
            NonNullList<Ingredient> list = NonNullList.withSize(width * height, Ingredient.EMPTY);
            for (int i = 0; i < list.size(); i++) {
                list.set(i, Ingredient.fromNetwork(buf));
            }
            return new DupeWorkbenchRecipe(id, width, height, list, buf.readItem());
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, DupeWorkbenchRecipe recipe) {
            buf.writeVarInt(recipe.width);
            buf.writeVarInt(recipe.height);
            for (Ingredient ing : recipe.ingredients) {
                ing.toNetwork(buf);
            }
            buf.writeItem(recipe.result);
        }
    }
}
