package com.example.dupercraft;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Клинок дюпера: шанс подвоїти предмети, що випали з убитого моба (логіка в DupeEvents). */
public class DupeSwordItem extends SwordItem {
    public final DupeTier gear;

    public DupeSwordItem(DupeTier tier) {
        super(tier, 3, -2.4F, new Item.Properties().fireResistant().rarity(Rarity.EPIC));
        this.gear = tier;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.dupercraft.sword").withStyle(ChatFormatting.LIGHT_PURPLE));
        int percent = (int) Math.round(Math.min(1.0, DupeConfig.SWORD_CHANCE.get() * gear.chanceMult) * 100);
        tooltip.add(Component.translatable("tooltip.dupercraft.chance", percent).withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.translatable("tooltip.dupercraft.gear_tier", gear.rank).withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.dupercraft.set_bonus").withStyle(ChatFormatting.GOLD));
    }
}
