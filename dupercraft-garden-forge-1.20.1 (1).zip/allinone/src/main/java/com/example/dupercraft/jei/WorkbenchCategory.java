package com.example.dupercraft.jei;

import java.util.List;

import com.example.dupercraft.DupeWorkbenchRecipe;
import com.example.dupercraft.DuperCraft;

import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.builder.IRecipeSlotBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.drawable.IDrawableStatic;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/** Категорія JEI «Верстак дюпера»: показує рецепти типу dupercraft:workbench у сітці до 9x9. */
public class WorkbenchCategory implements IRecipeCategory<DupeWorkbenchRecipe> {
    public static final RecipeType<DupeWorkbenchRecipe> TYPE =
            RecipeType.create(DuperCraft.MODID, "workbench", DupeWorkbenchRecipe.class);

    private static final int GRID = 9;
    private static final int SLOT = 18;
    private static final int ARROW_X = GRID * SLOT + 4;
    private static final int OUTPUT_X = ARROW_X + 24 + 4;
    private static final int WIDTH = OUTPUT_X + SLOT + 2;
    private static final int HEIGHT = GRID * SLOT;

    private final IDrawable background;
    private final IDrawable icon;
    private final IDrawableStatic arrow;

    public WorkbenchCategory(IGuiHelper gui) {
        this.background = gui.createBlankDrawable(WIDTH, HEIGHT);
        this.icon = gui.createDrawableIngredient(VanillaTypes.ITEM_STACK, new ItemStack(DuperCraft.WORKBENCH_ITEM.get()));
        this.arrow = gui.getRecipeArrow();
    }

    @Override
    public RecipeType<DupeWorkbenchRecipe> getRecipeType() {
        return TYPE;
    }

    @Override
    public Component getTitle() {
        return Component.translatable("container.dupercraft.workbench");
    }

    @Override
    public IDrawable getBackground() {
        return background;
    }

    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, DupeWorkbenchRecipe recipe, IFocusGroup focuses) {
        int w = recipe.getRecipeWidth();
        int h = recipe.getRecipeHeight();
        int ox = (GRID - w) / 2;
        int oy = (GRID - h) / 2;
        List<Ingredient> ingredients = recipe.getIngredients();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                Ingredient ingredient = ingredients.get(x + y * w);
                IRecipeSlotBuilder slot = builder.addSlot(RecipeIngredientRole.INPUT, (ox + x) * SLOT + 1, (oy + y) * SLOT + 1);
                if (!ingredient.isEmpty()) {
                    slot.addIngredients(ingredient);
                }
            }
        }
        builder.addSlot(RecipeIngredientRole.OUTPUT, OUTPUT_X + 1, (HEIGHT - SLOT) / 2 + 1)
                .addItemStack(recipe.getResult());
    }

    @Override
    public void draw(DupeWorkbenchRecipe recipe, IRecipeSlotsView recipeSlotsView, GuiGraphics guiGraphics, double mouseX, double mouseY) {
        arrow.draw(guiGraphics, ARROW_X, (HEIGHT - arrow.getHeight()) / 2);
    }
}
