package com.example.dupercraft.jei;

import java.util.Objects;

import com.example.dupercraft.DupeWorkbenchRecipe;
import com.example.dupercraft.DupeWorkbenchScreen;
import com.example.dupercraft.DuperCraft;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeManager;

/** Підключення до JEI: рецепти верстака дюпера (власний тип рецептів) стають видимими в JEI. */
@JeiPlugin
public class DuperJeiPlugin implements IModPlugin {
    private static final ResourceLocation UID = new ResourceLocation(DuperCraft.MODID, "jei_plugin");

    @Override
    public ResourceLocation getPluginUid() {
        return UID;
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        registration.addRecipeCategories(new WorkbenchCategory(registration.getJeiHelpers().getGuiHelper()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        RecipeManager recipes = Objects.requireNonNull(Minecraft.getInstance().level).getRecipeManager();
        registration.addRecipes(WorkbenchCategory.TYPE, recipes.getAllRecipesFor(DuperCraft.RECIPE_TYPE.get()));
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalyst(new ItemStack(DuperCraft.WORKBENCH_ITEM.get()), WorkbenchCategory.TYPE);
    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        // клік по стрілці у вікні верстака відкриває рецепти JEI
        registration.addRecipeClickArea(DupeWorkbenchScreen.class, 176, 94, 18, 12, WorkbenchCategory.TYPE);
    }
}
