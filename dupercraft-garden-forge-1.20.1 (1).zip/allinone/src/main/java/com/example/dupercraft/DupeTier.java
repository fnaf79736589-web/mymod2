package com.example.dupercraft;

import java.util.function.Supplier;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Рівні інструментів дюпера: від дюперію до сингуларію. Усі видобувають усе (рівень 4, як незерит). */
public enum DupeTier implements Tier {
    DUPE(1, 2500, 9.0F, 4.0F, 22, 1.0, () -> DuperCraft.DUPERIUM_INGOT.get()),
    AETHER(2, 3200, 10.5F, 5.0F, 26, 1.4, () -> DuperCraft.AETHERIUM_INGOT.get()),
    VOID(3, 4500, 12.0F, 6.0F, 30, 1.8, () -> DuperCraft.VOIDIUM_INGOT.get()),
    SINGULAR(4, 7000, 14.0F, 8.0F, 35, 2.3, () -> DuperCraft.SINGULARIUM_INGOT.get());

    /** Номер рівня 1..4. */
    public final int rank;
    /** Множник шансу подвоєння здобичі. */
    public final double chanceMult;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantment;
    private final Supplier<Item> ingot;

    DupeTier(int rank, int uses, float speed, float damage, int enchantment, double chanceMult, Supplier<Item> ingot) {
        this.rank = rank;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantment = enchantment;
        this.chanceMult = chanceMult;
        this.ingot = ingot;
    }

    @Override
    public int getUses() {
        return uses;
    }

    @Override
    public float getSpeed() {
        return speed;
    }

    @Override
    public float getAttackDamageBonus() {
        return damage;
    }

    @Override
    public int getLevel() {
        return 4;
    }

    @Override
    public int getEnchantmentValue() {
        return enchantment;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ingot.get());
    }
}
