#!/usr/bin/env python3
"""Генерує текстури, моделі, blockstates, рецепти, loot tables, теги й переклади для DuperCraft.
Запуск з кореня проєкту:  python3 tools/generate_assets.py   (потрібен Pillow)"""
import json, os, random
from PIL import Image

MOD = "dupercraft"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
A = os.path.join(ROOT, "assets", MOD)
D = os.path.join(ROOT, "data", MOD)
random.seed(11)

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def noise(base, spread):
    return tuple(max(0, min(255, c + random.randint(-spread, spread))) for c in base)

def tex(name, painter):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 255))
    painter(img)
    p = os.path.join(A, "textures", "block", name + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

PLANK = (150, 110, 62)
PURPLE = (110, 40, 170)
GOLD = (245, 200, 60)
OBS = (48, 26, 78)

def planks(img):
    for y in range(16):
        for x in range(16):
            c = noise(PLANK, 10)
            if y % 4 == 3:
                c = noise((105, 75, 40), 6)
            img.putpixel((x, y), c)

def wb_bottom(img):
    planks(img)

def wb_side(img):
    planks(img)
    for x in range(16):               # фіолетова смуга
        for y in (6, 7, 8):
            img.putpixel((x, y), noise(PURPLE, 8))
    for x in (0, 15):
        for y in range(16):
            img.putpixel((x, y), noise((70, 50, 28), 6))

def wb_top(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(PURPLE, 10))
    for i in range(16):               # рамка
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for gy in range(3):               # сітка 3x3
        for gx in range(3):
            for dy in range(3):
                for dx in range(3):
                    x, y = 3 + gx * 4 + dx, 3 + gy * 4 + dy
                    img.putpixel((x, y), noise((30, 12, 55) if (dx, dy) != (1, 1) else (200, 160, 255), 6))

def chest_base(img):
    for y in range(16):
        for x in range(16):
            img.putpixel((x, y), noise(OBS, 8))

def chest_side(img):
    chest_base(img)
    for x in range(16):               # золоті обручі
        for y in (0, 1, 14, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(16):
        for x in (0, 15):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(6, 11):            # замок
        for x in range(6, 10):
            img.putpixel((x, y), noise(GOLD, 6))
    img.putpixel((7, 8), (30, 20, 50, 255)); img.putpixel((8, 8), (30, 20, 50, 255))

def chest_top(img):
    chest_base(img)
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), noise(GOLD, 8))
    for y in range(5, 11):
        for x in range(5, 11):
            img.putpixel((x, y), noise((150, 70, 220), 10))

def chest_bottom(img):
    chest_base(img)

for n, f in [("dupe_workbench_top", wb_top), ("dupe_workbench_side", wb_side), ("dupe_workbench_bottom", wb_bottom),
             ("dupe_chest_top", chest_top), ("dupe_chest_side", chest_side), ("dupe_chest_bottom", chest_bottom)]:
    tex(n, f)

for b in ("dupe_workbench", "dupe_chest"):
    w(os.path.join(A, "models", "block", b + ".json"), {
        "parent": "minecraft:block/cube_bottom_top",
        "textures": {"top": f"{MOD}:block/{b}_top", "side": f"{MOD}:block/{b}_side", "bottom": f"{MOD}:block/{b}_bottom"},
    })
    w(os.path.join(A, "models", "item", b + ".json"), {"parent": f"{MOD}:block/{b}"})
    w(os.path.join(A, "blockstates", b + ".json"), {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(os.path.join(D, "loot_tables", "blocks", b + ".json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
                   "entries": [{"type": "minecraft:item", "name": f"{MOD}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}],
    })

for tag in ("axe",):
    w(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", tag + ".json"),
      {"replace": False, "values": [f"{MOD}:dupe_workbench", f"{MOD}:dupe_chest"]})

# Рецепт верстака: у звичайному верстаку
w(os.path.join(D, "recipes", "dupe_workbench.json"), {
    "type": "minecraft:crafting_shaped", "category": "misc",
    "pattern": ["OOO", "DTD", "OOO"],
    "key": {"O": {"item": "minecraft:obsidian"}, "D": {"item": "minecraft:diamond"}, "T": {"item": "minecraft:crafting_table"}},
    "result": {"item": f"{MOD}:dupe_workbench"},
})
# Рецепт сундука-дюпера: ТІЛЬКИ у верстаку DuperCraft (тип dupercraft:workbench)
w(os.path.join(D, "recipes", "dupe_chest.json"), {
    "type": f"{MOD}:workbench", "category": "misc",
    "pattern": ["DGD", "GSG", "DGD"],
    "key": {"D": {"item": "minecraft:diamond_block"}, "G": {"item": "minecraft:gold_block"}, "S": {"item": "minecraft:nether_star"}},
    "result": {"item": f"{MOD}:dupe_chest"},
})

lang = {
 "en_us": {"itemGroup.dupercraft": "DuperCraft", "block.dupercraft.dupe_workbench": "Dupe Workbench",
           "block.dupercraft.dupe_chest": "Dupe Chest", "container.dupercraft.workbench": "Dupe Workbench",
           "container.dupercraft.dupe_chest": "Dupe Chest"},
 "uk_ua": {"itemGroup.dupercraft": "DuperCraft", "block.dupercraft.dupe_workbench": "Верстак дюпера",
           "block.dupercraft.dupe_chest": "Сундук-дюпер", "container.dupercraft.workbench": "Верстак дюпера",
           "container.dupercraft.dupe_chest": "Сундук-дюпер"},
 "ru_ru": {"itemGroup.dupercraft": "DuperCraft", "block.dupercraft.dupe_workbench": "Верстак дюпера",
           "block.dupercraft.dupe_chest": "Сундук-дюпер", "container.dupercraft.workbench": "Верстак дюпера",
           "container.dupercraft.dupe_chest": "Сундук-дюпер"},
}
for code, d in lang.items():
    w(os.path.join(A, "lang", code + ".json"), d)
print("Готово")
