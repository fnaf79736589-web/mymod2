package com.example.dupercraft;

import com.google.gson.JsonObject;

import net.minecraft.core.NonNullList;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.minecraft.world.level.Level;

/** Звичайний фасонний рецепт (JSON як у ванілі), але іншого типу, тому працює лише у верстаку DuperCraft. */
public class DupeWorkbenchRecipe implements Recipe<CraftingContainer> {
    private final ShapedRecipe inner;

    public DupeWorkbenchRecipe(ShapedRecipe inner) {
        this.inner = inner;
    }

    @Override
    public boolean matches(CraftingContainer container, Level level) {
        return inner.matches(container, level);
    }

    @Override
    public ItemStack assemble(CraftingContainer container, RegistryAccess access) {
        return inner.assemble(container, access);
    }

    @Override
    public boolean canCraftInDimensions(int width, int height) {
        return inner.canCraftInDimensions(width, height);
    }

    @Override
    public ItemStack getResultItem(RegistryAccess access) {
        return inner.getResultItem(access);
    }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        return inner.getIngredients();
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(CraftingContainer container) {
        return inner.getRemainingItems(container);
    }

    @Override
    public ResourceLocation getId() {
        return inner.getId();
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return DuperCraft.RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return DuperCraft.RECIPE_TYPE.get();
    }

    public static class Serializer implements RecipeSerializer<DupeWorkbenchRecipe> {
        @Override
        public DupeWorkbenchRecipe fromJson(ResourceLocation id, JsonObject json) {
            return new DupeWorkbenchRecipe(RecipeSerializer.SHAPED_RECIPE.fromJson(id, json));
        }

        @Override
        public DupeWorkbenchRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            return new DupeWorkbenchRecipe(RecipeSerializer.SHAPED_RECIPE.fromNetwork(id, buf));
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, DupeWorkbenchRecipe recipe) {
            RecipeSerializer.SHAPED_RECIPE.toNetwork(buf, recipe.inner);
        }
    }
}
