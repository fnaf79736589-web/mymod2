package com.example.dupercraft;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(DuperCraft.MODID)
public class DuperCraft {
    public static final String MODID = "dupercraft";

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(ForgeRegistries.RECIPE_TYPES, MODID);
    public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of().strength(2.5F).sound(SoundType.WOOD);
    }

    // Блоки
    public static final RegistryObject<Block> WORKBENCH = BLOCKS.register("dupe_workbench", () -> new DupeWorkbenchBlock(props()));
    public static final RegistryObject<Block> DUPE_CHEST = BLOCKS.register("dupe_chest", () -> new DupeChestBlock(props()));

    // Предмети-блоки
    public static final RegistryObject<Item> WORKBENCH_ITEM = ITEMS.register("dupe_workbench", () -> new BlockItem(WORKBENCH.get(), new Item.Properties()));
    public static final RegistryObject<Item> DUPE_CHEST_ITEM = ITEMS.register("dupe_chest", () -> new BlockItem(DUPE_CHEST.get(), new Item.Properties()));

    // Блок-сутність сундука
    public static final RegistryObject<BlockEntityType<DupeChestBlockEntity>> DUPE_CHEST_BE = BLOCK_ENTITIES.register("dupe_chest",
            () -> BlockEntityType.Builder.of(DupeChestBlockEntity::new, DUPE_CHEST.get()).build(null));

    // Меню верстака
    public static final RegistryObject<MenuType<DupeWorkbenchMenu>> WORKBENCH_MENU = MENUS.register("workbench",
            () -> IForgeMenuType.create((id, inv, data) -> new DupeWorkbenchMenu(id, inv)));

    // Власний тип рецептів (крафтяться лише в цьому верстаку)
    public static final RegistryObject<RecipeType<DupeWorkbenchRecipe>> RECIPE_TYPE = RECIPE_TYPES.register("workbench",
            () -> RecipeType.simple(new ResourceLocation(MODID, "workbench")));
    public static final RegistryObject<RecipeSerializer<DupeWorkbenchRecipe>> RECIPE_SERIALIZER = RECIPE_SERIALIZERS.register("workbench",
            DupeWorkbenchRecipe.Serializer::new);

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.dupercraft"))
                    .icon(() -> new ItemStack(DUPE_CHEST_ITEM.get()))
                    .displayItems((params, out) -> {
                        out.accept(WORKBENCH_ITEM.get());
                        out.accept(DUPE_CHEST_ITEM.get());
                    })
                    .build());

    public DuperCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        MENUS.register(bus);
        RECIPE_TYPES.register(bus);
        RECIPE_SERIALIZERS.register(bus);
        TABS.register(bus);
    }
}
